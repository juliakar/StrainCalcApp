BATCH_2D =0;
BATCH_3D =10;

clear stats reg_strains_2D reg_strains_3D all_strains

if BATCH_2D
k=1;
all_strains = cell(1,12+1);
    for i=1:size(cn,1)
        
        proc = 1;
        for j=1:size(cn,2)
            if exist(cn{i,j}, 'file')
            else
                proc =0;
            end
        end
%         if strfind(cn{i,1}, 'NORM') 
%         else
%                 proc =0;
%         end
        if proc
            found_excptn =0;
            for j=1:size(cn,2)
                try
                    all_strains{1,1}(k,j)=i;
                    reg_strains_2D = LagrangeStrain( cn{i,j},2,11,2);
                    reg_strains_2D=reshape(reg_strains_2D,1,12);
                    for m=2:12+1
                        all_strains{1,m}(k,j)= reg_strains_2D(1,m-1);
                    end
                catch exception
                    found_excptn =1;
                end
            end
            if found_excptn 
            else
                k=k+1;
            end
        end
    end
%     for i=1:size(all_strains,2)
%         for j=1:size(cn,2)
%             all_strains{1,i}(find(isnan(all_strains{1,i}(:,j))==1),:)=[];
%         end
%     end
    anv_stats = []; stats=[];
    for i=1:size(all_strains,2)
        [anv_stats{i} b stats{i}]=anova1(all_strains{1,i}, [], 'off');
        [c,m,h,nms] = multcompare(stats{i}, 'display', 'off');
    end
end

if BATCH_3D
    k=1;all_strains = cell(1,18*7+1);
    for i=1:size(cn3,1)
        proc = 1;
        for j=1:size(cn3,2)
            if exist(cn3{i,j}, 'file')
            else
                proc =0;
            end
        end
        if proc
            found_excptn =0;
            for j=1:size(cn3,2)
                try
                    all_strains{1,1}(k,j)=i;
%                    ParseDispFile3D_2(cn3{i,j});
                     reg_strains_3D = Lagrange3_3D_Func( cn3{i,j});
                    reg_strains_3D=reshape(reg_strains_3D,1,18*7);
                    for m=2:18*7+1
                        all_strains{1,m}(k,j)= reg_strains_3D(1,m-1);
                    end
                catch exception
                    found_excptn =1;
                end
            end
            if found_excptn == 0
                k=k+1;
            end
        end
    end
%     for i=1:size(all_strains,2)
%         for j=1:size(cn3,2)
%             all_strains{1,i}(find(isnan(all_strains{1,i}(:,j))==1),:)=[];
%         end
%     end
end
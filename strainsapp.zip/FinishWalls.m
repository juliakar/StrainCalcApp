function [ wall_out] = FinishWalls( wall, offset, scale, creatid )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

sz_wall = size(wall,1);
wall_out = zeros(sz_wall,3);
if (creatid > 0)
   cent_wall = [mean(wall(1:sz_wall,1)), ...
            mean(wall(1:sz_wall,2)), ...
            mean(wall(1:sz_wall,3))];
   Dx=wall(1:sz_wall,1)-cent_wall(1,1);
   Dy=wall(1:sz_wall,2)-cent_wall(1,2);
   z = cent_wall(1,3);
   wall_out=[Dx*scale + cent_wall(1,1) , Dy*scale + cent_wall(1,2) ,...
                                    (z+offset)*ones(sz_wall,1)];
% % %    Dr = sqrt(Dx.^2+Dy.^2); 
% % %    r = sum(Dr)/sz_wall*scale;
% % %    tdiff = 2*pi/sz_wall;
% % %    tht = tdiff;
% % %    for j=1:sz_wall
% % %        tht = tht+tdiff;
% % %        x= r*cos(tht);
% % %        y= r*sin(tht);
% % %        wall_out(j,:)=[cent_wall(1,1)+x cent_wall(1,2)+y z + offset];
% % %    end
end   

end


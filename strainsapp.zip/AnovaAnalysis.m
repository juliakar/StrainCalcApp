load NORM_Stats; 
HF = exist('HF_Data', 'var');
if HF
else
    return;
end
ALL_regs = zeros(size(HF_Data));
 for i=1:18:size(HF_Data,1)
ALL_regs(i:i+17,:) = (HF_Data(i:i+17,:)-NORM_stats(1:18,1:3))./NORM_stats(1:18,4:6);
end
for i=1:18:size(ALL_regs,1)
    ALL_regs(i:i+17,4)=1:18';
end
for i=1:size(ALL_regs,1)
if ALL_regs(i,4) <= 6
ALL_regs(i,5)=1;
elseif ALL_regs(i,4) <= 12
ALL_regs(i,5)=2;
else
ALL_regs(i,5)=3;
end
end
for i=1:6:size(ALL_regs,1)
ALL_regs(i:i+5,6)=[1,2,3,4,5,6]';
end
%temp=ALL_regs(temp,2);temp1=reshape(temp,6,size(ALL_regs,1)/6/3)';
ALL_regs2 = [];%zeros(size(ALL_regs,1)/6, 6);
% for i=1:3
%     temp=find(ALL_regs(:,5) == i);
for i=1:18
    temp=find(ALL_regs(:,4) == i);
    temp=ALL_regs(temp,3);
    %temp1=reshape(temp,6,)';
     temp1=reshape(temp,size(ALL_regs,1)/6/3,1)';
    ALL_regs2 =[ ALL_regs2;temp1];
end
%P=anova2(ALL_regs2,size(ALL_regs,1)/6/3);




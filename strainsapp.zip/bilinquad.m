function [E XY] = bilinquad(XYZ,xyz)

%
% Output Variables
% E - Lagrangian Strain Tensor

% Input Variables
% XYZ - Reference Surface Coordinates: [X Y] - N(rows)x2(columns)
% xyz - Deformed Surface Coordinates: [x y] - Nx2

%%%%%%%%%%%%%%%%%%%%%%%%% Define Input Variables %%%%%%%%%%%%%%%%%%%%%%%%%%

% Find any deformed points that are NaN and set reference points to match
num_pts =4;
phi = .5777;
zi = .5777;
ind = isnan(xyz(:,1)) == 1;
XYZ(ind,1:2) = NaN;

XS=XYZ(:,1);
YS=XYZ(:,2);

f = zeros(num_pts,1);
dfdphi = zeros(num_pts,1);
dfdzi = zeros(num_pts,1);

f(1) = 0.25*(1-phi)*(1-zi);
f(2) = 0.25*(1+phi)*(1-zi);
f(3) = 0.25*(1+phi)*(1+zi);
f(4) = 0.25*(1-phi)*(1+zi);
dfdphi(1) = -0.25*(1-zi);
dfdphi(2) = 0.25*(1-zi);
dfdphi(3) = 0.25*(1+zi);
dfdphi(4) = -0.25*(1+zi);
dfdzi(1) = -0.25*(1-phi);
dfdzi(2) = -0.25*(1+phi);
dfdzi(3) = 0.25*(1+phi);
dfdzi(4) = 0.25*(1-phi);
        
E = zeros(2,2,length(XS));
XY = zeros(2, length(XS));
for ix=1:length(XS),
    if isnan(XS(ix))
        
    else        
        % Make Unit Normal And Tangents,
        X0 = XYZ(ix,1);Y0 = XYZ(ix,2);
        x0 = xyz(ix,1);y0 = xyz(ix,2);
        
        % Find Points in the Neighborhood
        DX=XS-X0;DY=YS-Y0;
        DR = sqrt(DX.^2+DY.^2);
        
        [~,IX] = sort(DR);
        
        % Keep Number of points (num_pts)
        
        Xi=XS(IX(1:num_pts))-X0;
        Yi=YS(IX(1:num_pts))-Y0;
        
        XY(1,ix) = X0;
        XY(2,ix) = Y0;
        SumXip = 0;
        SumYip = 0;
        SumXiz = 0;
        SumYiz = 0;
        for i=1:num_pts
            SumXip = SumXip + dfdphi(i)*Xi(i);
            SumXiz = SumXiz + dfdzi(i)*Xi(i);
            SumYip = SumYip + dfdphi(i)*Yi(i);
            SumYiz = SumYiz + dfdzi(i)*Yi(i);
%             XY(1,ix) = XY(1,ix) + Xi(i);
%             XY(2,ix) = XY(2,ix) + Yi(i);
        end
         XY(1,ix) = sum( XS(IX(1:num_pts)))/4;
          XY(2,ix) =sum( YS(IX(1:num_pts)))/4;
        J = [SumXip SumYip;SumXiz SumYiz];
        Jmat = [inv(J), [0 0;0 0]; [0 0;0 0] inv(J)];
        dfdsi=[dfdphi(1) 0 dfdphi(2) 0 dfdphi(3) 0 dfdphi(4) 0;...
            dfdzi(1) 0 dfdzi(2) 0 dfdzi(3) 0 dfdzi(4) 0;...
             0 dfdphi(1) 0 dfdphi(2) 0 dfdphi(3) 0 dfdphi(4);...
            0 dfdzi(1) 0 dfdzi(2) 0 dfdzi(3) 0 dfdzi(4);];
         
        I = [1 0 0 0; 0 0 0 1; 0 1 1 0];
        %%%%%% Assign Normal And Tangential Coordinates - Atlas Surface %%%%%%%
        
        B = I*Jmat*dfdsi;
       
        
        % fit curves for deformed vertices
        xi = xyz(IX(1:num_pts),1)-x0;
        yi = xyz(IX(1:num_pts),2)-y0;
        
        del =[xi(1)-Xi(1);yi(1)-Yi(1);...
            xi(2)-Xi(2);yi(2)-Yi(2);...
            xi(3)-Xi(3);yi(3)-Yi(3);...
            xi(4)-Xi(4);yi(4)-Yi(4)]; 
        Ebar=B*del;
        
        E(:,:,ix) = [Ebar(1) Ebar(3); Ebar(3) Ebar(2)];
    end
    
    if ix==length(XS)
        disp('script finished')
    end    
end
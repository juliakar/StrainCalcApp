function [coords, disps ] = Displacements3_3D_Func( filename)

clear points disps;
disp('The file being processed is: ')
which(filename)
try
[disps, coords]=ParseDispFile3D_2(filename);%SYSYW12.sci %YSYW12.sci/
catch exception
    rethrow(exception);
end
end
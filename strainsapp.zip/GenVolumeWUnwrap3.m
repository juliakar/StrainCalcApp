function [endo_d, epi_d,endo_s, epi_s, A_endo, A_epi, V] =GenVolumeWUnwrap3( dirname,my_names,rect,brightness,flipped)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% % % num_slices=3;
% % % slice_offset=1;
warning off;
A_endo=[]; A_epi=[]; V=[];
NUMPTS=30;
SHOWFINAL=0;
% my_names=cell(0);
addpath(genpath(dirname));

if isempty(my_names)
disp('No magnitude files found');
        return;
end

all_names=my_names;
SEGDIV1=1;SEGDIV2=1;SEGDIV3=3;

fsegpair=cell(size(all_names,1),2);
sizediv=uint16(size(all_names,1)/3);
for i=1:size(all_names,1)
    fsegpair{i,2}=SEGDIV1;
    fsegpair{i,1}=all_names{i};
    if i>sizediv*2
        fsegpair{i,2}=SEGDIV3;
    end
%    curdir=all_names{i};
%     my_files=dir(strcat(topdir,curdir,'\'));
%     mynum=3;
%     dcminfo = dicominfo(my_files(mynum).name);
%     z_inc=dcminfo.SliceLocation;
end


num_slices=size(my_names,1);

dcmm=cell(num_slices);
dcmm2=cell(num_slices);
epi = struct('xi',[],'yi',[],'zi',[]);
endo = struct('xi',[],'yi',[],'zi',[]);

epi_d=epi;
epi_s=epi;
endo_d=endo;
endo_s=endo;

topdir=dirname;
addpath(genpath(topdir));


bi=1;
vert=[];
set_aspect=1;
for i=1:size(my_names,1)
    fnum=6;
    curdir=my_names{i};
    
    DR_ELLIPSE=1;
    for findmyo = 1:1
        if findmyo==2
            fnum=12;
            DR_ELLIPSE=0;
        end
        
    my_files=dir(strcat(topdir,curdir,'\'));
    par=curdir;
    p=findstr(par,'PAR');
    par=par(p:p+4);
    p=findstr(par,'_');
    if p>0
        par=par(1:p-1);
    end
    stat= sprintf('Initial boundary for partition %s ...',par);
    dcminfo = dicominfo(my_files(fnum).name);
    z_inc=dcminfo.SliceLocation;
I2=imcrop(dicomread(my_files(fnum).name),rect);
I2=imfilter(I2,[3 3]);
[N, edges]=histcounts(I2,10);
% I2=locallapfilt(I2, .2,.25);
I2=imsharpen(I2,'Radius',5,'Amount',10);
I2(I2<=edges(3))=edges(3);
thresh = multithresh(I2,10);
valuesMax = [ thresh(1) max(I2(:)) ];
[qI2, index] = imquantize(I2, thresh(1), valuesMax);

if DR_ELLIPSE
    figure; 
    imagesc(qI2), colormap gray%,[brightness*min(I2(:)) brightness*max(I2(:))]),colormap gray;   
    hold;
    title(stat);
    if isempty(vert)
        himel=imellipse;vert=wait(himel);
    else
        himel=imellipse(gca,[min(vert) max(vert)-min(vert)]);
        vert=wait(himel);
    end
    [z, a, b, alpha] = fitellipse(vert,'linear','constraint','trace');
    vert=plotellipse(z, a, b, alpha);vert=vert';
    delete(himel);
end
disp('Completed part 0');
    cent=[mean(vert(:,1)),mean(vert(:,2))];
    rx_max=0.5*(max(vert(:,1))-min(vert(:,1)));
    ry_max=0.5*(max(vert(:,2))-min(vert(:,2)));
    adivs=360/size(vert,1);
    isize_max=int16(360/adivs);
    px_bound=rx_max*(cosd([1:adivs:360]))+cent(1,1);
    py_bound=ry_max*(sind([1:adivs:360]))+cent(1,2);
    px_bound=px_bound';py_bound=py_bound';
    
    rx=0.5*rx_max:1:rx_max;
    szrx=size(rx,2);
    ry=0.5*ry_max:1:ry_max;
    szry=size(ry,2);
    cx = cent(1,1)-5:1:cent(1,1)+5;
    szcx=size(cx,2);
    cy = cent(1,2)-5:1:cent(1,2)+5;
    szcy=size(cy,2);
    rx0=repmat(rx,szry*szcx*szcy,1);
    ry0=repmat(ry,szcx*szcy,szrx);
    cx0=repmat(cx,szcy,szry*szrx);
    cy0=repmat(cy,1,szcx*szry*szrx);
    rx0=reshape(rx0,size(rx0,1)*size(rx0,2),1);
    ry0=reshape(ry0,size(ry0,1)*size(ry0,2),1);
    cx0=reshape(cx0,size(cx0,1)*size(cx0,2),1);
    cy0=reshape(cy0,size(cy0,1)*size(cy0,2),1);
    px0=rx0.*(cosd([1:adivs:360]))+repmat(cx0,1,size([1:adivs:360],2));
    py0=ry0.*(sind([1:adivs:360]))+repmat(cy0,1,size([1:adivs:360],2));
    px_max=[];
    py_max=[];
    px_ind=[];
    py_ind=[];
    isize_ind=0;
    fac=5;
    px0_temp=px0(:,1:fac:size(px0,2))';
    py0_temp=py0(:,1:fac:size(py0,2))';
%     poly_h=impoly(px_bound,py_bound);
    idx=find(min(inpolygon(px0_temp,py0_temp,px_bound,py_bound))>0);%==uint16(size(px_bound,1)/fac));
    for p=idx
                    px=px0(p,:)';py=py0(p,:)';
                    intensities=[];
                    
%                     if sum(inpolygon(px,py,px_bound,py_bound))==size(px_bound,1)
%                         for q=1:size(px,1)
%                             intensities=[intensities;qI2(uint16(py(q)),uint16(px(q)))];
%                         end
                        intensities=improfile(qI2,px,py);
%                         hp=plot([px;px(1)],[py;py(1)],'c');drawnow;
                        aspect = (max(px)-min(px))/(max(py)-min(py));
                        isize=size(find(intensities>min(qI2(:))),1);
% %                         if isize >= isize_max
% % %                             px_max=px;
% % %                             py_max=py;
% %                         end
                        if isize >= isize_ind && aspect >= set_aspect
%                             delete(poly_h);
                            px_ind=px;
                            py_ind=py;
                            isize_ind=isize;   
                            title(sprintf('%s... searching polygon # %d',stat,p));
%                             poly_h=impoly(px,py);
                            drawnow;
                        end
    end
% % %     for rx=0.5*rx_max:1:rx_max
% % %         for ry=0.5*ry_max:1:ry_max
% % % %     for rx=rx_max:-1:0.5*rx_max
% % % %         for ry=ry_max:-1:0.5*ry_max
% % %             for cx = cent(1,1)-5:1:cent(1,1)+5
% % %                 for cy = cent(1,2)-5:1:cent(1,2)+5
% % %                     px=rx*(cosd([1:adivs:360]))+cx;
% % %                     py=ry*(sind([1:adivs:360]))+cy;
% % %                     px=px';py=py';
% % %                     intensities=[];
% % %                     if sum(inpolygon(px,py,px_bound,py_bound))==size(px_bound,1)
% % % %                         for q=1:size(px,1)
% % % %                             intensities=[intensities;qI2(uint16(py(q)),uint16(px(q)))];
% % % %                         end
% % %                         intensities=improfile(qI2,px,py);
% % % %                         hp=plot([px;px(1)],[py;py(1)],'c');drawnow;
% % %                         aspect = (max(px)-min(px))/(max(py)-min(py));
% % %                         isize=size(find(intensities>min(qI2(:))),1);
% % %                         if isize >= isize_max
% % % %                             px_max=px;
% % % %                             py_max=py;
% % %                         end
% % %                         if isize >= isize_ind && aspect >= set_aspect
% % %                             px_ind=px;
% % %                             py_ind=py;
% % %                             isize_ind=isize;    
% % %                         end
% % % %                         delete(hp);
% % %                     end
% % %                 end
% % %             end
% % %         end 
% % %     end
    if isempty(px_max) && isempty(py_max)
        px_max=px_ind;
        py_max=py_ind;
    end
      disp('Completed part 1');
    px_max=flip(px_max);
    py_max=flip(py_max);
    px_orig=px_max;py_orig=py_max;
    
    px_min=px_orig;
    py_min=py_orig;
    cent=[mean(px_min),mean(py_min)];
    uqI2=sort(unique(qI2));
    for p=1:size(px_min,1)
        [ix iy c]=improfile(qI2,linspace(px_min(p),cent(1,1)),linspace(py_min(p),cent(1,2)));
%         idx=find(c==min(c));
        idx=find(c<=uqI2(1));
        if isempty(idx)
        else
%             if idx(1) > 1
%                 px_min(p)=ix(idx(1)-1);
%                 py_min(p)=iy(idx(1)-1);
%             else
                px_min(p)=ix(idx(1));
                py_min(p)=iy(idx(1));
%             end
        end
    end
    disp('Completed part 2');
    temp = (max(px_max)-min(px_max))/(max(py_max)-min(py_max));
    if temp > 0 && temp < 1.2
%         set_aspect = temp;
    end
    cent=[mean(px_max), mean(py_max)];
    otsu_range=unique(qI2(:));
    for p=1:size(px_max,1)
        changed=0;
        or=0;
        while changed == 0
            or=or+1;
            if or > 4 % == size(otsu_range,1)
                break;
            end
            ix=px_max(p);
            iy=py_max(p);
            old_range=qI2(uint16(iy),uint16(ix));
            for del=1:30
                ix=(px_max(p)-cent(1,1))*(1+.05*del)+cent(1,1);
                iy=(py_max(p)-cent(1,2))*(1+.05*del)+cent(1,2);
                if changed==0 && inpolygon(ix,iy,px_bound,py_bound)
                    if iy <= size(qI2,1) && qI2(uint16(iy),uint16(ix)) == otsu_range(or)
%                         if or >1 && otsu_range(or) == old_range
%                         else
                            
                            if  p>1 && sqrt((px_max(p-1)-ix).^2+(py_max(p-1)-iy).^2) > 5
                            else
                                px_max(p)=ix;
                                py_max(p)=iy;
                                
                        changed=1;
                            end
                            
%                         end
                        
                        old_range=otsu_range(or) ;
                    end
                end
            end
        end
    end
    disp('Completed part 3');
    new_endo=[px_min';py_min'];
    new_epi=[px_max';py_max'];
    val_ind = zeros(size(px_min,1),2);
    for ii=1:size(px_min)
            [val_ind(ii,1),val_ind(ii,2)]=min((px_min(ii)-px_max(:)).^2+(py_min(ii)-py_max(:)).^2);
    end
    mean_val_ind=mean(val_ind(:,1));
    i_end=round(.5*size(px_min,1));
    for ii=1:i_end
        if (px_min(ii)-px_max(val_ind(ii,2)))^2+(py_min(ii)-py_max(val_ind(ii,2)))^2 > mean_val_ind
            ratio=sqrt(mean_val_ind/val_ind(ii,1));
% %             px_min(ii)=px_max(ii)-ratio*((px_max(ii)-px_min(ii)));
% %             py_min(ii)=py_max(ii)-ratio*((py_max(ii)-py_min(ii)));
                        px_min(ii)=px_max(val_ind(ii,2))-ratio*((px_max(val_ind(ii,2))-px_min(ii)));
            py_min(ii)=py_max(val_ind(ii,2))-ratio*((py_max(val_ind(ii,2))-py_min(ii)));
        end
    end
    disp('Completed part 4');
%     plot(px_orig,py_orig,'g.-')
%     plot(px_max,py_max,'m+')
    
    xyz=[px_max,py_max]';
    pts=my_fnplt(cscvn(xyz(:,[1:end 1])),'m-.',1.5);
%     plot(pts(1,:),pts(2,:),'r');
    epi0=pts';
    [z, a, b, alpha] = fitellipse(epi0,'linear','constraint','bookstein');
    X=plotellipse(z, a, b, alpha);
    epi0=Closest(epi0,X');
    
%     xyz=[px_min,py_min]';
%     pts=my_fnplt(cscvn(xyz(:,[1:end 1])),'m-.',1.5);
%     endo0=pts';
    endo0=[px_min,py_min];
    [z, a, b, alpha] = fitellipse(endo0);%',nonlinear','constraint','trace')
    X=plotellipse(z, a, b, alpha);
    endo0=Closest(endo0,X');

    yy=[];xx=[];
    x0=endo0(:,1);
    y0=endo0(:,2);
    sz=size(endo0,1)/12;
    endo_x00=decimate(x0,floor(sz),'FIR');
    endo_x0=endo_x00(1:size(endo_x00,1)-1);
    endo_y00=decimate(y0,floor(sz),'FIR');
    endo_y0=endo_y00(1:size(endo_y00,1)-1);
    
    
    yy=[];xx=[];
    x0=epi0(:,1);
    y0=epi0(:,2);
    sz=size(epi0,1)/12;
    epi_x00=decimate(x0,floor(sz),'FIR');
    epi_x0=epi_x00(1:size(epi_x00,1)-1);
    epi_y00=decimate(y0,floor(sz),'FIR');
    epi_y0=epi_y00(1:size(epi_y00,1)-1);
    
POLY_EDIT=1;
if POLY_EDIT && findmyo==1
%     figure;
%     imagesc(qI2, [brightness*min(I2(:)) brightness*max(I2(:))]),colormap gray;
    hold;
    xlim(gca,[min(epi0(:,1))-5,max(epi0(:,1))+5]);
    ylim(gca,[min(epi0(:,2))-5,max(epi0(:,2))+5]);
%     plot(px_min,py_min,'m-*');
%     plot(X(1,:),X(2,:),'y-*');
%     plot(X(1,:),X(2,:),'m*-');
    title('Adjust Endocardium');
    h=impoly(gca,[endo_x0,endo_y0]);
    raw_endo=wait(h);
    
    
%     plot(px_max,py_max,'m-*');
%     plot(epi0(:,1),epi0(:,2),'y-*');
    title('Adjust Epicardium');
    h=impoly(gca,[epi_x0,epi_y0]);
    raw_epi=wait(h);
    close 
    if SHOWFINAL
        I3=imcrop(dicomread(my_files(fnum).name),rect);
        I3=imfilter(I3,[5 5]);
        [N, edges]=histcounts(I3,10);
        I3(I3<=edges(3))=edges(3);
        figure
        imagesc(I3, [brightness*min(I3(:)) brightness*max(I3(:))]),colormap gray
        hold;
        plot(raw_epi(:,1),raw_epi(:,2),'*-r')
        plot(cent(:,1),cent(:,2),'*r')
        plot(raw_endo(:,1),raw_endo(:,2),'g*-')
    end
else
    raw_epi=[epi_x0,epi_y0];
    raw_endo=[endo_x0,endo_y0];
end
%
epi_ellipse= [transpose(raw_epi(:,1));transpose(raw_epi(:,2))];
endo_ellipse= [transpose(raw_endo(:,1));transpose(raw_endo(:,2))];

corners=repmat([0 0 0 0 0 0],1,100);
xyz=epi_ellipse;%[decimate(epi_ellipse(1,:)',5,9),decimate(epi_ellipse(2,:)',5,9)]';
sz=size(xyz,2);
cvec=corners(1:sz+1);
[pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
s = unique([linspace(0,pp.breaks(end),100),sparam]);
pts = fnval(pp,s);
epi_ellipse=pts;
sz=size(epi_ellipse(1,:),1);
epi_ellipse(1,sz+1)=epi_ellipse(1,1);
epi_ellipse(2,sz+1)=epi_ellipse(2,1);

xyz=endo_ellipse;%[decimate(endo_ellipse(1,:)',5,9),decimate(endo_ellipse(2,:)',5,9)]';
sz=size(xyz,2);
cvec=corners(1:sz+1);
[pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
s = unique([linspace(0,pp.breaks(end),100),sparam]);
pts = fnval(pp,s);
endo_ellipse=pts;
sz=size(endo_ellipse(1,:),1);
endo_ellipse(1,sz+1)=endo_ellipse(1,1);
endo_ellipse(2,sz+1)=endo_ellipse(2,1);
% 
% %     for bii=2:size(epi_ellipse,2)-1
% %             temp=((epi_ellipse(1,:)-epi_ellipse(1,bii)).^2+...
% %                 (epi_ellipse(2,:)-epi_ellipse(2,bii)).^2).^.5;
% %             [~,id]=sort(temp);
% %             u = [epi_ellipse(1,id(2))-epi_ellipse(1,bii), epi_ellipse(2,id(2))-epi_ellipse(2,bii)];
% %             v = [epi_ellipse(1,id(3))-epi_ellipse(1,bii), epi_ellipse(2,id(3))-epi_ellipse(2,bii)];
% %             Theta = acosd(dot(u,v)/(norm(u)*norm(v)));
% %             if Theta < 170
% %                 epi_ellipse(1,bii)=0.5*(epi_ellipse(1,id(2))+epi_ellipse(1,id(3)));
% %                 epi_ellipse(2,bii)=0.5*(epi_ellipse(2,id(2))+epi_ellipse(2,id(3)));
% %             end
% %     end
    epi_ellipse(:,size(epi_ellipse,2))=epi_ellipse(:,1);
% %     for bii=1:size(endo_ellipse,2)
% %         temp=((endo_ellipse(1,:)-endo_ellipse(1,bii)).^2+...
% %             (endo_ellipse(2,:)-endo_ellipse(2,bii)).^2).^.5;
% %         [~,id]=sort(temp);
% %         u = [endo_ellipse(1,id(2))-endo_ellipse(1,bii), endo_ellipse(2,id(2))-endo_ellipse(2,bii)];
% %         v = [endo_ellipse(1,id(3))-endo_ellipse(1,bii), endo_ellipse(2,id(3))-endo_ellipse(2,bii)];
% %         Theta = acosd(dot(u,v)/(norm(u)*norm(v)));
% %         if Theta < 170
% %             endo_ellipse(1,bii)=0.5*(endo_ellipse(1,id(2))+endo_ellipse(1,id(3)));
% %             endo_ellipse(2,bii)=0.5*(endo_ellipse(2,id(2))+endo_ellipse(2,id(3)));
% %         end
% %     end
    endo_ellipse(:,size(endo_ellipse,2))=endo_ellipse(:,1); 
        

    endo(bi).xi=transpose(endo_ellipse(1,:)); 
    endo(bi).yi=transpose(endo_ellipse(2,:));
    endo(bi).zi=ones(size(endo(bi).xi,1),1)*z_inc;
    epi(bi).xi=transpose(epi_ellipse(1,:)); 
    epi(bi).yi=transpose(epi_ellipse(2,:));
     epi(bi).zi=ones(size(epi(bi).xi,1),1)*z_inc;
    
    if findmyo==2
        epi_s(bi)=epi(bi);
        endo_s(bi)=endo(bi);
    else
        epi_d(bi)=epi(bi);
        endo_d(bi)=endo(bi);
    end
    if findmyo ==1
%         plot(epi(bi).xi,epi(bi).yi,'r*-');plot(endo(bi).xi,endo(bi).yi,'g*-');
    end

    end
    bi=bi+1;%close;
    
end



end


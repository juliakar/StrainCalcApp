%% This function puts Dicom magnitude and phase images into series folders 
%% Run this with the top directory
%% Example matlab command:
%% >>CreateDirs('C:\Images\Royal Brompton\DENSE_20150219\DENSE_STACK','C:\Images\Royal Brompton\DENSE_20150219\temp' )
%% The first argument is the top directory where it all exists, dir_arg
%% The second directory is where the series dirs should be created , new_dir
function [ output_args ] = CreateDirs( dir_arg,new_dir)
try 
if isdir(dir_arg)
    if isdir(new_dir)
        disp('The directories exists!');
        dirfiles = dir(dir_arg);
        for i= 1:size(dirfiles,1)
            dcm_fullname = strcat(dir_arg,'\',dirfiles(i).name); 
            try %see if the file is dicom otherwise pass
                dicom_info = dicominfo(dcm_fullname);
    %                 disp('This is a Dicom file: ');
    %                 disp (dirfiles(i).name);
                p=transpose(strfind(dirfiles(i).name,'.'));
                a2 = [];
                for p_i=1:size(p,1)-1
                            if str2num(dirfiles(i).name(p(p_i)+1:p(p_i+1)-1))
                                a2=[a2;str2num(dirfiles(i).name(p(p_i)+1:p(p_i+1)-1))];
                            end
                end
                series_desc=dicom_info.SeriesDescription;
                series_desc_str=strfind(series_desc,'_');
                dicom_info2=series_desc(series_desc_str(size(series_desc_str,2)):length(series_desc));
                dirname=strcat(dirfiles(i).name(1:p(1)-1),'_',num2str(a2(1)),'_',num2str(a2(size(a2,1)-1)),dicom_info2);
                dirname = strcat(new_dir,'\',dirname);
                if isdir(dirname)
                    else
                         mkdir(dirname);
                    end
                    if isdir(dirname)
                        copyfile(dcm_fullname,dirname);
                 end
            catch
%                 disp('This is not a Dicom file: ');
%                 disp (dirfiles(i).name);
            end
        end
   end
end
catch
end
end


%Add the path;
%Load all coronary files
LOAD_FILES=1; % change to 0 if already loaded
if LOAD_FILES
    clear all;
    mydir = 'coronaries\';%the dir of coronary dcm files
    files = dir(mydir);
    files = files(3:size(files,1),:);
    dcms=[];
    dcms_info =[];
    dcms = cell(size(files));
    dcms_info = cell(size(files));
    for i=1:size(files,1)
        myfile = strcat(mydir,files(i,1).name);
        interm = dicominfo(myfile);
        in = interm.InstanceNumber();
        dcms{in}= dicomread(myfile);
        dcms_info{in}=dicominfo(myfile);
    end
end

%specify a range of images over which to trace coronaries
range =31:5:55;
% display each image file and draw polygons around the same anatomical
% landmark (first practice with a bigger feature before coronaries)
% create a structure "post_pos" and store all coordinates in poly
num_arteries = 3;
post_pos = cell(size(range,2),num_arteries);
rects = cell(1,num_arteries);
p=1;
images_per_zoom = 1;
row_arrays = cell(size(range,2),1);
col_arrays = cell(size(range,2),1);
positions = cell(size(range,2),1);

%establish the 3 cropping rectangles
figure(11)
imagesc(dcms{range(1,1)}); colormap(gray);
for i=1:num_arteries
    [I, rect] = imcrop;
    rects{1,i} = rect; 
end
close(11);

% create polygon on 1st image on stack to be copied to other images-jk
% 062415
%inner for loop for each artery
img_per_zoom = images_per_zoom;
for i=1:num_arteries
    figure(11);
    I2 = imcrop(dcms{range(1,1)},rects{1,i});
    imagesc(I2);colormap(gray)
    h = impoly;
    post_pos{p,i} = wait(h);
    post_pos{p,i}(size(post_pos{p,i},1)+1,:)=post_pos{p,i}(1,:);% complete polygon
    close(11);
    rect = rects{1,i};
    top_left_x = rect(1,1);
    top_left_y = rect(1,2);
    image_set = post_pos{p,i};
    for m=1:size(image_set,1);
        orig_x = image_set(m,1);
        orig_y = image_set(m,2);
        new_x = top_left_x + orig_x;
        new_y = top_left_y + orig_y;
        post_pos{p,i}(m,1) = new_x;
        post_pos{p,i}(m,2) = new_y;
    end
end
img_per_zoom = img_per_zoom -1;
p=p+1;

% use polygon from 1st image and modify it on rest as anatomy changes
for k=range(1,2):range(1,2)+size(range,2)-2
    if img_per_zoom == 0
        figure(11)
        imagesc(dcms{k}); colormap(gray);
        for i=1:num_arteries
            [I, rect] = imcrop;
            rects{1,i} = rect; 
        end
        close(11);
        img_per_zoom = images_per_zoom;
    end


    %iterate through the arteries
    for i=1:num_arteries
        figure(11)
        I2 = imcrop(dcms{k},rects{1,i});
        imagesc(I2);colormap(gray)
        %before we display the previous set, we must adjust the old set
        %to the proper cropping. Since
        %the previous post_pos is already zoomed out, all we have to do is
        %zoom it back into the new frame.
        rect = rects{1,i};
        top_left_x = rect(1,1);
        top_left_y = rect(1,2);
        zoomed_in = post_pos{p-1,i};
        for m=1:size(zoomed_in,1)
            orig_x = zoomed_in(m,1);
            orig_y = zoomed_in(m,2);
            if (orig_x-top_left_x > 0) 
                new_x = orig_x - top_left_x;
            else
                new_x = 0;
            end
            if (orig_y-top_left_y > 0) 
                new_y = orig_y - top_left_y;
            else
                new_y = 0;
            end
            zoomed_in(m,1) = new_x;
            zoomed_in(m,2) = new_y;
        end
        h = impoly(gca, zoomed_in(1:size(post_pos{p-1,i})-1,:));
        post_pos{p,i} = wait(h);
        post_pos{p,i}(size(post_pos{p,i},1)+1,:)=post_pos{p,i}(1,:);% complete polygon
        close(11);
        %at the end of each drawing we convert the coordinates to the
        %'zoomed-out' coordinates. This allows us to accomodate to
        %different croppings.
        image_set = post_pos{p,i};
        for m=1:size(image_set,1);
            orig_x = image_set(m,1);
            orig_y = image_set(m,2);
            new_x = top_left_x + orig_x;
            new_y = top_left_y + orig_y;
            post_pos{p,i}(m,1) = new_x;
            post_pos{p,i}(m,2) = new_y;
        end
    end

    p=p+1;
    img_per_zoom = img_per_zoom - 1;
    
end

%find the proper coordinates of each point when not zoomed in.
%each point is simply shifted over and down by the coordinates of
%the top-left point of the zoomed in rectangle.
% temp = cell(size(range,2),num_arteries);
% 
% %i = which artery
% for i=1:num_arteries
%    rect = rects{1,i};
%    top_left_x = rect(1,1);
%    top_left_y = rect(1,2);
%    p=1;
%    %for each image.
%    for j=range
%        image_set = post_pos{p,i};
%        %for each point in an image.
%        for k=1:size(image_set,1);
%           orig_x = image_set(k,1);
%           orig_y = image_set(k,2);
%           new_x = top_left_x + orig_x;
%           new_y = top_left_y + orig_y;
%           post_pos{p,i}(k,1) = new_x;
%           post_pos{p,i}(k,2) = new_y;
%        end
%        p = p+1;
%    end    
% end

%DISPLAY OF THE 3D RESULTING

% transform all the landmark coordinates to 3D 
p=1;
% % store all the 3D landmark from each image in a structure called cor_3d
cor_3d=cell(size(range,2),num_arteries);
for k=range
    %rc = getfield(dcms_info{k}, 'ImageOrientationPatient');
    rc = dcms_info{k}.ImageOrientationPatient;
    C=-rc(4:6);
    R=rc(1:3);
    col_arrays{p,1} = C;
    row_arrays{p,1} = R;
    positions{p,1} = dcms_info{k}.ImagePositionPatient;
    N = cross(R,C);
    P = .1*dcms_info{k}.ImagePositionPatient;
    FR = [R,C,N,P;0 0 0 1];
    FR = transpose(FR);
    
    %for each artery
    for j=1:size(post_pos,2)
        xyz = zeros(size(post_pos{p,j},1),4);
        %for each point
        for i=1:size(post_pos{p,j},1)
            xyz(i,:)= [post_pos{p,j}(i,:) 0 1]*FR;
        end
        cor_3d{p,j} = xyz;
    end
    p=p+1;   
end

%plot 3d polygons-jk 062415
figure;hold;
for i = 1:size(cor_3d,1)
    for j= 1:size(cor_3d,2)
        line(cor_3d{i,j}(:,1),cor_3d{i,j}(:,2),cor_3d{i,j}(:,3));
    end
end

num_imgs = size(cor_3d,1);

%build the vertical lines.

% for each artery
for k=1:size(post_pos,2)
    num_points_per_image = size(cor_3d{1,k},1);
    %each artery will have a set number of points per image.
    %For each point, iterate through each image and add that point
    %'vert_coord'. Therefore vert_coord is an array of associated points
    %from different images.
    for i=1:num_points_per_image
        vert_coord = zeros(num_imgs,4);
        %for each image.
        for j=1:num_imgs
            cell = cor_3d{j,k};
            vert_coord(j,:) = cell(i,:);
        end
        line(vert_coord(:,1), vert_coord(:,2), vert_coord(:,3));
    end
end


%ASSURE THAT OUR LINE DRAWING PRODUCED VALID THINGS.
p=1;
for k=range
    figure;
    imagesc(dcms{k}); colormap(gray);
    hold;
    for i=1:3
        line(post_pos{p,i}(:,1), post_pos{p,i}(:,2)); 
    end
    p=p+1;
end


%FLIP THE Y's IN ORDER TO LINE UP WITH C++ VISUALIZING
p=1;
for i=range
    height = dcms_info{i}.Height();
    for j=1:size(post_pos,2)
        pos = post_pos{p,j};
        cor = cor_3d{p,j};
        for k=1:size(pos,1)
            pos(k,2) = double(height) - pos(k,2);
        end
        post_pos{p,j} = pos;
    end
    p = p+1;
end

fid = fopen('arteries.con', 'w');
p=1;
%each image (p and i both iterate through the images).
fprintf(fid,'ImageSetListWallsFile\n');
for i=range
    [pathstr,name,ext] = fileparts(dcms_info{i}.Filename);
    filename = strcat(name,ext);
    fprintf(fid,'ImageListWallsFile\n');
    fprintf(fid,'ShortAxis1\n');
    fprintf(fid,'#images: 1\n');
    fprintf(fid, '%s\n', filename);
    %each artery
    %note: col_arrays has already been negated before being sent over.
    %see line 177 for how col_arrays, row_arrays, and positions are filled.
    fprintf(fid,'orientation col_array: %d %d %d\n', col_arrays{p,1});
    fprintf(fid,'orientation row_array: %d %d %d\n', row_arrays{p,1});
    fprintf(fid,'position: %d %d %d\n', positions{p,1});
    fprintf(fid,'pixel spacing: %d %d\n', dcms_info{i}.PixelSpacing);
    fprintf(fid,'base rows: %d\n', dcms_info{i}.Rows);
    
    for j=1:size(post_pos,2)
        switch j
            case 1
                fprintf(fid,'posterior\n');
            case 2
                fprintf(fid,'LCD\n');
            case 3
                fprintf(fid,'circumflex\n');
        end
        
        fprintf(fid,'catmull_rom\n');
        fprintf(fid,'closed\n');
        pos = post_pos{p,j};
        fprintf(fid,'npts: %d\n', size(pos,1));
        for k=1:size(pos,1)
            
            fprintf(fid, '%d %f, %f\n', k-1, pos(k,1:2));
        end
        fprintf(fid,'\n');
    end
    fprintf(fid,'\n');
    p = p+1;
end

fclose(fid);

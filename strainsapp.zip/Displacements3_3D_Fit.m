function [ new_points,new_disps] = Displacements3_3D_Fit( filenames, sys_num)



FFIT=1;
num_tstamps=size(filenames,1);
disps=cell(size(filenames,1),1);
points=cell(size(filenames,1),1);
new_disps =cell(num_tstamps,1);
new_points=cell(num_tstamps,1);

if num_tstamps<3
    FFIT=0;
end

for i=1:size(filenames,1)
    try
         disp('The files being processed: ');
         disp(filenames(i).name);
        [disps{i,1}, points{i,1}]=ParseDispFile3D_2(filenames(i).name);%SYSYW12.sci %YSYW12.sci/
        catch exception
            return;
    end
end



sys_arr_sz=size(disps{sys_num,1},1);

for i=1:num_tstamps
    if i==sys_num
        new_disps{i,1}=disps{i,1};
        new_points{i,1} = points{i,1} ;
    else
        temp = zeros(sys_arr_sz,3);
        temp_disps = zeros(sys_arr_sz,3);
        for j=1:sys_arr_sz
            d1_arr=ones(size(points{i,1}));
            d1_arr(:,1) = points{sys_num,1}(j,1)*d1_arr(:,1) ;
            d1_arr(:,2) = points{sys_num,1}(j,2)*d1_arr(:,2) ;
            d1_arr(:,3) = points{sys_num,1}(j,3)*d1_arr(:,3) ;
            [val id]=sort(sqrt((points{i,1}(:,1)-d1_arr(:,1)).^2+(points{i,1}(:,2)-d1_arr(:,2)).^2 ...
            +(points{i,1}(:,3)-d1_arr(:,3)).^2));
            temp(j,:)=points{i,1}(id(1),:);
            temp_disps(j,:)=disps{i,1}(id(1),:);
        end
        new_disps{i,1}=temp_disps;
        new_points{i,1} = temp;
    end
end

if FFIT
    for j=1:sys_arr_sz %loop points
            p=[];
            for i=1:num_tstamps %loop timestamps
                p=[p;[new_disps{i,1}(j,1),new_disps{i,1}(j,2),new_disps{i,1}(j,3)]];
            end
            for k=1:3 
                z=transpose(1:num_tstamps+2);
                y=[0;p(:,k);0];
                [y2fa y2fb] = Fseries(z,y,2);
                yfit = Fseriesval(y2fa,y2fb,z);
                for i=1:num_tstamps
                  new_disps{i,1}(j,k)=yfit(i+1);
                end
            end
    end
end

PLOT=0;
if PLOT
    figure;hold;
    p=[];
    for j=1:20:250%loop points
    p=[];
        for i=1:num_tstamps %loop timestamps
            p=[p;[new_disps{i,1}(j,1),new_disps{i,1}(j,2),new_disps{i,1}(j,3)]];
        end
        plot(1:18,p);
        if j==1
            legend('x','y','z');
        end
    end
end
end
function [endo_d, epi_d,endo_s, epi_s, A_endo, A_epi, V] =GenVolumeWUnwrap2( dirname,all_names,my_names,rect,LOESS_PAN,endoRatio,flipped)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% % % num_slices=3;
% % % slice_offset=1;
warning off;
NUMPTS=30;
% my_names=cell(0);
addpath(genpath(dirname));

if isempty(my_names)
disp('No magnitude files found');
        return;
end

SEGDIV1=1;SEGDIV2=1;SEGDIV3=3;

fsegpair=cell(size(all_names,1),2);
sizediv=uint16(size(all_names,1)/3);
for i=1:size(all_names,1)
    fsegpair{i,2}=SEGDIV1;
    fsegpair{i,1}=all_names{i};
    if i>sizediv*2
        fsegpair{i,2}=SEGDIV3;
    end
%    curdir=all_names{i};
%     my_files=dir(strcat(topdir,curdir,'\'));
%     mynum=3;
%     dcminfo = dicominfo(my_files(mynum).name);
%     z_inc=dcminfo.SliceLocation;
end


num_slices=size(my_names,1);

dcmm=cell(num_slices);
dcmm2=cell(num_slices);
epi = struct('xi',[],'yi',[],'zi',[]);
endo = struct('xi',[],'yi',[],'zi',[]);

epi_d=epi;
epi_s=epi;
endo_d=endo;
endo_s=endo;

topdir=dirname;
addpath(genpath(topdir));


bi=1;
for i=1:size(my_names,1)
    fnum=5;
    curdir=my_names{i};
    ENDO_RATIO=endoRatio;
    ind=find(strcmp(curdir,fsegpair(1:size(fsegpair,1),1))==1);
    temp=fsegpair{ind,2};
    if temp > 1
        ENDO_RATIO=1.5*endoRatio;
    end
    disp('ENDO_RATIO: ');disp(ENDO_RATIO);
    DR_ELLIPSE=1;
    for findmyo = 1:2
        if findmyo==2
            fnum=12;
            DR_ELLIPSE=0;
        end
        
    my_files=dir(strcat(topdir,curdir,'\'));
%   rect=[45 45 55 55];
% fnum=5;
    dcminfo = dicominfo(my_files(fnum).name);
    z_inc=dcminfo.SliceLocation;
I20=imcrop(dicomread(my_files(fnum).name),rect);
    I2=imsharpen(I20,'Radius',3,'Amount',3);
    I2=imfilter(I2,[1 1]);
    [N, edges]=histcounts(I2,10);
    I2(I2<=edges(2))=edges(2);
thresh = multithresh(I2,6);
 valuesMax = [ thresh max(I2(:)) ];
    
 [qI2, index] = imquantize(I2, thresh, valuesMax);

if DR_ELLIPSE
    %close all;
    figure(1111)
    imagesc(I2),colormap gray;
    hold;
    himel=imellipse;vert=wait(himel);
    cent=[mean(vert(:,1)),mean(vert(:,2))];
    himel2=imellipse(gca,[cent(1,1)-0.25*(max(vert(:,1))-min(vert(:,1))),cent(1,2)-0.25*(max(vert(:,2))-min(vert(:,2))),...
    0.5*(max(vert(:,1))-min(vert(:,1))),0.5*(max(vert(:,2))-min(vert(:,2)))]);
    vert2=getVertices(himel2);
     close(1111);
    vert1=transpose(fit_ellipse(vert(:,1),vert(:,2),NUMPTS));
else
    cent=[mean(vert(:,1)),mean(vert(:,2))];
    vert1=transpose(fit_ellipse(vert(:,1),vert(:,2),NUMPTS));
    vert1(:,1)=0.95*(vert1(:,1)-cent(1,1)) +cent(1,1);
    vert1(:,2)=0.95*(vert1(:,2)-cent(1,2)) +cent(1,2);
    vert2=vert1;
    vert2(:,1)=0.45*(vert1(:,1)-cent(1,1)) +cent(1,1);
    vert2(:,2)=0.45*(vert1(:,2)-cent(1,2)) +cent(1,2);
end
        xi=vert1(:,1) ;
        yi=vert1(:,2);
%         xi2=vert2(:,1) ;
%         yi2=vert2(:,2);
        I_grad_master=cell(size(xi));
        bndry=zeros(size(vert1));
        cent = mean(vert1);
        for bii=1:size(xi,1)
            [min_d, ind]=min(hypot(xi(bii)-vert2(:,1),...
            yi(bii)-vert2(:,2)));
            [cx cy c]=improfile(qI2,[xi(bii);vert2(ind,1)],[yi(bii);vert2(ind,2)]);
%             [cx cy c]=improfile(I2,[xi(bii);cent(1,1)],[yi(bii);cent(1,2)]);
            c_ind=1;gradc=0;
            I_grad = zeros(size(c,1),1);
            I_grad(1)=0;
            I_grad(2)=0;
            for ci=1:size(c,1)-1
                if c(ci)>100000000%thresh(4)
                    I_grad(ci)=0;
                else
                    I_grad(ci)= (c(ci+1)-c(ci));
                end
            end
            I_grad(size(c,1))=-999;
            [gradc,c_ind]=findpeaks(I_grad);
            if isempty(gradc)
                [gradc,c_ind]=findpeaks(I_grad);
            end
            c_ind2=c_ind(gradc==max(gradc));
            if isempty(c_ind2)
                bndry(bii,1)=cx(1);bndry(bii,2)=cy(1);
            else
                c_ind2=c_ind2(1);
                bndry(bii,1)=cx(c_ind2);bndry(bii,2)=cy(c_ind2);
            end
           
            I_grad_master{bii}=[I_grad,cx,cy];
            %plot(I_grad_master{bii}(:,2),I_grad_master{bii}(:,3),'*','Color',[[0,0,0];cmap(c_ind,:)]);
%             colormap(jet);
%             scatter(I_grad_master{bii}(:,2),I_grad_master{bii}(:,3),10,[I_grad],'filled');
        end
        cent=[mean(bndry(:,1)),mean(bndry(:,2))];
        squared=((bndry(:,1)-cent(:,1)).^2+(bndry(:,2)-cent(:,2)).^2);
        szh=int16(size(vert1,1)/2);sz=int16(size(vert1,1));
        zscores0=(squared-mean(squared(szh+1:sz)))/std(squared(szh+1:sz));
        for i=1:szh%size(zscores0,1)
             if abs(zscores0(i))>1.25
                 bndry(i,1)=cent(1,1)+abs(bndry(sz-i,1)-cent(1,1))/1./abs(bndry(i,1)-cent(1,1))...
                     *(bndry(i,1)-cent(1,1));
                 bndry(i,2)=cent(1,2)+abs(bndry(sz-i,2)-cent(1,2))/1./abs(bndry(i,2)-cent(1,2))...
                     *(bndry(i,2)-cent(1,2));;
                 cent=[mean(bndry(:,1)),mean(bndry(:,2))];
             end
        end
bndry2=bndry;
% plot(bndry(:,1),bndry(:,2),'om-')
epi0=bndry2;

I3=imfilter(I20,[1 1]);
[N, edges]=histcounts(I3,10);
I3(I3<=edges(3))=edges(3);
thresh = multithresh(I3,6);
valuesMax = [ thresh max(I3(:)) ];
[qI3, index] = imquantize(I3, thresh, valuesMax);

cent=[mean(bndry(:,1)),mean(bndry(:,2))];
bndry=zeros(size(epi0));
I_grad_master2=cell(size(epi0,1),1);
for bii=1:size(epi0,1)
            [min_d, ind]=min(hypot(epi0(bii,1)-vert2(:,1),...
            epi0(bii,2)-vert2(:,2)));
            [cx cy c]=improfile(qI3,[epi0(bii,1);cent(1,1)],[epi0(bii,2);cent(1,2)]);
%             [cx cy c]=improfile(I3,[epi0(bii);cent(1,1)],[epi0(bii);cent(1,2)]);
            c_ind=1;gradc=0;
            I_grad = zeros(size(c,1),1);
            I_grad(1)=0;
            I_grad(2)=0;
            for ci=int16(ENDO_RATIO*size(c,1)):size(c,1)
%                 if c(ci)>thresh(1)
%                     I_grad(ci)= 0;
%                 else
                I_grad(ci)= c(ci)-c(ci-1);
%                 end
            end
            I_grad(size(c,1))=999;
            [gradc,c_ind]=findpeaks(-I_grad);
            if isempty(gradc)
                c_ind=prev_cind;
            else
                prev_cind=c_ind;
            end
            c_ind2=c_ind(1);
            bndry(bii,1)=cx(c_ind2);bndry(bii,2)=cy(c_ind2);
            opt_ind=0;
            for ii=c_ind2:size(c,1)-1
                if c(ii)==thresh(1) && opt_ind==0
                    
                    bndry(bii,1)=cx(ii);bndry(bii,2)=cy(ii);
                    opt_ind=ii;
                end
            end
            I_grad_master2{bii}=[-I_grad,cx,cy];
end
% plot(bndry(:,1),bndry(:,2),'o-g')

        cent=[mean(bndry(:,1)),mean(bndry(:,2))];
        squared=(bndry(:,1)-cent(:,1)).^2+(bndry(:,2)-cent(:,2)).^2;
                    zscores=(squared-...
                     mean(squared))/std(squared);
endo0=bndry;


POLY_EDIT=1;
if POLY_EDIT
    figure;
    imagesc(qI2),colormap gray;
    hold;
    plot(epi0(:,1),epi0(:,2),'r');
    plot(endo0(:,1),endo0(:,2),'g');
%     plot(raw_epi(:,1),raw_epi(:,2),'r');
%     plot(raw_endo(:,1),raw_endo(:,2),'g');
    h=impoly(gca,endo0);
    raw_endo=wait(h);
    h=impoly(gca,epi0);
    raw_epi=wait(h);
    close 
end
% close all;
figure
imagesc(I2),colormap gray
hold;
plot(raw_epi(:,1),raw_epi(:,2),'*-r')
plot(cent(:,1),cent(:,2),'*r')
plot(vert1(:,1),vert1(:,2),'co')
plot(vert2(:,1),vert2(:,2),'mo')
plot(raw_endo(:,1),raw_endo(:,2),'g*-')
% epi_ellipse= fit_ellipse(b_epi{bi-1}(:,1),b_epi{bi-1}(:,2),NUMPTS);
% endo_ellipse= fit_ellipse(b_endo{bi-1}(:,1),b_endo{bi-1}(:,2),NUMPTS);
epi_ellipse= [transpose(raw_epi(:,1));transpose(raw_epi(:,2))];
endo_ellipse= [transpose(raw_endo(:,1));transpose(raw_endo(:,2))];

% plot(epi_ellipse(1,:),epi_ellipse(2,:),'r-o')
% plot(endo_ellipse(1,:),endo_ellipse(2,:),'g-o')   

% LOESS_PAN=.5;
temp=fLOESS([transpose(endo_ellipse(1,:))], LOESS_PAN);
endo_ellipse(1,:)=transpose(temp(1:size(endo_ellipse,2)));
temp=fLOESS([transpose(endo_ellipse(2,:))], LOESS_PAN);
endo_ellipse(2,:)=transpose(temp(1:size(endo_ellipse,2)));
temp=fLOESS([transpose(epi_ellipse(1,:))], LOESS_PAN);
epi_ellipse(1,:)=transpose(temp(1:size(epi_ellipse,2)));
temp=fLOESS([transpose(epi_ellipse(2,:))], LOESS_PAN);
epi_ellipse(2,:)=transpose(temp(1:size(epi_ellipse,2)));
for bii=2:size(epi_ellipse,2)-1
        temp=((epi_ellipse(1,:)-epi_ellipse(1,bii)).^2+...
            (epi_ellipse(2,:)-epi_ellipse(2,bii)).^2).^.5;
        [~,id]=sort(temp);
        u = [epi_ellipse(1,id(2))-epi_ellipse(1,bii), epi_ellipse(2,id(2))-epi_ellipse(2,bii)];
        v = [epi_ellipse(1,id(3))-epi_ellipse(1,bii), epi_ellipse(2,id(3))-epi_ellipse(2,bii)];
        Theta = acosd(dot(u,v)/(norm(u)*norm(v)));
        if Theta < 170
            epi_ellipse(1,bii)=0.5*(epi_ellipse(1,id(2))+epi_ellipse(1,id(3)));
            epi_ellipse(2,bii)=0.5*(epi_ellipse(2,id(2))+epi_ellipse(2,id(3)));
        end
end
    epi_ellipse(:,size(epi_ellipse,2))=epi_ellipse(:,1);
    for bii=1:size(endo_ellipse,2)
        temp=((endo_ellipse(1,:)-endo_ellipse(1,bii)).^2+...
            (endo_ellipse(2,:)-endo_ellipse(2,bii)).^2).^.5;
        [~,id]=sort(temp);
        u = [endo_ellipse(1,id(2))-endo_ellipse(1,bii), endo_ellipse(2,id(2))-endo_ellipse(2,bii)];
        v = [endo_ellipse(1,id(3))-endo_ellipse(1,bii), endo_ellipse(2,id(3))-endo_ellipse(2,bii)];
        Theta = acosd(dot(u,v)/(norm(u)*norm(v)));
        if Theta < 170
            endo_ellipse(1,bii)=0.5*(endo_ellipse(1,id(2))+endo_ellipse(1,id(3)));
            endo_ellipse(2,bii)=0.5*(endo_ellipse(2,id(2))+endo_ellipse(2,id(3)));
        end
    end
       endo_ellipse(:,size(endo_ellipse,2))=endo_ellipse(:,1); 
        
plot(epi_ellipse(1,:),epi_ellipse(2,:),'r-o')
plot(endo_ellipse(1,:),endo_ellipse(2,:),'g-o')   
gen_epi{fnum}=epi_ellipse;
gen_endo{fnum}=endo_ellipse;

    endo(bi).xi=transpose(endo_ellipse(1,:)); 
    endo(bi).yi=transpose(endo_ellipse(2,:));
    endo(bi).zi=ones(size(endo(bi).xi,1),1)*z_inc;
    epi(bi).xi=transpose(epi_ellipse(1,:)); 
    epi(bi).yi=transpose(epi_ellipse(2,:));
     epi(bi).zi=ones(size(epi(bi).xi,1),1)*z_inc;
    
    if findmyo==2
        epi_s(bi)=epi(bi);
        endo_s(bi)=endo(bi);
    else
        epi_d(bi)=epi(bi);
        endo_d(bi)=endo(bi);
    end
    if findmyo ==1
        plot(epi(bi).xi,epi(bi).yi,'r*-');plot(endo(bi).xi,endo(bi).yi,'g*-');
    end

    end
    bi=bi+1;%close;
    
end

A_endo=[];
A_epi=[];
V=[];
% % % Acell = struct2cell(endo);
% % % sz = size(Acell);
% % % Acell = reshape(Acell, sz(1), []);      % Px(MxN)
% % % Acell = Acell'; 
% % % for i=1:size(endo,2)
% % % temp = cell2mat(Acell(i,3));
% % % temp=temp(1);
% % % Acell{i,3}=temp;
% % % end
% % % Acell = sortrows(Acell, 3);% (MxN)xP
% % % for i=1:size(endo,2)
% % % endo(i).xi=Acell{i,1};
% % % endo(i).yi=Acell{i,2};
% % % endo(i).zi=ones(size(Acell{i,1}))*Acell{i,3};
% % % end
% % % 
% % % Acell = struct2cell(epi);
% % % sz = size(Acell)
% % % Acell = reshape(Acell, sz(1), []);      % Px(MxN)
% % % Acell = Acell'; 
% % % for i=1:size(epi,2)
% % % temp = cell2mat(Acell(i,3));
% % % temp=temp(1);
% % % Acell{i,3}=temp;
% % % end
% % % Acell = sortrows(Acell, 3);% (MxN)xP
% % % for i=1:size(epi,2)
% % % epi(i).xi=Acell{i,1};
% % % epi(i).yi=Acell{i,2};
% % % epi(i).zi=ones(size(Acell{i,1}))*Acell{i,3};
% % % end
% % % 
% % % A_epi = ones(num_slices,1);
% % % A_endo = ones(num_slices,1);
% % % for i=1:num_slices
% % % A_endo(i)=polyarea(endo(i).xi,endo(i).yi);
% % % A_epi(i)=polyarea(epi(i).xi,epi(i).yi);
% % % end
% % % V=0;
% % % for i=1:num_slices-1
% % %     z1 = cell2mat(Acell(i,3));
% % %     z1=z1(1);
% % %     z2 = cell2mat(Acell(i+1,3));
% % %     z_inc =z1-z2(1);
% % %     V=V+0.5*abs(z_inc)*(A_epi(i)-A_endo(i)+A_epi(i+1)-A_endo(i+1));
% % % end

figure;hold
for bi=1:num_slices
    plot3(epi(bi).xi,epi(bi).yi,epi(bi).zi,'m*-');
    plot3(endo(bi).xi,endo(bi).yi,endo(bi).zi,'r*-');
end
view([1 1 1]);

% close(111);
% % if (xls_file)
% %     
% %     out_file=strcat(xls_file,'.xlsx');
% %     epi_array=[];
% %     for i=1:size(epi,2)
% %     sz = size(struct2array(epi(i)),1);
% %     epi_array=[epi_array;i*ones(sz,1),struct2array(epi(i))];
% %     end
% %     xlswrite(out_file,epi_array,'epi_array');
% %     endo_array=[];
% %     
% %     for i=1:size(endo,2)
% %     sz = size(struct2array(endo(i)),1);
% %     endo_array=[endo_array;i*ones(sz,1),struct2array(endo(i))];
% %     end;
% %     xlswrite(out_file,endo_array,'endo_array'); 
% %     
% %     xlswrite(out_file,A_endo,'A_endo'); 
% %     xlswrite(out_file,A_epi,'A_epi');  
% %      xlswrite(out_file,V,'Volume'); 
% %     
% % end

end


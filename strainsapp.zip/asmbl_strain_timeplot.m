%load('reg_avg_strns.mat')
%reg_avg_strns=reg_avg_strns_jk;
cn3_hf_size= ones(size(reg_avg_strns,1),1);
reg_avg_strns_mat_hf = cell2mat(reg_avg_strns);
reg_avg_p = zeros(size(cn3_hf_size,1),7);
%ROWN=1;
str='';
if ROWN==1
    str='basal-anteroseptal';
end
if ROWN==2
    str='basal-anterior';
end
if ROWN==3
    str='basal-anterolateral';
end
if ROWN==4
    str='basal-posterolateral';
end
if ROWN==5
    str='basal-posterior';
end
if ROWN==6
    str='basal-posteroseptal';
end

if ROWN==7
    str='mid-anteroseptal';
end
if ROWN==8
    str='mid-anterior';
end
if ROWN==9
    str='mid-anterolateral';
end
if ROWN==10
    str='mid-posterolateral';
end
if ROWN==11
    str='mid-posterior';
end
if ROWN==12
    str='mid-posteroseptal';
end
if ROWN==13
    str='apical-septal';
end
if ROWN==14
    str='apical-anterior';
end
if ROWN==15
    str='apical-lateral';
end
if ROWN==16
    str='apical-lateral';
end
if ROWN==17
    str='apical-posterior';
end
if ROWN==18
    str='apical-septal';
end
for i=1:size(cn3_hf_size,1)
for j=1:7
reg_avg_p(i,j)=reg_avg_strns_mat_hf((i-1)*18+ROWN,j);
end
end
BLEND=1;
if BLEND
for str_cols=1:3
    for i= ceil(size(cn3_hf_size,1)/2)+1:size(cn3_hf_size,1)
        if abs(reg_avg_p(i,str_cols)) > abs(reg_avg_p(size(cn3_hf_size,1)-i+1,str_cols))
            reg_avg_p(i,str_cols)=mean(reg_avg_p(size(cn3_hf_size,1)-i+1:size(cn3_hf_size,1)-i+3,str_cols));
            if i==size(cn3_hf_size,1)
                reg_avg_p(i,str_cols)=reg_avg_p(size(cn3_hf_size,1)-i+1,str_cols);
            end
        end
    end
end
end


colors=rand(1,3);
offset=0;
lev_str='basal-';
for str_cols=1:3
    if ROWN<=6
    elseif ROWN<=12
        lev_str='midwall-';
        offset=3;
    elseif ROWN<=18
        lev_str='apical-';
        offset=6;
    else
    end
        
    if ~ishandle(offset+str_cols) 
          figure(offset+str_cols); 
          hold;
    else
        figure(offset+str_cols);
    end
    TDIFF=32;
    z=[transpose(1:size(cn3_hf_size,1));size(cn3_hf_size,1)+1;size(cn3_hf_size,1)+2];
    y=[0;reg_avg_p(:,str_cols);0];
%     plot(1:TDIFF:TDIFF*(size(cn3_hf_size,1)+2),y,'ro-');
%     zfit = linspace(1,size(cn3_hf_size,1)+2,size(cn3_hf_size,1)+2);
%    pz = polyfit(z,y,2);
%    yfit = polyval(pz,zfit);
    [y2fa y2fb] = Fseries(z,y,2);
    yfit = Fseriesval(y2fa,y2fb,z);
    p_now=plot(1:TDIFF:TDIFF*(size(cn3_hf_size,1)+2),yfit,'sq-','color',colors);
    legend(p_now, str);
    legend('off');
    legend('show');
    if str_cols == 1
        str2=strcat('circ-','strain');
    end
    if str_cols == 2
        str2=strcat('long-','strain');
    end
    if str_cols == 3
        str2=strcat('radial-','strain');
    end
    
    title(strcat(lev_str,str2));
end
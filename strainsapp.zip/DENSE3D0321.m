function varargout = DENSE3D(varargin)
% DENSE3D MATLAB code for DENSE3D.fig
%      DENSE3D, by itself, creates a new DENSE3D or raises the existing
%      singleton*.
%
%      H = DENSE3D returns the handle to a new DENSE3D or the handle to
%      the existing singleton*.
%
%      DENSE3D('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DENSE3D.M with the given input arguments.
%
%      DENSE3D('Property','Value',...) creates a new DENSE3D or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DENSE3D_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DENSE3D_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DENSE3D

% Last Modified by GUIDE v2.5 20-Mar-2018 19:27:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DENSE3D_OpeningFcn, ...
                   'gui_OutputFcn',  @DENSE3D_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before DENSE3D is made visible.
function DENSE3D_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DENSE3D (see VARARGIN)

% Choose default command line output for DENSE3D
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% This sets up the initial plot - only do when we are invisible
% so window can get raised using DENSE3D.
% % % if strcmp(get(hObject,'Visible'),'off')
% % %     plot(rand(5));
% % % end
axes(handles.axes1);
plot(rand(5),'Parent',handles.axes1);
axes(handles.axes2);
plot(rand(5),'Parent',handles.axes2);


% UIWAIT makes DENSE3D wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DENSE3D_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in loaddir.
function loaddir_Callback(hObject, eventdata, handles)
% hObject    handle to loaddir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
alldirs=uigetdir('C:\Images\','Pick Top Directory');
if (alldirs)
else
    return;
end
if isdir(alldirs)
else
    return;
end
set(handles.filedir,'string',strcat(alldirs,'\'));
alldirs=dir(alldirs);
k=0;
allist=cell(1);
for i=1:size(alldirs,1)
a=strfind(alldirs(i).name,'AVEMAG');
    if isempty(a)
    else
        k=k+1;
        allist{k}=alldirs(i).name;
    end
end
set(handles.listbox1,'string',allist(1:k));
set(handles.listbox1,'Max',k,'Min',1);
set(handles.listboxphase,'string','');
set(handles.listboxmag,'string','');

%%
% % save_all_list(handles);
% 
% function save_all_list(handles)
newstr=get(handles.listbox1,'string');

filedir=get(handles.filedir,'string');

%% Setup available phases
STARTSET=3;
frames=cell(size(dir(strcat(filedir,'\',newstr{1})),1)-2-STARTSET,1);
for f =1:size(frames,1)
frames{f,1}=strcat('1-',num2str(f+STARTSET));
end
set(handles.FrameRange,'string',frames);
%%
addpath(genpath(filedir));
xdirs=dir(strcat(get(handles.filedir,'string'),'*X-ENCPHA*'));
ydirs=dir(strcat(get(handles.filedir,'string'),'*Y-ENCPHA*'));
zdirs=dir(strcat(get(handles.filedir,'string'),'*Z-ENCPHA*'));

pos=zeros(size(newstr));

for i=1:size(newstr,1)
        files=dir(strcat(filedir,newstr{i}));
        files=files(3);
        info = dicominfo(strcat(strcat(filedir,newstr{i}),'\',files.name));
        pos(i)=info.SliceLocation;
end

[p, id]=sort(pos);
pos=pos(id);
newstr=newstr(id);
set(handles.listbox1,'string',newstr);

k=1;
xdirsc=cell(size(newstr));
for i=1:size(newstr,1)
    for j=1:size(xdirs,1)
%         files=dir(strcat(filedir,newstr{i}));
%         files=files(3);
        files_x=dir(strcat(filedir,xdirs(j).name));
        files_x=files_x(3);
%         info = dicominfo(strcat(strcat(filedir,newstr{i}),'\',files.name));
        info_x = dicominfo(strcat(strcat(filedir,xdirs(j).name),'\',files_x.name));
        if pos(i) == info_x.SliceLocation
            xdirsc{k}=xdirs(j).name;
            disp('loading...');
            disp(xdirs(j).name);
            k=k+1;
        end
end
end

%newstr=p_str;
ydirsc=cell(size(newstr));
k=1;
for i=1:size(newstr,1)
    for j=1:size(ydirs,1)
%         files=dir(strcat(filedir,newstr{i}));
%         files=files(3);
        files_x=dir(strcat(filedir,ydirs(j).name));
        files_x=files_x(3);
%         info = dicominfo(strcat(strcat(filedir,newstr{i}),'\',files.name));
        info_x = dicominfo(strcat(strcat(filedir,ydirs(j).name),'\',files_x.name));
        if pos(i) == info_x.SliceLocation
            ydirsc{k}=ydirs(j).name;
            disp('loading...');
            disp(ydirs(j).name);
            k=k+1;
        end
end
end

%newstr=p_str;
zdirsc=cell(size(newstr));
k=1;
for i=1:size(newstr,1)
    for j=1:size(zdirs,1)
%         files=dir(strcat(filedir,newstr{i}));
%         files=files(3);
        files_x=dir(strcat(filedir,zdirs(j).name));
        files_x=files_x(3);
%         info = dicominfo(strcat(strcat(filedir,newstr{i}),'\',files.name));
        info_x = dicominfo(strcat(strcat(filedir,zdirs(j).name),'\',files_x.name));
        if pos(i) == info_x.SliceLocation
            zdirsc{k}=zdirs(j).name;
            disp('loading...');
            disp(zdirs(j).name);
            k=k+1;
        end
end
end
allist=cell(size(newstr,1),4);
k=1;
%p_val=transpose(p_val);
epi_d = struct('xi',[],'yi',[],'zi',[]);
endo_d = struct('xi',[],'yi',[],'zi',[]);
epi_s = struct('xi',[],'yi',[],'zi',[]);
endo_s = struct('xi',[],'yi',[],'zi',[]);
phases=cell(1,3);
mag=cell(1,1);
ph_names=cell(1,3);
masterset=struct('epi_d',[],'endo_d',[],'epi_s',[],'endo_s',[],'phases',[],'mag',[],...
    'unwrapped',[],'ph_names',[],'mag_names',[], 'gen_epi',[],'gen_endo',[],'gen_disp',[]);
for i=1:size(newstr,1)
    allist{i,1}=newstr{i,1};
    allist{i,2}=xdirsc{i,1};
    allist{i,3}=ydirsc{i,1};
    allist{i,4}=zdirsc{i,1};
    masterset(i).mag_names=allist{i,1};
    masterset(i).ph_names={allist{i,2:4}};
end
x=get(handles.FrameRange,'string');
curval=get(handles.FrameRange,'value');
x=x(curval);
[t,rem]=strtok(reverse(x),'-');
t=reverse(t);
x=str2num(t{1})+2;
START_FRAME=3;
END_FRAME=x;
setappdata(handles.loaddir,'masterset',masterset);
setappdata(handles.loaddir,'START_FRAME',START_FRAME);
setappdata(handles.loaddir,'END_FRAME',END_FRAME);
setappdata(handles.boundaries,'rect',[]);

save('allist.mat', 'allist');
[pathstr,name,ext] = fileparts(filedir(1:length(filedir)-1));
[pathstr,name,ext] = fileparts(pathstr);
set(handles.savefile,'string',name);


% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figure1)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                     ['Close ' get(handles.figure1,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.figure1)




% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listboxphase.
function listboxphase_Callback(hObject, eventdata, handles)
% hObject    handle to listboxphase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listboxphase contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listboxphase


% --- Executes during object creation, after setting all properties.
function listboxphase_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listboxphase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listboxmag.
function listboxmag_Callback(hObject, eventdata, handles)
% hObject    handle to listboxmag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listboxmag contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listboxmag


% --- Executes during object creation, after setting all properties.
function listboxmag_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listboxmag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phases.
function phases_Callback(hObject, eventdata, handles)
% hObject    handle to phases (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p_val=get(handles.listbox1,'value');
p_str=get(handles.listbox1,'string');
p_str=p_str(p_val);
p_str2=get(handles.listboxmag,'string');

    p_str=[p_str;p_str2];
p_str=unique(p_str);

set(handles.listboxmag,'string',p_str);
filedir=get(handles.filedir,'string');
addpath(genpath(filedir));

load allist;
newstr=p_str;
xdirsc=cell(size(newstr));
ydirsc=cell(size(newstr));
zdirsc=cell(size(newstr));

id=[];
for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = [id;find(not(cellfun('isempty', IndexC)))];
    
end
[id,id2]=sort(id,1);
set(handles.listboxmag,'string',newstr(id2));

xdirsc=allist(id,2);
ydirsc=allist(id,3);
zdirsc=allist(id,4);

mystring=cell(size(p_str,1),3);
%p_val=transpose(p_val);
for i=1:size(p_str)
    mystring{i,1}=xdirsc{i,1};
    mystring{i,2}=ydirsc{i,1};
    mystring{i,3}=zdirsc{i,1};
end
% guidata(handles.select,mystring);
mystring2=reshape(mystring,size(mystring,1)*size(mystring,2),1);
set(handles.listboxphase,'string',mystring2);
setappdata(handles.listboxphase,'mystring',mystring);
save('mystring.mat','mystring');


% --- Executes on button press in unwrap.
function unwrap_Callback(hObject, eventdata, handles)
% hObject    handle to unwrap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p_str=get(handles.listboxmag,'string');
addpath(genpath(get(handles.filedir,'string')));
axis_pt_z=size(p_str,1);
files=dir(strcat(get(handles.filedir,'string'),p_str{1},'\'));


filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');
imPhase=cell(size(p_str,1),3);
imMag=cell(size(p_str,1),1);
unwrapped=cell(size(p_str,1),3);
k=1;

rect=getappdata(handles.boundaries,'rect');
flipped=getappdata(handles.boundaries,'flipped');

masterset=getappdata(handles.loaddir,'masterset');
nonempty={masterset(1:size(masterset,2)).epi_d};
epi_d=([masterset(find(~cellfun(@isempty,nonempty))).epi_d]);
endo_d=([masterset(find(~cellfun(@isempty,nonempty))).endo_d]);
srch=get(handles.listboxmag,'string');
procset=[];
for m=1:size(masterset,2)
    for s=1:size(srch,1)
        if (strfind(string(masterset(1,m).mag_names),string(srch(s))))
%             if ~isempty(masterset(1,m).gen_epi) && ~isempty(masterset(1,m).gen_endo)...
%                     && ~isempty(masterset(1,m).gen_disp) && ~isempty(masterset(1,m).unwrapped)
                procset=[procset;m];
%             end
        end
     end
end
epi_d=[masterset(procset).epi_d];
endo_d=[masterset(procset).endo_d];
pm=[];
for i=1:size(p_str,1)
    if isempty(masterset(procset(i)).epi_d)
        pm2=[0 0 0 0];
    else
        pm2=polygeom(masterset(procset(i)).epi_d.xi,masterset(procset(i)).epi_d.yi);
    end
    pm=[pm;pm2(4)];
    
end
[pmax pmid]=max(pm);
files=dir(strcat(get(handles.filedir,'string'),p_str{pmid},'\'));
if flipped ==1
    dcm=flipud(dicomread(files(6).name));
else
    dcm=dicomread(files(6).name);
end
% figure;
im_m=imcrop(dcm,rect);
I1=imfilter(im_m,[7 7]);
[N, edges]=histcounts(I1,10);
I1=imsharpen(I1,'Radius',5,'Amount',1);
I1(I1<=edges(2))=edges(2);
imshow(I1,[0.5*min(I1(:)) 0.5*max(I1(:))], 'Parent', handles.axes1), colormap gray;
hold on;
plot(masterset(procset(pmid)).epi_d.xi,masterset(procset(pmid)).epi_d.yi,'r-');
plot(masterset(procset(pmid)).endo_d.xi,masterset(procset(pmid)).endo_d.yi,'g-');
axis_pts=zeros(2,2);
title('Select Upper Axis Point');
[axis_pts(1,1),axis_pts(1,2)] = ginput(1);
title('Select Lower Axis Point');
[axis_pts(2,1),axis_pts(2,2)] = ginput(1);
hold off;

masterset=getappdata(handles.loaddir,'masterset');
nonempty={masterset(1:size(masterset,2)).epi_d};
nonempty=find(~cellfun(@isempty,nonempty));

[x,y]=meshgrid(1:size(im_m,2),1:size(im_m,1));


savefile = strsplit(get(handles.filedir,'string'),'\');
idC=strfind(savefile,'_0');
ind = find(not(cellfun('isempty', idC)));
if isempty(ind)
    savefile=get(handles.savefile,'string');
else
    savefile=strcat(savefile{ind},'.mat');
end
ProcStrains3;

nonempty={masterset(1:size(masterset,2)).epi_d};
epi_d=([masterset(find(~cellfun(@isempty,nonempty))).epi_d]);
endo_d=([masterset(find(~cellfun(@isempty,nonempty))).endo_d]);
% epi_s=([masterset(find(~cellfun(@isempty,nonempty))).epi_s]);
% endo_s=([masterset(find(~cellfun(@isempty,nonempty))).endo_s]);
imMag=({masterset(find(~cellfun(@isempty,nonempty))).mag});
imMag=imMag';
imPhase=({masterset(find(~cellfun(@isempty,nonempty))).phases});
imPhase=imPhase';
temp=cell(size(imPhase,1),3);
for t=1:size(imPhase,1)
    temp{t,1}=imPhase{t}{1};
    temp{t,2}=imPhase{t}{2};
    temp{t,3}=imPhase{t}{3};
end
imPhase=temp;
% % % imUnwrapped=({masterset(find(~cellfun(@isempty,nonempty))).unwrapped});
% % % imUnwrapped=imUnwrapped';
% % % temp=cell(size(imUnwrapped,1),3);
% % % for t=1:size(imUnwrapped,1)
% % %     temp{t,1}=imUnwrapped{t}{1};
% % %     temp{t,2}=imUnwrapped{t}{2};
% % %     temp{t,3}=imUnwrapped{t}{3};
% % % end
% % % imUnwrapped=temp;
mystring=({masterset(find(~cellfun(@isempty,nonempty))).ph_names});
mystring=mystring';
temp=cell(size(mystring,1),3);
for t=1:size(mystring,1)
    temp{t,1}=mystring{t}{1};
    temp{t,2}=mystring{t}{2};
    temp{t,3}=mystring{t}{3};
end
mystring=temp;
save(savefile, 'masterset','x','y','endo_d','epi_d','imMag','imPhase','filedir', 'mystring','rect','axis_pts');

%proofDENSE3D;
disp('Strains done');


function savefile_Callback(hObject, eventdata, handles)
% hObject    handle to savefile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of savefile as text
%        str2double(get(hObject,'String')) returns contents of savefile as a double


% --- Executes during object creation, after setting all properties.
function savefile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to savefile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in remove.
function remove_Callback(hObject, eventdata, handles)
% hObject    handle to remove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p_val=get(handles.listboxmag,'value');
p_str=get(handles.listboxmag,'string');
%p_val=setdiff(1:size(p_str,1),p_val);
% p_str=p_str(p_val);

p_str(p_val)=[];

Val=p_val-1;
if Val < 1 
    Val =1;
end
set(handles.listboxmag,'string',p_str,'value',Val);
filedir=get(handles.filedir,'string');
addpath(genpath(filedir));

load allist;
newstr=p_str;
xdirsc=cell(size(newstr));
ydirsc=cell(size(newstr));
zdirsc=cell(size(newstr));

for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = find(not(cellfun('isempty', IndexC)));
    xdirsc{i}=allist{id,2};
    ydirsc{i}=allist{id,3};
    zdirsc{i}=allist{id,4};
end
id=[];
for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = [id;find(not(cellfun('isempty', IndexC)))];
    
end
[id,id2]=sort(id,1);
set(handles.listboxmag,'string',newstr(id2));

mystring=cell(size(p_str,1),3);
for i=1:size(p_str)
    mystring{i,1}=xdirsc{i,1};
    mystring{i,2}=ydirsc{i,1};
    mystring{i,3}=zdirsc{i,1};
end
% guidata(handles.select,mystring);
mystring2=reshape(mystring,size(mystring,1)*size(mystring,2),1);
set(handles.listboxphase,'string',mystring2);
setappdata(handles.listboxphase,'mystring',mystring);
save('mystring.mat','mystring');


% --- Executes on button press in show.
function show_Callback(hObject, eventdata, handles)
% hObject    handle to show (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
slider1_Callback(hObject, eventdata, handles);
% % % p_val=get(handles.listboxmag,'value');
% % % p_str=get(handles.listboxmag,'string');
% % % p_str=p_str(p_val);
% % % files=dir(strcat(get(handles.filedir,'string'),p_str{1},'\'));
% % % dcm=dicomread(files(5).name);
% % % dcm2=imadjust(dcm);
% % % imshow(dcm2, 'Parent', handles.axes1);


% --- Executes when entered data in editable cell(s) in uitable2.
function uitable2_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to uitable2 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function uitable2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uitable2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in boundaries.
function boundaries_Callback(hObject, eventdata, handles)
% hObject    handle to boundaries (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p_str=get(handles.listboxmag,'string');
addpath(genpath(get(handles.filedir,'string')));
axis_pt_z=size(p_str,1);
files=dir(strcat(get(handles.filedir,'string'),p_str{1},'\'));
dcm=dicomread(files(5).name);

if isempty(getappdata(handles.boundaries,'rect'))
    flipped=0;
    figure;
    imagesc(dcm), colormap gray;
            QuestName=questdlg('Is Anterior-Posterior reversed?', ...
                             'Positioning','Yes', 'No','No');
            switch QuestName,
                 case 'Yes',
                    flipped=1;
                 case 'No',
                    flipped=0;
            end
    if flipped == 1
        close;
        dcm=flipud(dicomread(files(5).name));
        figure;
        imagesc(dcm), colormap gray;
        setappdata(handles.boundaries,'flipped',1);
    else
          setappdata(handles.boundaries,'flipped',0);
    end

    [im_m,rect]=imcrop;
    close;
    setappdata(handles.boundaries,'rect',rect);
else
    rect=getappdata(handles.boundaries,'rect');
    flipped=getappdata(handles.boundaries,'flipped');
end

filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');
masterset=getappdata(handles.loaddir,'masterset');
p_str2=cell(1,1);
numvec=[];
k=1;
for p=1:size(p_str,1)
    num=find(ismember({masterset(1:size(masterset,2)).mag_names},p_str{p})==1);
%     if isempty(masterset(num).epi_d)
        p_str2{k,1}=p_str{p};
        numvec=[numvec;num];
        k=k+1;
%     end
end
p_str2=get(handles.listboxmag,'string');
if isempty(p_str2{1,1})
else

    LOESS_PAN=0.18;
    endoRatio=0.2;
    [endo_d, epi_d] = GenVolumeWUnwrap3(filedir,p_str2,rect,LOESS_PAN,endoRatio,flipped);
    save('Init_BNDRYS','endo_d', 'epi_d');
    k=1;
    numvec=numvec';
    for n=numvec
        masterset(n).epi_d=epi_d(k);
        masterset(n).endo_d=endo_d(k);
        masterset(n).gen_epi{6}=[epi_d(k).xi,epi_d(k).yi]';
         masterset(n).gen_endo{6}=[endo_d(k).xi,endo_d(k).yi]';
%         masterset(n).epi_s=epi_s(k);
%         masterset(n).endo_s=endo_s(k);
        k=k+1;
    end
    setappdata(handles.loaddir,'masterset',masterset);
end


% --- Executes on button press in searchboundaries.
function searchboundaries_Callback(hObject, eventdata, handles)
% hObject    handle to searchboundaries (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%filedir=getappdata(handles.unwrap,'filedir');
addpath(genpath('geom2d'));
filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');

p_str=get(handles.listboxmag,'string');
p_val=get(handles.listboxmag,'value');
p_str=get(handles.listboxmag,'string');
% p_str=p_str(p_val);

LOESS_PAN=0.32;
rect=getappdata(handles.boundaries,'rect');
masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);
for nonempty=[find(nonempty_all> 0)]'
    inum=1;
epi_d=([masterset(nonempty).epi_d]);
endo_d=([masterset(nonempty).endo_d]);
epi_ellipse= transpose([epi_d((1)).xi,epi_d((1)).yi]);
endo_ellipse= transpose([endo_d((1)).xi,endo_d((1)).yi]);
cent=[mean(epi_ellipse(1,:)),mean(epi_ellipse(2,:))];
for ii=1:size(epi_ellipse,2)
     endo_ellipse(1,ii)=cent(1,1)+ (endo_ellipse(1,ii)-1*cent(1,1));
      endo_ellipse(2,ii)=cent(1,2)+ (endo_ellipse(2,ii)-1*cent(1,2));
%     
    epi_ellipse(1,ii)=cent(1,1)+ (epi_ellipse(1,ii)-1*cent(1,1));
     epi_ellipse(2,ii)=cent(1,2)+ (epi_ellipse(2,ii)-1*cent(1,2));
end

files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
phasex_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{1}));
phasey_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{2}));
phasez_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{3}));

stat= sprintf('Unwrapping for partition %d ...',nonempty);
    set(handles.edit2,'string',stat);drawnow;
unwrapped=cell(20,2);

x=get(handles.FrameRange,'string');
curval=get(handles.FrameRange,'value');
x=x(curval);
[t,rem]=strtok(reverse(x),'-');
t=reverse(t);
x=str2num(t{1})+2;
START_FRAME=3;
END_FRAME=x;
UNWRAP=1;
if UNWRAP
    xpoint1=0;
    ypoint1=0;
    xpoint2=0;
    ypoint2=0;
    xpoint3=0;
    ypoint3=0;
    for bi=START_FRAME:END_FRAME
        dcm=dicomread(files(bi).name);
        im_m=imcrop(dcm,rect);
        dcm=dicomread(phasex_f(bi).name);
        im_p=imcrop(dcm,rect);
        im_p1=im_p;
        if bi>START_FRAME
%             xpoint=xpoint1;
%             ypoint=ypoint1;
        end
        QualityGuidedUnwrap2DDENSE3D;
        if bi==START_FRAME
%             xpoint1=xpoint;
%             ypoint1=ypoint;
        end
        unwrapped{bi,1}=im_unwrapped;
        dcm=dicomread(phasey_f(bi).name);
        im_p=imcrop(dcm,rect);
        im_p2=im_p;
        if bi>START_FRAME
%             xpoint=xpoint2;
%             ypoint=ypoint2;
        end
        QualityGuidedUnwrap2DDENSE3D;
        if bi==START_FRAME
%             xpoint2=xpoint;
%             ypoint2=ypoint;
        end
        unwrapped{bi,2}=im_unwrapped;
        [im_x,im_y]=meshgrid(1:size(im_unwrapped,2),1:size(im_unwrapped,1));
        [in on]=inpolygon(im_x,im_y,epi_d(1).xi,epi_d(1).yi);
        [in2 on2]=inpolygon(im_x,im_y,endo_d(1).xi,endo_d(1).yi);
        in=in-in2;
        im_ux=unwrapped{bi,1};
        im_ux=mean(im_ux(in==1));
        im_uy=unwrapped{bi,2};
        im_uy=mean(im_uy(in==1));
        dmax=max(abs(im_uy),abs(im_ux));
        disp('ratio')
        ratio=max(abs(im_uy/im_ux),abs(im_ux/im_uy))
        if ratio > 40 && dmax > 4
%             unwrapped{bi,1}=unwrapped{bi-1,1};
%             unwrapped{bi,2}=unwrapped{bi-1,2};
        end
        dcm=dicomread(phasez_f(bi).name);
        im_p=imcrop(dcm,rect);
        im_p3=im_p;
        if bi>START_FRAME
%             xpoint=xpoint3;
%             ypoint=ypoint3;
        end
        QualityGuidedUnwrap2DDENSE3D;
        if bi==START_FRAME
%             xpoint3=xpoint;
%             ypoint3=ypoint;
        end
        unwrapped{bi,3}=im_unwrapped;
    end
end;
stat= sprintf('Unwrapping done for partition %d ...',nonempty);
    set(handles.edit2,'string',stat);
    drawnow;
info=dicominfo(files(3).name);
% % my_pix=info.PixelSpacing(1);
% % aff{i,1}=[info.PixelSpacing(1)*info.ImageOrientationPatient(rows),...
% %     info.PixelSpacing(1)*info.ImageOrientationPatient(cols),...
% %     -cross(info.ImageOrientationPatient(1:3),info.PixelSpacing(1)*info.ImageOrientationPatient(4:6)),...
% %     info.ImagePositionPatient(1:3)];
if findstr(info.Private_0051_100e,'Tra') ==1
    ORIENT_TCS = 1;
elseif findstr(info.Private_0051_100e,'Cor') ==1
    ORIENT_TCS = 2;
else
    ORIENT_TCS = 3;
end
  
% vidObj = VideoWriter('newcycle.avi');
% open(vidObj);
% axis tight
set(gca,'nextplot','replacechildren');

epi_ellipse=epi_ellipse(:,2:size(epi_ellipse,2)-1);
endo_ellipse=endo_ellipse(:,2:size(endo_ellipse,2)-1);
gen_epi=cell(20,1);
gen_endo=cell(20,1);
gen_disp=cell(20,1);
epi_orig=epi_ellipse;
endo_orig=endo_ellipse;
new_epi=epi_ellipse;;
new_endo=endo_ellipse;;
im_ux_in=[];
im_uy_in=[];

im_ux=zeros(int16(rect(3))+1,int16(rect(4))+1);
im_uy=zeros(int16(rect(3))+1,int16(rect(4))+1);
qI2=[];

SRC_PLOT=0;

for bi=START_FRAME:1:END_FRAME
    I2=imcrop(dicomread(files(bi).name),rect);
     I2=imfilter(I2,[7 7]);
    [N, edges]=histcounts(I2,10);
%      I2=locallapfilt(I2, .2,.25);
    I2=imsharpen(I2,'Radius',10,'Amount',1);
    I2(I2<=edges(3))=edges(3);
   
   
    thresh = multithresh(I2,10);
    valuesMax = [ thresh max(I2(:)) ];
    [qI2, index] = imquantize(I2, thresh, valuesMax);
if SRC_PLOT
    figure;
    imagesc(I2),colormap gray; axis tight
    hold;
end
    im_ux_old=im_ux;
    im_uy_old=im_uy;
    flipped=getappdata(handles.boundaries,'flipped');
    if ORIENT_TCS == 3
        im_ux=unwrapped{bi,2};
        im_uy=-unwrapped{bi,1};    
    elseif ORIENT_TCS == 2
        if flipped
            im_ux=unwrapped{bi,2};
            im_uy=-unwrapped{bi,1};
        else
            im_ux=unwrapped{bi,2};
            im_uy=unwrapped{bi,1};
        end
    else %ORIENT_TCS == 1
         im_ux=-unwrapped{bi,1};
        im_uy=unwrapped{bi,2};
    end
% %     im_ux=unwrapped{bi,1};%+unwrapped{4,1};
% %     im_uy=unwrapped{bi,2};%+unwrapped{4,2};
   
    if bi<=5
        im_ux=-.33*im_ux;
        im_uy=-.33*im_uy;
%         im_ux=.53*im_ux;
%         im_uy=.53*im_uy;
%         im_ux=.5*im_ux;
%         im_uy=.5*im_uy;
    else
        im_ux=.9*im_ux;
        im_uy=.99*im_uy;
%         im_ux=-.75*im_ux;
%         im_uy=-.75.*im_uy;
%         im_ux=-.9*im_ux;
%         im_uy=-.9*im_uy;
    end
    [x,y]=meshgrid(1:size(I2,2),1:size(I2,1));

    old_epi= [epi_ellipse(1,:);epi_ellipse(2,:)];
    old_endo= [endo_ellipse(1,:);endo_ellipse(2,:)];
    old_im_ux_in=im_ux_in;
    old_im_uy_in=im_uy_in;
    [inb onb]=inpolygon(x,y,epi_orig(1,:),epi_orig(2,:));
    [inb2 onb2]=inpolygon(x,y,old_endo(1,:),old_endo(2,:));
    inb=inb ;%-inb2;

    in=(inb+onb);in(in>=2)=1;
    x_in=x(in==1);y_in =y(in==1);
    im_ux_in=im_ux(in==1);im_uy_in=im_uy(in==1);
    
    old_im_ux_in=im_ux_old(in==1);old_im_uy_in=im_uy_old(in==1);
    if bi > 5
        ang=dot([-im_uy(in==1),im_ux(in==1)],[cent(1,1)-x(in==1),cent(1,2)-y(in==1)],2);
        ind=find(ang<-20);
        im_ux_in(ind)=0;im_uy_in(ind)=0;
        old_im_ux_in(ind)=0;old_im_uy_in(ind)=0;

        zscores=(im_uy_in-mean(im_uy_in))/std(im_uy_in);
        im_uy_in(find(abs(zscores)>=3))=0;
        zscores=(im_ux_in-mean(im_ux_in))/std(im_ux_in);
        im_ux_in(find(abs(zscores)>=3))=0;

        uy_0=find(im_uy_in==0);ux_0=find(im_ux_in==0);
        uxy_0=unique([uy_0;ux_0]);
        uxy_non0=setdiff(1:size(x_in,1),uxy_0);

        for ii=1:size(x_in,1)
        [val, ind]=sort((x_in(ii)-x_in(uxy_non0)).^2+(y_in(ii)-y_in(uxy_non0)).^2);
        im_ux_in(ii)=mean(im_ux_in(uxy_non0(ind(1:15))));
        im_uy_in(ii)=mean(im_uy_in(uxy_non0(ind(1:15))));
        old_im_ux_in(ii)=mean(old_im_ux_in(uxy_non0(ind(1:15))));
        old_im_uy_in(ii)=mean(old_im_uy_in(uxy_non0(ind(1:15))));
        end
    else
         for ii=1:size(x_in,1)
        [val, ind]=sort((x_in(ii)-x_in(:)).^2+(y_in(ii)-y_in(:)).^2);
        im_ux_in(ii)=mean(im_ux_in((ind(1:100))));
        im_uy_in(ii)=mean(im_uy_in((ind(1:100))));
        old_im_ux_in(ii)=mean(old_im_ux_in((ind(1:100))));
        old_im_uy_in(ii)=mean(old_im_uy_in((ind(1:100))));
        end
    end

% %     plot(epi_ellipse(1,:),epi_ellipse(2,:),'m-.')
% %     plot(endo_ellipse(1,:),endo_ellipse(2,:),'c-.')   

    for ii=1:size(epi_ellipse,2)
            [val, ind]=sort((epi_orig(1,ii)-x_in(:)).^2+(epi_orig(2,ii)-y_in(:)).^2);
            new_epi(1,ii)=epi_orig(1,ii)+im_ux_in(ind(1));
            new_epi(2,ii)=epi_orig(2,ii)+im_uy_in(ind(1));
    end
    for ii=1:size(endo_ellipse,2)
            [val, ind]=sort((endo_orig(1,ii)-x_in(:)).^2+(endo_orig(2,ii)-y_in(:)).^2);
            
                new_endo(1,ii)=endo_orig(1,ii)+1.*im_ux_in(ind(1));
            new_endo(2,ii)=endo_orig(2,ii)+1*im_uy_in(ind(1));
    end 
    
% %       plot(new_epi(1,:),new_epi(2,:),'m-s')
% %       plot(new_endo(1,:),new_endo(2,:),'-s', 'color',[.4 1 .1])   

    cent=[mean(transpose(endo_ellipse(1,:))),mean(transpose(endo_ellipse(2,:)))];
    for bii=1:size(endo_ellipse,2)
        if bi <= 5
            [cx cy c]=improfile(qI2,[.5*(1.9*endo_orig(1,bii)+0.1*new_epi(1,bii));1*new_endo(1,bii)],[0.5*(1.9*endo_orig(2,bii)+0.1*new_epi(2,bii));1*new_endo(2,bii)]);
        else
            [cx cy c]=improfile(qI2,[.5*(1.9*endo_orig(1,bii)+0.1*new_epi(1,bii));.75*cent(1,1)+.25*new_endo(1,bii)],[0.5*(1.9*endo_orig(2,bii)+0.1*new_epi(2,bii));.75*cent(1,2)+.25*new_endo(2,bii)]);
        end
        c_ind=0;
% % %     if bii==25
% % %                       plot(cx,cy,'c*');
% % %     end
        for ci=1:1:size(c,1)
            if c(ci) <= thresh(1) 
                 if c_ind==0
                    c_ind=ci;
                    if c_ind>1 %<size(c,1)
                        new_endo(1,bii)=0.5*(cx(c_ind)+cx(c_ind-1));
                        new_endo(2,bii)=0.5*(cy(c_ind)+cy(c_ind-1));
                    else
                        new_endo(1,bii)=cx(c_ind);
                        new_endo(2,bii)=cy(c_ind);
                    end
                 end
            end
        end
    end  
    
    for bii=2:size(epi_ellipse,2)
        if bi < 10
            [cx cy c]=improfile(qI2,[epi_orig(1,bii);1*(.75*old_endo(1,bii)+0.25*new_epi(1,bii))],[epi_orig(2,bii);1*(.75*old_endo(2,bii)+0.25*new_epi(2,bii))]);
        else
            [cx cy c]=improfile(qI2,[epi_orig(1,bii);1*(1*old_endo(1,bii)+0.*new_epi(1,bii))],[epi_orig(2,bii);1*(1*old_endo(2,bii)+0.*new_epi(2,bii))]);
        end
            c_ind=0;
        if bi==50
            disp('debug');
        end
        for ci=1:size(c,1)-1
                if c(ci) <=thresh(2) && c(ci)< c(ci+1)
%                     if c_ind==0
                            c_ind=ci;
                                new_epi(1,bii)=0.5*(cx(c_ind)+cx(c_ind));
                                new_epi(2,bii)=0.5*(cy(c_ind)+cy(c_ind));
                         
%                     end
                end
        end 
        if c_ind==0
            new_epi(1,bii)=0.5*(cx(1)+cx(1));
                                new_epi(2,bii)=0.5*(cy(1)+cy(1));
        end
            
    end  
    
    val_ind = zeros(size(new_endo));
    ind = zeros(size(new_endo));
    for ii=1:size(new_endo,2)
            [val_ind(1,ii),val_ind(2,ii)]=min((new_endo(1,ii)-new_epi(1,:)).^2+(new_endo(2,ii)-new_epi(2,:)).^2);
    end
    mean_val_ind=mean(val_ind(1,:));
    i_end=round(.5*size(new_endo,2));
    for ii=1:i_end
        if (new_endo(1,ii)-new_epi(1,val_ind(2,ii)))^2+(new_endo(2,ii)-new_epi(2,val_ind(2,ii)))^2 > mean_val_ind
            ratio=sqrt(mean_val_ind/val_ind(1,ii));
% %             new_endo(1,ii)=new_epi(1,ii)-ratio*((new_epi(1,ii)-new_endo(1,ii)));
% %             new_endo(2,ii)=new_epi(2,ii)-ratio*((new_epi(2,ii)-new_endo(2,ii)));
                        new_endo(1,ii)=new_epi(1,val_ind(2,ii))-ratio*((new_epi(1,val_ind(2,ii))-new_endo(1,ii)));
            new_endo(2,ii)=new_epi(2,val_ind(2,ii))-ratio*((new_epi(2,val_ind(2,ii))-new_endo(2,ii)));
        end
    end
%     if bi >3
    epi_ellipse=new_epi;
    endo_ellipse=new_endo;
%     end
    
% %       plot(new_epi(1,:),new_epi(2,:),'m-*')
% %       plot(new_endo(1,:),new_endo(2,:),'-*','color',[0.11 0.67 0.84])   

    [z, a, b, alpha] = fitellipse(epi_ellipse,'linear','constraint','trace')
    X=plotellipse(z, a, b, alpha);
% %     plot(epi_ellipse(1,:),epi_ellipse(2,:),'m-*');
% %     plot(X(1,:),X(2,:),'y-*');
    
    epi_ellipse=Closest(epi_ellipse',X');
    epi_ellipse=epi_ellipse';
    [val ids ]=(unique(mean(epi_ellipse)));
    ids=sort(ids);
%     epi_ellipse=[epi_ellipse(1,ids');epi_ellipse(2,ids')];
%     plot(epi_ellipse(1,:),epi_ellipse(2,:),'g-o');
    
    [z, a, b, alpha] = fitellipse(endo_ellipse,'linear','constraint','trace')
    X=plotellipse(z, a, b, alpha);
    if SRC_PLOT
    plot(endo_ellipse(1,:),endo_ellipse(2,:),'m-*');
     plot(X(1,:),X(2,:),'y-*');
    end
    endo_ellipse=Closest(endo_ellipse',X');
    endo_ellipse=endo_ellipse';
    [val ids ]=(unique(mean(endo_ellipse)));
    ids=sort(ids);
%     endo_ellipse=[endo_ellipse(1,ids');endo_ellipse(2,ids')];
    endo0=endo_ellipse';
    yy=[];xx=[];
    x0=endo0(:,1);
    y0=endo0(:,2);
    sz=floor(size(endo0,1)/8);
    new_sz=size(1:sz:size(x0,1),2);
    while new_sz > 8
        sz=sz+1;
        new_sz=size(1:floor(sz):size(x0,1),2);
    end
    endo_x0=x0(1:floor(sz):size(x0,1));
    endo_y0=y0(1:floor(sz):size(y0,1));
%     plot(endo_x0,endo_y0,'c*-');
    
    epi0=epi_ellipse';
    yy=[];xx=[];
    x0=epi0(:,1);
    y0=epi0(:,2);
    sz=floor(size(epi0,1)/8);
    new_sz=size(1:floor(sz):size(x0,1),2);
    while new_sz > 8
        sz=sz+1;
        new_sz=size(1:floor(sz):size(x0,1),2);
    end
    epi_x0=x0(1:floor(sz):size(x0,1));
    epi_y0=y0(1:floor(sz):size(y0,1));
  %     plot(epi_x0,epi_y0,'c*-'); 
  
    corners=repmat([0 0 0 0 0 0],1,100);
    xyz=[epi_x0';epi_y0'];%[decimate(epi_ellipse(1,:)',5,9),decimate(epi_ellipse(2,:)',5,9)]';
    sz=size(xyz,2);
    cvec=corners(1:sz+1);
    [pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
    s = unique([linspace(0,pp.breaks(end),100),sparam]);
    pts = fnval(pp,s);
    epi_ellipse=pts;

    sz=size(epi_ellipse(1,:),1);
%     epi_ellipse(1,sz+1)=epi_ellipse(1,1);
%     epi_ellipse(2,sz+1)=epi_ellipse(2,1);

    xyz=[endo_x0';endo_y0'];%[decimate(endo_ellipse(1,:)',5,9),decimate(endo_ellipse(2,:)',5,9)]';
    sz=size(xyz,2);
    cvec=corners(1:sz+1);
    [pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
    s = unique([linspace(0,pp.breaks(end),100),sparam]);
    pts = fnval(pp,s);
    endo_ellipse=pts;
    sz=size(endo_ellipse(1,:),1);
%     endo_ellipse(1,sz+1)=endo_ellipse(1,1);
%     endo_ellipse(2,sz+1)=endo_ellipse(2,1);
    
% % %     temp=fLOESS([transpose(endo_ellipse(1,:))], LOESS_PAN);
% % %     endo_ellipse(1,:)=transpose(temp(1:size(endo_ellipse,2)));
% % %     temp=fLOESS([transpose(endo_ellipse(2,:))], LOESS_PAN);
% % %     endo_ellipse(2,:)=transpose(temp(1:size(endo_ellipse,2)));
% % %     temp=fLOESS([transpose(epi_ellipse(1,:))], LOESS_PAN);
% % %     epi_ellipse(1,:)=transpose(temp(1:size(epi_ellipse,2)));
% % %     temp=fLOESS([transpose(epi_ellipse(2,:))], LOESS_PAN);
% % %     epi_ellipse(2,:)=transpose(temp(1:size(epi_ellipse,2)));
% % %     
    
     
%     for bii=1:size(epi_ellipse,2)
%         temp=((epi_ellipse(1,:)-epi_ellipse(1,bii)).^2+...
%             (epi_ellipse(2,:)-epi_ellipse(2,bii)).^2).^.5;
%         [~,id]=sort(temp);
%         u = [epi_ellipse(1,id(2))-epi_ellipse(1,bii), epi_ellipse(2,id(2))-epi_ellipse(2,bii)];
%         v = [epi_ellipse(1,id(3))-epi_ellipse(1,bii), epi_ellipse(2,id(3))-epi_ellipse(2,bii)];
%         Theta = acosd(dot(u,v)/(norm(u)*norm(v)));
%         if Theta < 150
%             epi_ellipse(1,bii)=0.5*(epi_ellipse(1,id(2))+epi_ellipse(1,id(3)));
%             epi_ellipse(2,bii)=0.5*(epi_ellipse(2,id(2))+epi_ellipse(2,id(3)));
%         end
%     end
%     for bii=1:size(endo_ellipse,2)
%         temp=((endo_ellipse(1,:)-endo_ellipse(1,bii)).^2+...
%             (endo_ellipse(2,:)-endo_ellipse(2,bii)).^2).^.5;
%         [~,id]=sort(temp);
%         u = [endo_ellipse(1,id(2))-endo_ellipse(1,bii), endo_ellipse(2,id(2))-endo_ellipse(2,bii)];
%         v = [endo_ellipse(1,id(3))-endo_ellipse(1,bii), endo_ellipse(2,id(3))-endo_ellipse(2,bii)];
%         Theta = acosd(dot(u,v)/(norm(u)*norm(v)));
%         if Theta < 150
%             endo_ellipse(1,bii)=0.5*(endo_ellipse(1,id(2))+endo_ellipse(1,id(3)));
%             endo_ellipse(2,bii)=0.5*(endo_ellipse(2,id(2))+endo_ellipse(2,id(3)));
%         end
%     end
 
    sz=size(endo_ellipse,2);
    endo_ellipse(:,sz)=endo_ellipse(:,1);
    sz=size(epi_ellipse,2);
    epi_ellipse(:,sz)=epi_ellipse(:,1);

     
%         endo_ellipse=fit_ellipse(endo_ellipse(1,:),endo_ellipse(2,:),size(endo_ellipse,2));
%          epi_ellipse=fit_ellipse(epi_ellipse(1,:),epi_ellipse(2,:),size(epi_ellipse,2));
    
    gen_epi{bi}=epi_ellipse;
    gen_endo{bi}=endo_ellipse;
    masterset=getappdata(handles.loaddir,'masterset');
%     masterset(nonempty).epi_s.xi=epi_ellipse(1,:)';
%     masterset(nonempty).epi_s.yi=epi_ellipse(2,:)';
%     masterset(nonempty).endo_s.xi=endo_ellipse(1,:)';
%     masterset(nonempty).endo_s.yi=endo_ellipse(2,:)';
    masterset(nonempty).mag=im_m;
    masterset(nonempty).phases={im_p1,im_p2,im_p3};
    masterset(nonempty).unwrapped=unwrapped;
    masterset(nonempty).gen_epi=gen_epi;
    masterset(nonempty).gen_endo=gen_endo;
    
    setappdata(handles.loaddir,'masterset',masterset);
if SRC_PLOT
    plot(epi_ellipse(1,:),epi_ellipse(2,:),'color',[1 0.2 0.1],'LineWidth',2)
    plot(endo_ellipse(1,:),endo_ellipse(2,:),'-','color',[.4 1 0],'LineWidth',2)
    plot(epi_orig(1,:),epi_orig(2,:),'-r','MarkerSize',3);
    plot(endo_orig(1,:),endo_orig(2,:),'g-','MarkerSize',3);
end
     if bi==3
         endo_orig=endo_ellipse;
         epi_orig=epi_ellipse;
    end
      
% %         plot(old_epi(1,:),old_epi(2,:),'m--')
% %         plot(old_endo(1,:),old_endo(2,:),'y--')
%         quiver(old_endo(1,:),old_endo(2,:),endo_ellipse(1,:)-old_endo(1,:),endo_ellipse(2,:)-old_endo(2,:),'Autoscale','off','Color',[.25 .75 .75]);
%         quiver(old_epi(1,:),old_epi(2,:),epi_ellipse(1,:)-old_epi(1,:),epi_ellipse(2,:)-old_epi(2,:),'Autoscale','off','Color',[.25 .75 .75]);
    [in on]=inpolygon(x_in,y_in,old_epi(1,:),old_epi(2,:));  
    if isempty(old_im_ux_in)
        im_ux_in2=im_ux_in(in==1);
        im_uy_in2=im_uy_in(in==1);
    else
        im_ux_in2=im_ux_in(in==1)-old_im_ux_in(in==1);
        im_uy_in2=im_uy_in(in==1)-old_im_uy_in(in==1);
    end
    TRIM_VEC=0;
    if TRIM_VEC
        [inb onb]=inpolygon(x_in,y_in,gen_endo{bi}(1,:),gen_endo{bi}(2,:));
        x_in(inb==1)=[];
        y_in(inb==1)=[];
        im_ux_in(inb==1)=[];
        im_uy_in(inb==1)=[];
        [inb onb]=inpolygon(x_in+1.*im_ux_in,y_in+1.*im_uy_in,gen_endo{bi}(1,:),gen_endo{bi}(2,:));
        for ii=1:size(inb,1)
            if inb(ii)==1
                inter=intersectLinePolygon([x_in(ii),y_in(ii),+1.*im_ux_in(ii),1.*im_uy_in(ii)],...
                   [transpose(gen_endo{bi}(1,:)),transpose(gen_endo{bi}(2,:))]);
               veclen=((inter(:,1)-x_in(ii)).^2+(inter(:,2)-y_in(ii)).^2).^5;
                [val ind]=min(veclen);
                if val < 0.2*((im_ux_in(ii).^2+im_uy_in(ii).^2).^.5)
                    im_uy_in(ii)=0;
                   im_ux_in(ii)=0;
                end
            end
        end
        if SRC_PLOT
        quiver(x_in,y_in,im_ux_in,im_uy_in,'Autoscale','off','color','c');
        end
         gen_disp{bi}=[ x_in,y_in,+im_ux_in,im_uy_in];
       masterset(nonempty).gen_disp=gen_disp;
       setappdata(handles.loaddir,'masterset',masterset);
    else
    % quiver(x_in,y_in,-im_uy_in,im_ux_in,'Autoscale','off');
        in=inpolygon(x_in+im_ux_in,y_in+im_uy_in,endo_ellipse(1,:),endo_ellipse(2,:)) + ...
            inpolygon(x_in,y_in,endo_ellipse(1,:),endo_ellipse(2,:));  ;  
        if SRC_PLOT
        quiver(x_in(in==0),y_in(in==0),+im_ux_in(in==0),im_uy_in(in==0),'Autoscale','off','Color','c','LineWidth',.005);
        end
        gen_disp{bi}=[ x_in(in==0),y_in(in==0),+im_ux_in(in==0),im_uy_in(in==0)];
       masterset(nonempty).gen_disp=gen_disp;
       setappdata(handles.loaddir,'masterset',masterset);
% quiver(x_in,y_in,+im_ux_in,im_uy_in,'Autoscale','off','Color','c','LineWidth',.005);
    end
    title(sprintf('After %d ms',(bi-3)*15+3))
    stat=    sprintf('Frame %d of %d done...',bi, END_FRAME);
    set(handles.edit2,'string',stat);
    drawnow;
%    saveas(gcf, strcat('Figs\','time-frame-',num2str(bi),'-name-',curdir), 'tif');
%     for t=1:7
%         currFrame = getframe;
%          writeVideo(vidObj,currFrame);
%     end
end
% close(vidObj);
stat= sprintf('Partition %d done...',nonempty);
    set(handles.edit2,'string',stat);
    drawnow;
end

% find axis point
p_str=get(handles.listboxmag,'string');
rect=getappdata(handles.boundaries,'rect');
flipped=getappdata(handles.boundaries,'flipped');
masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);
pm=[];
for ny=[find(nonempty_all> 0)]'
    pm2=polygeom(masterset(ny).epi_d.xi,masterset(ny).epi_d.yi);
    pm=[pm;pm2(4)];
    
end
[pmax pmid]=max(pm);

files=dir(strcat(get(handles.filedir,'string'),p_str{pmid},'\'));
if flipped ==1
    dcm=flipud(dicomread(files(6).name));
else
    dcm=dicomread(files(6).name);
end
AXIS_PTS=0;
if AXIS_PTS
    figure;
    im_axis=imcrop(dcm,rect);
    imagesc(im_axis), colormap gray;
    hold;
    base = [find(nonempty_all> 0)]';
    base=base(pmid);
    plot(masterset(base).epi_d.xi,masterset(base).epi_d.yi,'r-');
    plot(masterset(base).endo_d.xi,masterset(base).endo_d.yi,'g-');
    axis_pts=zeros(2,2);
    title('Select Upper Axis Point');
    [axis_pts(1,1),axis_pts(1,2)] = ginput(1);
    title('Select Lower Axis Point');
    [axis_pts(2,1),axis_pts(2,2)] = ginput(1);
    close;
end


% --- Executes on button press in plot3Dboundaries.
function plot3Dboundaries_Callback(hObject, eventdata, handles)
% hObject    handle to plot3Dboundaries (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% h=impoint(handles.axes2);
% h.addNewPositionCallback(@fcn) ;

masterset=getappdata(handles.loaddir,'masterset');
nonempty={masterset(1:size(masterset,2)).epi_d};
epi_d=([masterset(find(~cellfun(@isempty,nonempty))).epi_d]);
epi_d=epi_d';
endo_d=([masterset(find(~cellfun(@isempty,nonempty))).endo_d]);
endo_d=endo_d';
figure;hold
num_slices=size(epi_d,1);
for bi=1:num_slices
    plot3(epi_d(bi).xi,epi_d(bi).yi,epi_d(bi).zi,'m*-');
    plot3(endo_d(bi).xi,endo_d(bi).yi,endo_d(bi).zi,'r*-');
end
view([1 1 1]);


% --- Executes on button press in showstack.
function showstack_Callback(hObject, eventdata, handles)
% hObject    handle to showstack (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p_str=get(handles.listboxmag,'string');
p_str=flip(p_str);
%set(handles.listboxmag,'string',p_str);
filedir=get(handles.filedir,'string');
addpath(genpath(filedir));

load allist;
allist=flip(allist);
newstr=p_str;
xdirsc=cell(size(newstr));
ydirsc=cell(size(newstr));
zdirsc=cell(size(newstr));

for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = find(not(cellfun('isempty', IndexC)));
    xdirsc{i}=allist{id,2};
    ydirsc{i}=allist{id,3};
    zdirsc{i}=allist{id,4};
end
id=[];
for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = [id;find(not(cellfun('isempty', IndexC)))];
    
end
[id,id2]=sort(id,1);
set(handles.listboxmag,'string',newstr(id2));

mystring=cell(size(p_str,1),3);
for i=1:size(p_str)
    mystring{i,1}=xdirsc{i,1};
    mystring{i,2}=ydirsc{i,1};
    mystring{i,3}=zdirsc{i,1};
end
mystring2=reshape(mystring,size(mystring,1)*size(mystring,2),1);
set(handles.listboxphase,'string',mystring2);
setappdata(handles.listboxphase,'mystring',mystring);
save('mystring.mat','mystring');
save('allist.mat','allist');
p_str=get(handles.listbox1,'string');
p_str=flip(p_str);
set(handles.listbox1,'string',p_str);
masterset=getappdata(handles.loaddir,'masterset');
masterset=flip(masterset);
setappdata(handles.loaddir,'masterset',masterset);


% --- Executes on mouse press over axes background.
function axes2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

addpath(genpath('geom2d'));
filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');

p_str=get(handles.listboxmag,'string');
p_val=get(handles.listboxmag,'value');
p_str=p_str(p_val);

masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);
ax=(handles.axes2);
axes(ax);
xlim=ax.XLim;
ylim=ax.YLim;
for nonempty=[find(nonempty_all> 0)]'

files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
gen_epi=masterset(nonempty).gen_epi;
gen_endo=masterset(nonempty).gen_endo;
gen_disp=masterset(nonempty).gen_disp;
unwrapped=[(masterset(nonempty).unwrapped)];
sz=size(masterset(nonempty).mag);
if sz(1)==0
    sz=size(dicomread(files(3).name));
end
[x y]=meshgrid(1:sz(2),1:sz(1));
rect=getappdata(handles.boundaries,'rect');
if isempty(rect)
    rect = [0 0 sz(1) sz(2)];
end
if ylim(2)-ylim(1) <1.5
    xlim=[0.5 rect(3)];
    ylim=[0.5 rect(4)];
end

x=get(handles.FrameRange,'string');
curval=get(handles.FrameRange,'value');
x=x(curval);
[t,rem]=strtok(reverse(x),'-');
t=reverse(t);
x=str2num(t{1})+2;
START_FRAME=3;
END_FRAME=x;
if isempty(gen_epi)
else
    temp=find(~cellfun(@isempty,gen_epi));
    START_FRAME = temp(1);
    END_FRAME = temp(end);

    if END_FRAME-START_FRAME < 0
        return;
    end
end

sl=get(handles.slider1,'value');
sl=START_FRAME+round((END_FRAME-START_FRAME)*sl)
set(handles.slidertext,'string',num2str(sl));
info=dicominfo(files(3).name);
% % my_pix=info.PixelSpacing(1);
% % aff{i,1}=[info.PixelSpacing(1)*info.ImageOrientationPatient(rows),...
% %     info.PixelSpacing(1)*info.ImageOrientationPatient(cols),...
% %     -cross(info.ImageOrientationPatient(1:3),info.PixelSpacing(1)*info.ImageOrientationPatient(4:6)),...
% %     info.ImagePositionPatient(1:3)];
if findstr(info.Private_0051_100e,'Tra') ==1
    ORIENT_TCS = 1;
elseif findstr(info.Private_0051_100e,'Cor') ==1
    ORIENT_TCS = 2;
else
    ORIENT_TCS = 3;
end
  
%
% for bi=START_FRAME:1:END_FRAME
    for bi=sl
    I2=imcrop(dicomread(files(bi).name),rect);
    I1=imfilter(I2,[7 7]);
    [N, edges]=histcounts(I1,10);
    I1=imsharpen(I1,'Radius',5,'Amount',1);
   I1(I1<=edges(2))=edges(2);
   fac=0.95;

    display = get(handles.displaymenu,'value');
    if display==1
    
        h=imshow(I1, [fac*min(I1(:)) fac*max(I1(:))], 'Parent', handles.axes2);
    else
        if isempty(unwrapped)
            h=imshow(I1, [min(I1(:)) max(I1(:))], 'Parent', handles.axes2);
        else
            if isempty(gen_epi{bi})
                in = ones(size(masterset(nonempty).mag));
            else
                [in on]=inpolygon(x,y,gen_epi{bi}(1,:),gen_epi{bi}(2,:));
                [in2 on2]=inpolygon(x,y,gen_endo{bi}(1,:),gen_endo{bi}(2,:));
                in=in-in2;
            end
            flipped=getappdata(handles.boundaries,'flipped');
            if ORIENT_TCS == 3
                if display == 2
                    im_unwr=unwrapped{bi,2};
                elseif display==3
                    im_unwr=-unwrapped{bi,1};  
                else
                    im_unwr=unwrapped{bi,3};
                end
            elseif ORIENT_TCS == 2
                if flipped
                    im_ux=unwrapped{bi,2};
                    im_uy=-unwrapped{bi,1};
                else
                    im_ux=unwrapped{bi,2};
                    im_uy=unwrapped{bi,1};
                end
                if display == 2
                    im_unwr=im_ux;
                elseif display==3
                    im_unwr=im_uy;  
                else
                    im_unwr=unwrapped{bi,3};
                end
            else %ORIENT_TCS == 1
                 im_ux=-unwrapped{bi,1};
                im_uy=unwrapped{bi,2};
                if display == 2
                    im_unwr=im_ux;
                elseif display==3
                    im_unwr=im_uy;  
                else
                    im_unwr=unwrapped{bi,3};
                end
            end
            I1=im_unwr.*in;
%             I1(I1==0)=max(I1(:));
            h=imshow(I1, [-pi pi], 'Parent', handles.axes2);
            colormap gray; axis tight
        end
    end
    set(h, 'ButtonDownFcn', {@gcf_ButtonDownFc,'handles'});
    hold on;
    
    if isempty(gen_epi) || isempty(gen_epi{bi})
    else
        x_in=gen_disp{bi}(:,1);
        y_in=gen_disp{bi}(:,2);
        ux_in=gen_disp{bi}(:,3);
        uy_in=gen_disp{bi}(:,4);
        
        quiver(x_in,y_in,ux_in,uy_in,'Autoscale','off','Color','c','LineWidth',.005,'Parent',handles.axes2);
        plot(gen_epi{bi}(1,:),gen_epi{bi}(2,:),'r-','Parent',handles.axes2,'Tag','epi', 'LineWidth', 2);
        plot(gen_endo{bi}(1,:),gen_endo{bi}(2,:),'g-','Parent',handles.axes2,'Tag','endo', 'LineWidth', 2);
        x0=gen_epi{bi}(1,:);
        y0=gen_epi{bi}(2,:);
        sz=floor(size(x0,2)/8);
        new_sz=size(1:sz:size(x0,2),2);
        while new_sz > 8
            sz=sz+1;
            new_sz=size(1:floor(sz):size(x0,2),2);
        end
        x0=x0(1:sz:end);y0=y0(1:sz:end);
        plot(x0,y0,'ro','MarkerFaceColor','r','Parent',handles.axes2,'Tag','epi_mrkr');
        x0=gen_endo{bi}(1,:);
        y0=gen_endo{bi}(2,:);
        x0=x0(1:sz:end);y0=y0(1:sz:end);
        plot(x0,y0,'go','MarkerFaceColor','g','Parent',handles.axes2,'Tag','endo_mrkr');
        plot(masterset(nonempty).epi_d.xi,masterset(nonempty).epi_d.yi,'m','Parent',handles.axes2);
        plot(masterset(nonempty).endo_d.xi,masterset(nonempty).endo_d.yi,'m','Parent',handles.axes2);
    end
    hold off
    
    end
    if get(handles.zoompan,'Value') 
    else
%         set (gcf, 'WindowButtonMotionFcn', @mouseMove);
        h=get(gca,'Children');
        set(h, 'ButtonDownFcn', {@gcf_ButtonDownFcn});
%         set(gcf, 'WindowButtonUpFcn', {@gcf_ButtonUpFcn});
    end
if getappdata(handles.zoompan,'reset')
    setappdata(handles.zoompan,'reset',0);
else
set(ax,'XLim',xlim);
set(ax,'YLim',ylim);
end
% close(vidObj);
end

function gcf_ButtonDownFcn(hObject, eventdata)
C = get (gca, 'CurrentPoint')
fprintf('Point from button down is %d',C)
handles = guidata( ancestor(hObject, 'figure') );

setappdata(handles.axes2,'epi_mrkr',0);
setappdata(handles.axes2,'endo_mrkr',0);
    
p_str=get(handles.listboxmag,'string');
p_val=get(handles.listboxmag,'value');
p_str=p_str(p_val);

rect=getappdata(handles.boundaries,'rect');
masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);
nonempty=[find(nonempty_all> 0)]'

files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
gen_epi=masterset(nonempty).gen_epi;
gen_endo=masterset(nonempty).gen_endo;

temp=find(~cellfun(@isempty,gen_epi));
START_FRAME = temp(1);
END_FRAME = temp(end);

if END_FRAME-START_FRAME < 0
    return;
end

sl=get(handles.slider1,'value');
sl=START_FRAME+round((END_FRAME-START_FRAME)*sl);
x0=gen_epi{sl}(1,:)';
y0=gen_epi{sl}(2,:)';
sz=floor(size(x0,1)/8);
    new_sz=size(1:sz:size(x0,1),2);
    while new_sz > 8
        sz=sz+1;
        new_sz=size(1:floor(sz):size(x0,1),2);
    end
epi_x0=x0(1:floor(sz):size(x0,1));
epi_y0=y0(1:floor(sz):size(y0,1));
[va id]=min((epi_x0(:,1)-C(1,1)).^2+(epi_y0(:,1)-C(1,2)).^2);
  
h=get(gca,'Children');
val=0; id =0;
val2=0; id2=0;

for hi=1:size(h,1)
if strfind(h(hi).Tag,'epi_mrkr')
    [val,id]=min((C(1,1)-h(hi).XData(1,:)).^2+(C(1,2)-h(hi).YData(1,:)).^2);
end
if strfind(h(hi).Tag,'endo_mrkr')
    [val2,id2]=min((C(1,1)-h(hi).XData(1,:)).^2+(C(1,2)-h(hi).YData(1,:)).^2);
end

if val < val2
    setappdata(handles.axes2,'epi_mrkr',id);
else
    setappdata(handles.axes2,'endo_mrkr',id2);
end

end
if get(handles.zoompan,'Value') 
    else
        set (gcf, 'WindowButtonMotionFcn', @mouseMove);
        set(gcf, 'WindowButtonUpFcn', {@gcf_ButtonUpFcn});
    end

function mouseMove (hObject, eventdata)
C = get (gca, 'CurrentPoint');
% % fprintf('Point from button down is %d',C);
handles = guidata( ancestor(hObject, 'figure') );
h=get(gca,'Children');
del_hi=0;
del_hi2=0;

mrkr_num=getappdata(handles.axes2,'epi_mrkr');
if mrkr_num > 0
    for hi=1:size(h,1)
        if strfind(h(hi).Tag,'epi_mrkr')
            del_hi=hi;
        h(hi).XData(1,mrkr_num)=C(1,1); 
        h(hi).YData(1,mrkr_num)=C(1,2); 
        new_x=h(hi).XData;
        new_y=h(hi).YData;
        end
        if strfind(h(hi).Tag,'epi')
            del_hi2=hi;
        end
    end
    if del_hi > 0
    delete(h(del_hi));
    end
    if del_hi2 > 0
    delete(h(del_hi2));
    end

    corners=repmat([0 0 0 0 0 0],1,100);
    xyz=[new_x;new_y];%[decimate(epi_ellipse(1,:)',5,9),decimate(epi_ellipse(2,:)',5,9)]';
    sz=size(xyz,2);
    cvec=corners(1:sz);
    [pp sparam]=cscvn2(xyz(:,[1:end]),'periodic',cvec);
    s = unique([linspace(0,pp.breaks(end),100),sparam]);
    pts = fnval(pp,s);
    hold on
    plot(pts(1,:),pts(2,:),'r-','Parent',handles.axes2,'Tag','epi','LineWidth', 2);
    plot(new_x,new_y,'ro','MarkerFaceColor','r','Parent',handles.axes2,'Tag','epi_mrkr');
    hold off
end

mrkr_num=getappdata(handles.axes2,'endo_mrkr');
if mrkr_num > 0
    for hi=1:size(h,1)
        if strfind(h(hi).Tag,'endo_mrkr')
            del_hi=hi;
        h(hi).XData(1,mrkr_num)=C(1,1); 
        h(hi).YData(1,mrkr_num)=C(1,2); 
        new_x=h(hi).XData;
        new_y=h(hi).YData;
        end
        if strfind(h(hi).Tag,'endo')
            del_hi2=hi;
        end
    end
    if del_hi > 0
    delete(h(del_hi));
    end
    if del_hi2 > 0
    delete(h(del_hi2));
    end

    corners=repmat([0 0 0 0 0 0],1,100);
    xyz=[new_x;new_y];%[decimate(endo_ellipse(1,:)',5,9),decimate(endo_ellipse(2,:)',5,9)]';
    sz=size(xyz,2);
    cvec=corners(1:sz);
    [pp sparam]=cscvn2(xyz(:,[1:end]),'periodic',cvec);
    s = unique([linspace(0,pp.breaks(end),100),sparam]);
    pts = fnval(pp,s);
    hold on
    plot(pts(1,:),pts(2,:),'g-','Parent',handles.axes2,'Tag','endo', 'LineWidth', 2);
    plot(new_x,new_y,'go','MarkerFaceColor','g','Parent',handles.axes2,'Tag','endo_mrkr');
    hold off
end

function gcf_ButtonUpFcn(hObject, eventdata)
C = get (gca, 'CurrentPoint')
fprintf('Point from button down is %d',C)
handles = guidata( ancestor(hObject, 'figure') );

p_str=get(handles.listboxmag,'string');
p_val=get(handles.listboxmag,'value');
p_str=p_str(p_val);

rect=getappdata(handles.boundaries,'rect');
masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);
nonempty=[find(nonempty_all> 0)]'

files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
gen_epi=masterset(nonempty).gen_epi;
gen_endo=masterset(nonempty).gen_endo;

temp=find(~cellfun(@isempty,gen_epi));
START_FRAME = temp(1);
END_FRAME = temp(end);

if END_FRAME-START_FRAME < 0
    return;
end

sl=get(handles.slider1,'value');
sl=START_FRAME+round((END_FRAME-START_FRAME)*sl);
x0=gen_epi{sl}(1,:)';
y0=gen_epi{sl}(2,:)';
sz=floor(size(x0,1)/8);
    new_sz=size(1:sz:size(x0,1),2);
    while new_sz > 8
        sz=sz+1;
        new_sz=size(1:floor(sz):size(x0,1),2);
    end
epi_x0=x0(1:floor(sz):size(x0,1));
epi_y0=y0(1:floor(sz):size(y0,1));
[va id]=min((epi_x0(:,1)-C(1,1)).^2+(epi_y0(:,1)-C(1,2)).^2);
  
% corners=repmat([0 0 0 0 0 0],1,100);
% xyz=[epi_x0';epi_y0'];%[decimate(epi_ellipse(1,:)',5,9),decimate(epi_ellipse(2,:)',5,9)]';
% sz=size(xyz,2);
% cvec=corners(1:sz+1);
% [pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
% s = unique([linspace(0,pp.breaks(end),100),sparam]);
% pts = fnval(pp,s);
% epi_ellipse=pts;
h=get(gca,'Children');

for hi=1:size(h,1)
if strfind(h(hi).Tag,'epi')
    new_x=h(hi).XData;
    new_y=h(hi).YData;
    gen_epi{sl}=[new_x;new_y];
%     if sl==6
%         masterset(nonempty).epi_d.xi=new_x';
%         masterset(nonempty).epi_d.yi=new_y';
%     end
end
if strfind(h(hi).Tag,'endo')
    new_x=h(hi).XData;
    new_y=h(hi).YData;
    gen_endo{sl}=[new_x;new_y];
%     if sl==6
%         masterset(nonempty).endo_d.xi=new_x';
%         masterset(nonempty).endo_d.yi=new_y';
%     end
        
end
end
setappdata(handles.axes2,'epi_mrkr',0);
setappdata(handles.axes2,'endo_mrkr',0);

masterset(nonempty).gen_epi=gen_epi;
masterset(nonempty).gen_endo=gen_endo;
setappdata(handles.loaddir,'masterset',masterset);
h=get(gca,'Children');
set(h, 'ButtonDownFcn', {@gcf_ButtonDownFcn});

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDA
for s=0:.1:1
    tic;pause(.02);toc;
    set(handles.slider1,'value',s);
    slider1_Callback(hObject, eventdata, handles);
% hObject    handle to plot3Dboundaries (see GCBO)
end
return;


% --- Executes on selection change in displaymenu.
function displaymenu_Callback(hObject, eventdata, handles)
% hObject    handle to displaymenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% contents = cellstr(get(hObject,'String')) ;
% contents={get(hObject,'Value')} ;


% --- Executes during object creation, after setting all properties.
function displaymenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to displaymenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in zoompan.
function zoompan_Callback(hObject, eventdata, handles)
% hObject    handle to zoompan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: returns toggle state of zoompan
if get(hObject,'Value')
h=handles.axes2;
dragzoom(h);
else
    slider1_Callback(hObject, eventdata, handles);
end


% --- Executes during object creation, after setting all properties.
function zoompan_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zoompan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'Value',0) ;


% --- Executes on button press in zoomout.
function zoomout_Callback(hObject, eventdata, handles)
% hObject    handle to zoomout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.zoompan,'Value',0) ;
setappdata(handles.zoompan,'reset',1);
slider1_Callback(hObject, eventdata, handles);


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in FrameRange.
function FrameRange_Callback(hObject, eventdata, handles)
% hObject    handle to FrameRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns FrameRange contents as cell array
%        contents{get(hObject,'Value')} returns selected item from FrameRange
curval=get(hObject,'Value');


% --- Executes during object creation, after setting all properties.
function FrameRange_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FrameRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%earlier image
%dcm = dicomread('082714-001.MR.CCIR00500_CCIR-00534_PASQUE.0059.0005.2014.08.27.11.39.16.265625.2064107.IMA');
%later image
dcm = dicomread('082714-001.MR.CCIR00500_CCIR-00534_PASQUE.0059.0012.2014.08.27.11.39.16.265625.2064233.IMA');
%dcm = dicomread('090314-001.MR.CCIR-00600_CCIR-0679_PASQUE.0067.0004.2014.09.03.12.45.59.328125.2629379.IMA');
thresh0=0.2*max(max(dcm)); % old code
max_dcm = max(max(dcm));
%figure;imagesc(dcm)
%[dcm rect] = imcrop;
dcm=imcrop(dcm,rect);
close

figure;imagesc(dcm);hold
h = imellipse;
bndry_epi = wait(h);
h = imellipse;
bndry_endo = wait(h);
% close

bndry_epi = int16(bndry_epi);
bndry_endo = int16(bndry_endo);
t1=0.3*max(max(dcm));
t2=0.8*max(max(dcm));
thresh = dcm <t1;
dcm(thresh) = 0;
thresh = dcm >t2;
dcm(thresh) = 0;


[d1 d2] = size(dcm);
for i=1:d1
    for j=1:d2
        IN = inpolygon(j,i,double(bndry_epi(:,1)), double(bndry_epi(:,2)))...
            -inpolygon(j,i,double(bndry_endo(:,1)), double(bndry_endo(:,2)));
        if IN(1,1) <= 0
            dcm(i,j) = 0;%int16(1);
             
        end
    end
end
  
figure;imagesc(dcm);hold
plot(bndry_epi(:,1), bndry_epi(:,2), 'w-*');
plot(bndry_endo(:,1), bndry_endo(:,2), 'w-s');

ELLIPSE=0;
if ELLIPSE
%     figure;imagesc(dcm);hold
    % h = imline(gca,[]);
    h = imellipse;
    bndry_epi = wait(h);
    h = imellipse;
    bndry_endo = wait(h);
    % cent = int16(pos(1,:));%[25,18];
    %close
end

%dcm=dcm(50:80,50:80);
%cent = [25,18];
 
% rad =  [8.5, 5];
% rad(1) = 0.8*sqrt((pos(1,1)-pos(2,1)).^2+(pos(1,2)-pos(2,2)).^2);
% rad(2) = 0.6*rad(1);
%dcm(cent(2),cent(1)) = 3*max_dcm;
CONVOL=0;
if CONVOL
    maskX = [-1 0 1 ; -2 0 2; -1 0 1];
    maskY = [-1 -2 -1 ; 0 0 0 ; 1 2 1] ;
    resX = conv2(double(dcm), double(maskX));resY = conv2(double(dcm),double( maskY));
    mag = sqrt(resX.^2 + resY.^2);
    thresh = mag <thresh0;
    mag(thresh) = 0;


    [id1 id2 ] = find(mag<10);
    plot(id2,id1, 'k*');

    ids=[id2 id1];
    pol = zeros (360,2);
end
% figure;imagesc(mag);%hold;

% for a=1:7:360
% %     pol = zeros (360,2);
%     for i=1:5
%         r1=[int16((rad(1)+i*sqrt(.5))*cosd(a) + cent(1)),int16((rad(1)+i*sqrt(.5))*sind(a) + cent(2))];
%         ii=i+1;
%         r2=[int16((rad(1)+i*sqrt(.5))*cosd(a) + cent(1)),int16((rad(1)+i*sqrt(.5))*sind(a) + cent(2))];
%         if min(r2) > 0 %&& min(pol(a,:)) > 0
%             if r2(2) < size(mag,1) && r2(1) < size(mag,2) 
%                 if mag(r2(2), r2(1)) > 0 %mag(pol(a,2),pol(a,1))
%                     pol(a,:) = r2;
%                 else
%                  %pol(a,:) = [0,0];
%                 end
%             end
%         end
%     end
% 
% end
% 
% pol=int16(pol);
% 
% polf=pol;
% [b1 b2]= find(polf==0);
% polf(b1,:)=[];
% polf=unique(polf(:,:),'rows','stable');
% plot(polf(:,1), polf(:,2),'k.')
% 
% 
% pol = zeros (360,2);
% for a=1:7:360
% %     pol = zeros (360,2);
%     for i=1:5
%         r1=[int16((rad(2)+i*sqrt(.5))*cosd(a) + cent(1)),int16((rad(2)+i*sqrt(.5))*sind(a) + cent(2))];
%         ii=i+1;
%         r2=[int16((rad(2)+i*sqrt(.5))*cosd(a) + cent(1)),int16((rad(2)+i*sqrt(.5))*sind(a) + cent(2))];
%         if min(r2) > 0 %&& min(pol(a,:)) > 0
%             if r2(2) < size(mag,1) && r2(1) < size(mag,2) 
%                 if mag(r2(2), r2(1)) > thresh0%mag(pol(a,2),pol(a,1))
%                     pol(a,:) = r2;
%                 else
%                  %pol(a,:) = [0,0];
%                 end
%             end
%         end
%     end
% 
% end
% pol = int16(pol);
% polf2=pol;
% [b1 b2]= find(polf2==0);
% polf2(b1,:)=[];
% polf2=unique(polf2(:,:),'rows','stable');
% plot(polf2(:,1), polf2(:,2),'r.')




function [ ret_X ] = Closest( bndry, ellip )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
ret_X=bndry;
sz=size(bndry,1);
val=zeros(sz,1);
% % % id=zeros(sz,1);
% % % for i=1:sz
% % %     [val(i), id(i)]=min((bndry(i,1)-ellip(:,1)).^2+(bndry(i,2)-ellip(:,2)).^2);
% % % %     ret_X(i,:)=[(ellip(id,1)+bndry(i,1))/2,(ellip(id,2)+bndry(i,2))/2];
% % % end
% % % [val2 id2]=sort(val,'ascend');
% % % sz=floor(sz*.5);
% % % id2=id2(1:sz);
% % % id_other=setdiff(1:size(bndry,1),id2);
% % % ret_X(id_other,:)=ellip(id(id_other),:);
% % % end

xy=zeros(sz,2);
for i=1:sz
    [xy(i,:), val(i)]=distance2curve(ellip,bndry(i,:));
%     ret_X(i,:)=[(ellip(id,1)+bndry(i,1))/2,(ellip(id,2)+bndry(i,2))/2];
end
[val2 id2]=sort(val,'ascend');
sz=floor(sz*.15);
id2=id2(1:sz);
id_other=setdiff(1:size(bndry,1),id2);
ret_X(id_other,:)=xy(id_other,:);
end

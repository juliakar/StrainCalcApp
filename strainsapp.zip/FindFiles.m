function [ return_names ] = FindFiles( varargin )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% cn = FindFiles(3,'C:\Dense Publication III\Brian\DENSE Analysis',...
% 'C:\Dense Publication III\Kevin Kulshrestha\DENSE\HF MASS Displacements\',...
% 'C:\Dense Publication III\Danielle\DENSE\HF Mass Strains\');
MY_NORM='NORMAL';
maxsize = max(size(varargin));
return_names = [];
 if maxsize == 0
     return;
 end
dim = varargin{1};
if dim == 2
    dim = '2D';
elseif dim == 3
    dim = '3D';
else
   
    return;
end
common_names = cell(100,maxsize-1);
dirnames = varargin(2:maxsize);
dirnames = reshape(dirnames,maxsize-1,1);

pstrings = {'_disp';'_3Ddisp';'_3DDISP';';';'('};
k =1;
found=0;

%for l = 1:size(mdate)
%   found = 0;
for i = 1:size(dirnames,1)
    q=rdir([dirnames{i}, strcat('\**\*', dim, '\**\*DISP*.sci')]);
    p=rdir([dirnames{i}, strcat('\**\*DISP*',dim,'*.sci')]);
    q=[q;p];
    k=1;
    for j = 1:size(q,1)
       if (strfind(q(j).name, MY_NORM) )
     %f isempty(strfind(q(j).name, 'NORMAL') )    
            [a1 b1 c1] = fileparts(q(j).name);
            cur_date =[];
            a=[];
            disp(['searching..  ' q(j).name]);
            for l=1:size(pstrings,1)

                a=strfind(b1,pstrings{l});
                if isempty(a)
                %  elseif length(b1) >= a+6
                elseif length(b1) > a+6
                    cur_date = strcat(b1(a-2:a-1),b1(a+1:a+6));
                elseif length(b1) > 6 && isempty(cur_date) 
                    cur_date = strcat(b1(a-9:a-8),b1(a-6:a-1));
                end
                    if isempty (cur_date)
                     elseif str2num(cur_date(3:8)) < 123115 
                        common_names{k,i} = cur_date;%q(j).name; 
                        found = found+1;
                        cur_date = [];
                    end
             end
             if found > 0
                k=k+1;
             end
        end
    end
end
   
%end

cn2 = reshape(common_names, size(common_names,1)*size(common_names,2),1);
cn3=[];
ii=1;
for i =1:size(cn2,1)
    if isempty(cn2{i})
    else
        cn3{ii} = cn2{i};ii=ii+1;
    end
end
cn3 = reshape( cn3,max(size(cn3)),1);
cn3 = uniqueRowsCA(cn3) ;
return_names= cell(size(cn3,1),size(dirnames,1));


pstrings = {'_';';';'('};
%pstrings = {'_disp';'_3Ddisp';';';'('};

for i = 1:size(dirnames,1)
    q=rdir([dirnames{i}, strcat('\**\*', dim, '\**\*.sci')]);
    p=rdir([dirnames{i}, strcat('\**\*', dim,'*.sci')]);
    q=[q;p];
    for j = 1:size(q,1)
        [a1 b1 c1] = fileparts(q(j).name);
        for k=1:size(cn3,1)
            disp('sorting..')
             for l=1:size(pstrings,1)
                temp =char(strcat(cn3{k}(1:2),pstrings(l),cn3{k}(3:8)));
                    if isempty(strfind(b1,temp)) 
                    else
                        return_names{k,i} = strcat(b1, '.sci'); 
                    end
             end
         end
     end
end

% figure;
% idir='C:\My Publications\Dense Pub III\STS2015\ZscoreMaps\KK\';
% inames =  dir (strcat(idir, 'test*disp*.png'))
% strcat(idir,inames(1).name)
% for i=1:13
% fullname = strcat(idir,inames(i).name);
% 
% h=subplot(5,3,i);
% imshow(fullname);
% p=get(h, 'position');
% p(3) = p(3) + 0.05;
% set(h,'position',p);

 end
% 

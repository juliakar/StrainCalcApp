function [meanDiff,CR ,coef ] = BlandAltman(var1, var2, plotflag, ttl, subflag)
 
    %INPUTS: var1 and var2 - 1D or 2D arrays of the same size
    %Plotting plotflags 
        %%% 0 = no plot
        %%% 1 = plot data
        %%% 2 = data and CR lines
        %%% 3 = linear fit
    %
    %OUTPUTS:
    %%% means = the means
    %%% diffs = raw differences
    %%% meanDiff = mean difference
    %%% CR = the 2SD confidence limits
    %%% linfit params
    
    
    if (nargin<1)
      return;
    end
    
    %Reshape var1 and var2 incase it is a 2D array
    var1=reshape(var1, 1, size(var1,1)*size(var1,2));
    var2=reshape(var2, 1, size(var2,1)*size(var2,2));
    if nargin==2
        plotflag = 0;
    end
    
    means = mean([var1;var2]);
    diffs = var1-var2;
    
    MOVAVE=5;
    PARAM_B =1.5;
    MOVAVE_FAC=1/MOVAVE;

    diffs=transpose(diffs);
%     a=filter(MOVAVE_FAC*ones(MOVAVE,1),PARAM_B,[ diffs(:,1)]);
%     diffs(:,1) = a(1:size(diffs,1),1);
    diffs=transpose(diffs);
%     figure
%     normplot(diffs)
%     close
    meanDiff = mean(diffs);
    sdDiff = std(diffs);
    CR = [meanDiff + 1.96 * sdDiff, meanDiff - 1.96 * sdDiff]; %%95% confidence range
    
    linFit = polyfit(means,diffs,1); %%%work out the linear fit coefficients
    
    [coef ] = corr2(means, diffs);
    %%%plot results unless plotflag is 0
    if plotflag ~= 0
%         3D Plotting
        if (subflag==1)
            figure;
            subplot(3,1,1);
        elseif (subflag==2)
            subplot(3,1,2);
        elseif (subflag==3)
            subplot(3,1,3);
        end
%         2D Plotting
%         if (subflag==1)
%             figure;
%             subplot(2,1,1);
%         elseif (subflag==2)
%             subplot(2,1,2);
%         end
        plot(means,diffs,'bo','MarkerSize',3)
        hold on;
        plot_rng = min(min(var1(:)),min(var2(:)))-0.1:.01:max(max(var1(:)),max(var2(:)))+.1;
        if plotflag > 1
            %plot(means, ones(1,length(means)).*CR(1),'b-'); %%%plot the upper CR
            plot(plot_rng, ones(1,length(plot_rng)).*CR(1),'b-'); %%%plot the upper CR
            plot(plot_rng, ones(1,length(plot_rng)).*CR(2),'b-'); %%%plot the lower CR
            plot(plot_rng, ones(1,length(plot_rng))*meanDiff,'r'); %%%plot zero
        end
        if plotflag > 2
            plot(means, means.*linFit(1)+linFit(2),'r-'); %%%plot the linear fit
        end
        if ttl
            title(ttl);
        end
        ylabel('\epsilon diff. (mm/mm)');
        xlabel('mean \epsilon (mm/mm)');
    end
    
end 
 


TEST_ALL=0;
% % 
% % 
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR10_0047    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR11_0051    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR12_0055    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR13_0059    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR14_0063    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR15_0067    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR16_0071    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR17_0075    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR18_0079    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR19_0083    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR4_0023     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR5_0027     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR6_0031     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR7_0035     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR8_0039     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR9_0043  
% % 

mystr='SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR9_0043';
mydir = dir( strcat('C:\Images\JK_082714_001\all_images\',mystr));

pic=[];
for i=1:size(mydir,1)
    if ~isdir(mydir(i).name)
        pic=[pic;mydir(i).name];
    end
end

PAPPILARIES = 0;
FAC = 1.;
if EARLIER
    dcm = dicomread(pic(3,:));
    outdir =strcat('C:\matlab\',mystr);
    if exist( outdir, 'dir')
        dos_cmd = sprintf( 'rmdir /S /Q "%s"', outdir );
        [ st, msg ] = system( dos_cmd );
        %rmdir(outdir); 
        rehash();
    end;
%     mkdir(outdir);
%     addpath(outdir);

    figure;imagesc(dcm);colormap gray
    [dcm, rect] = imcrop;
    close
    [d1, d2] = size(dcm);

    figure;imagesc(dcm);colormap gray;hold
    h = imellipse;
    bndry_epi = wait(h);
    h = imellipse;
    bndry_endo = wait(h);
    close

    t1=[];t2=[];
    for i=1:d1
        for j=1:d2
            IN0 = inpolygon(j,i,double(bndry_endo(:,1)), double(bndry_endo(:,2)));
            if IN0(1,1) > 0
                   t1=[t1;dcm(i,j)];
            end
            IN = inpolygon(j,i,double(bndry_epi(:,1)), double(bndry_epi(:,2)))...
                -inpolygon(j,i,double(bndry_endo(:,1)), double(bndry_endo(:,2)));
            if IN(1,1) <= 0
                %dcm(i,j) = 0;%int16(1);
            else
                t2=[t2;dcm(i,j)];
            end
        end
    end
    t1=int16(t1); t2=int16(t2);
    %t1=int16(0.9*min(double(t2)));
    t1=int16(1.*max(t1));
    
    cent_epi=[mean(bndry_epi(:,1)),mean(bndry_epi(:,2))];
    cent_endo=[mean(bndry_endo(:,1)),mean(bndry_endo(:,2))];
    bndry_endo_new=zeros(size(bndry_endo));
    get_endo=zeros(size(bndry_endo,1));
    for i=1:size(bndry_endo,1)
        [xx, yy]=fillline(double(bndry_endo(i,:)),double(cent_endo(1,:)),20);
        %plot(xx,yy,'-k*');
        %xx=int16(xx);yy=int16(yy);
        bndry_endo_new(i,:)=bndry_endo(i,:);
        for j=1:20
            if dcm(int16(yy(j)),int16(xx(j))) == 0
                get_endo(i)=1;
            end
            if dcm(int16(yy(j)),int16(xx(j))) >t1
                if get_endo(i) ==0
                    bndry_endo_new(i,:)=[xx(j),yy(j)];
                    get_endo(i)=1;
                end
            end
        end
    end
   
    bndry_endo=bndry_endo_new;
    
    figure;imagesc(dcm);colormap gray;hold
    plot(bndry_epi(:,1), bndry_epi(:,2), 'y-','LineWidth',2);
    plot(bndry_endo(:,1), bndry_endo(:,2), 'y-','LineWidth',2);
end
  
if EARLIER==0
    close all;
    writerObj = VideoWriter(strcat('boundaries_',mystr,'.avi'));
    open(writerObj);
    for inum=1:size(pic,1)
        dcm = dicomread(pic(inum,:));
        dcm= imcrop(dcm, rect);
        figure;imagesc(dcm);colormap gray;hold
%         [d1, d2] = size(dcm);
%         for i=1:d1
%             for j=1:d2
%                 IN = inpolygon(j,i,double(bndry_epi(:,1)), double(bndry_epi(:,2)));
%                 if IN(1,1) <= 0
%                     dcm(i,j) = 0;%int16(1);
% 
%                 end
%             end
%         end
   
        cent_epi=[mean(bndry_epi(:,1)),mean(bndry_epi(:,2))];
        cent_endo=[mean(bndry_endo(:,1)),mean(bndry_endo(:,2))];
        bndry_epi_new=zeros(size(bndry_epi));
        bndry_endo_new=zeros(size(bndry_endo));
        get_epi=zeros(size(bndry_epi,1));
        get_endo=zeros(size(bndry_endo,1));
        for i=1:size(bndry_epi,1)
            [xx, yy]=fillline(double(bndry_epi(i,:)),double(cent_epi(1,:)),20);
            bndry_epi_new(i,:)=bndry_epi(i,:);
            for j=1:max(size(xx))
                if dcm(int16(yy(j)),int16(xx(j))) >int16(0.5*t1)
                    if get_epi(i) ==0
                        bndry_epi_new(i,:)=[xx(j),yy(j)];
                        get_epi(i) =1;
                    end
                end
            end
        end
    
        t1=int16(FAC*t1);
        for i=1:size(bndry_endo,1)
            [xx, yy]=fillline(double(cent_endo(1,:)),double(bndry_endo(i,:)),20);

            bndry_endo_new(i,:)=bndry_endo(i,:);
            for j=1:max(size(xx))
                if dcm(int16(yy(j)),int16(xx(j))) == 0
%                     get_endo(i)=1;
                end
                if dcm(int16(yy(j)),int16(xx(j))) >t1
                    if get_endo(i) <=1
                        bndry_endo_new(i,:)=[xx(j),yy(j)];
                        get_endo(i)=get_endo(i)+1;
                    end
                end
            end
        end
        bndry_epi_new(:,1) = smoothn(bndry_epi_new(:,1),2);
        bndry_epi_new(:,2)= smoothn(bndry_epi_new(:,2),2);

        %papilaries
        if PAPPILARIES
            endo_cent_dist =  sqrt((bndry_endo(:,1)-cent_endo(1,1)).^2+(bndry_endo(:,2)-cent_endo(1,2)).^2);
            median_endo_cent_dist=0.7*median(endo_cent_dist);
            for i=1:size(bndry_endo,1)
                [xx, yy]=fillline(double(bndry_endo(i,:)),double(cent_endo(1,:)),20);
                %xx=int16(xx);yy=int16(yy);
                bndry_endo_new(i,:)=bndry_endo(i,:);
                for j=1:20
                    if dcm(int16(yy(j)),int16(xx(j))) == 0
%                         get_endo(i)=1;
                    end
                    if dcm(int16(yy(j)),int16(xx(j))) >t1
                        if get_endo(i) ==0
                            if sqrt((double(xx(j))-cent_endo(1,1)).^2+double((yy(j))-cent_endo(1,2)).^2) > median_endo_cent_dist
                                bndry_endo_new(i,:)=[xx(j),yy(j)];
                                get_endo(i)=1;
                            end
                        end
                    end
                end
            end
        end
         bndry_endo_new(:,1) = smoothn(bndry_endo_new(:,1),5);
         bndry_endo_new(:,2) = smoothn(bndry_endo_new(:,2),5);
%         sz=size(bndry_endo_new,1);
%         dx = (bndry_endo_new(2,1)-bndry_endo_new(sz-1,1))/3;
%         dy = (bndry_endo_new(2,2)-bndry_endo_new(sz-1,2))/3;
%         bndry_endo_new(1,1)=bndry_endo_new(2,1)-dx;
%         bndry_endo_new(1,2)=bndry_endo_new(2,2)-dy;
%         bndry_endo_new(sz,1)=bndry_endo_new(2,1)-2*dx;
%         bndry_endo_new(sz,2)=bndry_endo_new(2,2)-2*dy;
% 
%         sz=size(bndry_epi_new,1);
%         dx = (bndry_epi_new(2,1)-bndry_epi_new(sz-1,1))/3;
%         dy = (bndry_epi_new(2,2)-bndry_epi_new(sz-1,2))/3;
%         bndry_epi_new(1,1)=bndry_epi_new(2,1)-dx;
%         bndry_epi_new(1,2)=bndry_epi_new(2,2)-dy;
%         bndry_epi_new(sz,1)=bndry_epi_new(2,1)-2*dx;
%         bndry_epi_new(sz,2)=bndry_epi_new(2,2)-2*dy;

        t1=int16(t1/FAC);
       
        plot([bndry_endo_new(:,1);bndry_endo_new(1,1)],[bndry_endo_new(:,2);bndry_endo_new(1,2)], 'g--*','LineWidth',2)
        plot([bndry_epi_new(:,1);bndry_epi_new(1,1)],[bndry_epi_new(:,2);bndry_epi_new(1,2)], 'r--*','LineWidth',2)
        plot([bndry_endo(:,1);bndry_endo(1,1)],[bndry_endo(:,2);bndry_endo(1,2)], 'y-')
        plot([bndry_epi(:,1);bndry_epi(1,1)],[bndry_epi(:,2);bndry_epi(1,2)], 'y-')
        frame = getframe(gca);
        writeVideo(writerObj,frame);
        close;
%         bndry_endo=bndry_endo_new;
% 
%         bndry_epi=bndry_epi_new;
        %figname = strcat('pic_',num2str(inum),'.png');
        %saveas(gcf,strcat(outdir,'\',figname));
    end
    close(writerObj);
end

CONVOL=0;
if CONVOL
    maskX = [-1 0 1 ; -2 0 2; -1 0 1];
    maskY = [-1 -2 -1 ; 0 0 0 ; 1 2 1] ;
    resX = conv2(double(dcm), double(maskX));resY = conv2(double(dcm),double( maskY));
    mag = sqrt(resX.^2 + resY.^2);
    thresh = mag <thresh0;
    mag(thresh) = 0;


    [id1 id2 ] = find(mag<10);
    plot(id2,id1, 'k*');

    ids=[id2 id1];
    pol = zeros (360,2);
end
%%%




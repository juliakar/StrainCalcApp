function [ new_XYZ err ] = ErrorFun( poly, xyz )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

XX = xyz(:,1);
YY = xyz(:,2);
poly_x = poly(1,:);
poly_y = poly(2,:);
num_pts = size(XX,1);
uno = zeros(num_pts,1);
if size(poly,2)==6 
                alpha = [XX YY (1/2)*XX.^2 (1/2)*YY.^2 XX.*YY uno ];
else
                alpha =  [XX.^3/3  YY.^3/3  3*YY.*XX.^2/3  3*XX.^2/3  ...
                3*XX.*YY.^2/3  6*XX.*YY/3  3*XX/3  3*YY.^2/3  3*YY/3  uno]; 
end

x_new = poly_x*transpose(alpha);
y_new = poly_y*transpose(alpha);

x_new = reshape(x_new,size(XX,1),size(XX,2));
y_new = reshape(y_new,size(XX,1),size(XX,2));
err=sqrt(sum((y_new-YY).^2+(x_new-XX).^2)/num_pts);
new_XYZ = [x_new y_new];
%err_y=sqrt(sum((y_new-YY).^2)/num_pts);
%err=[err_x err_y];
end


function [ d1 del1 ] = DispSmoothingFn( d1,del1 )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
def=d1(:,1:2)+del1(:,1:2);
new_d1=zeros(size(def));
new_del1=zeros(size(def));
for i=1:size(def,1)
    px=def(i,1);
    py=def(i,2);
    DX=def(:,1)-px;
    DY=def(:,2)-py;
    DR = sqrt(DX.^2+DY.^2);
    [d2 idx] =sort(DR);
    pdx = 0.25*(del1(idx(2),1)+del1(idx(3),1)+del1(idx(4),1)+del1(idx(5),1));
    pdy = 0.25*(del1(idx(2),2)+del1(idx(3),2)+del1(idx(4),2)+del1(idx(5),2));
    new_d1(i,1:2)=[def(i,1)-pdx def(i,2)-pdy];
    new_del1(i,1:2)=[pdx pdy];
end
d1 =[new_d1(:,1),new_d1(:,2)];
del1 =[new_del1(:,1),new_del1(:,2)];
% figure
% hold
% quiver(new_d1(:,1)+new_del1(:,1)/2,new_d1(:,2)+new_del1(:,2)/2,new_del1(:,1)/2,new_del1(:,2)/2, 'Color', 'r','AutoScale', 'off');
% new_walls1=[[walls(w1_start:w1_end,1)-mean(walls(:,1));walls(w1_start,1)-mean(walls(:,1))], [walls(w1_start:w1_end,2)-mean(walls(:,2));walls(w1_start,2)-mean(walls(:,2))]];
% new_walls2=[[walls(w2_start:w2_end,1)-mean(walls(:,1));walls(w2_start,1)-mean(walls(:,1))], [walls(w2_start:w2_end,2)-mean(walls(:,2));walls(w2_start,2)-mean(walls(:,2))]];
% 
% wx = interp(new_walls1(:,1),2);
% wy = interp(new_walls1(:,2),2);
% ws=size(wx,1);
% plot(wx(1:ws-1), wy(1:ws-1), 'black');
% wx = interp(new_walls2(:,1),2);
% wy = interp(new_walls2(:,2),2);
% ws=size(wx,1);
% plot(wx(1:ws-1), wy(1:ws-1), 'black');
% seg2=[seg(:,1)-mean(walls(:,1)), seg(:,2)-mean(walls(:,2))];
% plot(seg2(2:2:13,1), seg2(2:2:13,2), 'g*')


end


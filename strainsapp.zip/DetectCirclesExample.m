%% Detect and Measure Circular Objects in an Image
% This example shows how to use |imfindcircles| to automatically detect
% circles or circular objects in an image. It also shows the use of
% |viscircles| to visualize the detected circles.

% Copyright 2012-2014 The MathWorks, Inc.

%% Step 1: Load Image
% This example uses an image of round plastic chips of various colors.

num_slices=3;
slice_offset=1;
if exist('num_slices', 'var')
else
    disp('num_slices not specified');
    return;
end
if exist('slice_offset', 'var')
else
    disp('slice_offset not specified');
    return;
end
close all;
I=[];
k=1;
my_names=cell(1);
dirname='C:\Images\Normals\DK_080515_001\all_images\';
MYDIR=dir(dirname);
for i=1:size(MYDIR,1) 
    findstr(MYDIR(i).name,'MAG');
    if isempty(ans)
    else my_names{k}=strcat(dirname,MYDIR(i).name); k=k+1;
    end
end
ims=dir(my_names{1+slice_offset});
ims=ims(6:size(ims,1));
dcmm=zeros(128,128,size(ims,1));
for i=1:size(ims,1)
dcmm(:,:,i)=dicomread(ims(i).name);
end
ims=dir('C:\Images\Normals\DK_080515_001\all_images\SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_X-ENCPHA_PAR12_0058');
ims=ims(6:size(ims,1));
dcmx=zeros(128,128,size(ims,1));
for i=1:size(ims,1)
dcmx(:,:,i)=dicomread(ims(i).name);
end
ims=dir('C:\Images\Normals\DK_080515_001\all_images\SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_Y-ENCPHA_PAR12_0059');
ims=ims(6:size(ims,1));
dcmy=zeros(128,128,size(ims,1));
for i=1:size(ims,1)
dcmy(:,:,i)=dicomread(ims(i).name);
end
ims=dir('C:\Images\Normals\DK_080515_001\all_images\SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_Z-ENCPHA_PAR12_0060');
ims=ims(6:size(ims,1));
dcmz=zeros(128,128,size(ims,1));
for i=1:size(ims,1)
dcmz(:,:,i)=dicomread(ims(i).name);
end

I=dcmm(:,:,1); 
crop=struct('cropi',[],'cropj',[]);
if isempty(crop.cropi)
    % Crop image
    figure(11),imagesc(I(:,:)),axis image,colormap gray
    title('Crop image - Pick 1 point upper left and one point lower right')
    [x y] = ginput(2);close(11)
    
    cropi = min(round(y)):max(round(y));
    crop.cropi=cropi;
    cropj = min(round(x)):max(round(x));
    crop.cropj=cropj;
end
 
% I = I(min(crop.cropi):max(crop.cropi),min(crop.cropj):max(crop.cropj));
% h=figure(111);
% BW = I > 900;
% imagesc(BW), colormap gray;
% title('Binary');
% himel=imellipse;vert1=wait(himel);
% himel2=imellipse;vert2=wait(himel2);
% c=[mean([vert1(:,1);vert2(:,1)]) mean([vert1(:,2) ;vert2(:,2)])];
% d=sqrt((x(1)-x(2))^2+(y(1)-y(2))^2);
% 
% hold;

% xi=vert1(:,1) ;
% yi=vert1(:,2);
% xi2=vert2(:,1) ;
% yi2=vert2(:,2);

% close(h);


epi = struct('xi',[],'yi',[],'zi',[]);
endo = struct('xi',[],'yi',[],'zi',[]);
z_inc=8;
bi=1;
for i=num_slices:-1:1%:-1:1%size(ims,1)imagesc(BW), colormap gray;
    ims=dir(my_names{i+slice_offset});
    ims=ims(6:size(ims,1));

    dcmm(:,:,i)=dicomread(ims(1).name);

    I=dcmm(:,:,i);
    I = I(min(crop.cropi):max(crop.cropi),min(crop.cropj):max(crop.cropj));
    figure;
    title('Create epicardium');
    BW = I > 900;
    imagesc(BW),colormap gray;
    hold;
    title('Create epicardium');
    himel=imellipse;vert1=wait(himel);
    title('Create endocardium');
    himel2=imellipse;vert2=wait(himel2);
    % wait(he);pos = getVertices(he);
    % [x y]=getline(h);
    c=[mean([vert1(:,1);vert2(:,1)]) mean([vert1(:,2) ;vert2(:,2)])];
    d=sqrt((x(1)-x(2))^2+(y(1)-y(2))^2);
    xi=vert1(:,1) ;
    yi=vert1(:,2);
    xi2=vert2(:,1) ;
    yi2=vert2(:,2);
    close;
    figure;
%     ims=dir(my_names{i+1});
%     ims=ims(6:size(ims,1));
% 
%     dcmm(:,:,i)=dicomread(ims(1).name);
% 
    I=dcmm(:,:,i);
    I = I(min(crop.cropi):max(crop.cropi),min(crop.cropj):max(crop.cropj));
    BW = I > 900;
    imagesc(BW),colormap gray
    hold;
     c=[mean([vert1(:,1)]) mean([vert1(:,2)])];
    subdivs=150;
    for t=1:size(vert1,1)
        ti=[(vert1(t,1)-c(1))/subdivs ,(vert1(t,2)-c(2))/subdivs ];
        prev_temp =0; 
        stop_srch=0;
        for di=1:subdivs
            temp = impixel(BW,ceil(vert1(t,1)-(di-1)*ti(1,1)),ceil(vert1(t,2)-(di-1)*ti(1,2)));
            
            if temp(1) > 0 &&stop_srch ==0
                xi(t)= vert1(t,1)-di*ti(1,1);
                yi(t)=vert1(t,2)-di*ti(1,2);
                stop_srch=1;
            else
               % stop_srch=0;
            end
            prev_temp = temp(1);
        end
        
    end
    c=[mean([vert2(:,1)]) mean([vert2(:,2)])];
    for t=1:size(vert2,1)
        ti=[(vert2(t,1)-c(1))/subdivs ,(vert2(t,2)-c(2))/subdivs ];
        prev_temp =0; 
        stop_srch=0;
        for di=1:subdivs
            temp = impixel(BW,ceil(vert2(t,1)-(di-1)*ti(1,1)),ceil(vert2(t,2)-(di-1)*ti(1,2)));
            
            if temp(1) == 0 &&stop_srch ==0
                xi2(t)= vert2(t,1)-di*ti(1,1);
                yi2(t)=vert2(t,2)-di*ti(1,2);
                stop_srch=1;
            else
               % stop_srch=0;
            end
            prev_temp = temp(1);
        end
        
    end
%     vert1(:,1)= (vert1(:,1)+(xi))/2;
%     vert1(:,2)= (vert1(:,2)+(yi))/2;
%     vert2(:,1)= (vert2(:,1)+(xi2))/2;
%     vert2(:,2)= (vert2(:,2)+(yi2))/2;

    [zg, ag, bg, alphag] = fitellipse([transpose(xi);transpose(yi)]);
    e_epi = plotellipse(zg, ag, bg, alphag, 'b');
    sz=size(e_epi,2);
    e_epi =e_epi(:,1:5:sz);
    epi(bi).xi=transpose(e_epi(1,:));
    epi(bi).yi=transpose(e_epi(2,:));
    epi(bi).zi=ones(size(epi(bi).yi,1))*z_inc*(i-1);
% %     epi(bi).xi=0.5*( epi(bi).xi+resample(xi,sz/5,size(xi,1)));
% %     epi(bi).yi=0.5*( epi(bi).yi+resample(xi,sz/5,size(xi,1)));
    epi(bi).xi=xi;
    epi(bi).yi=yi;
    epi(bi).zi=ones(size(epi(bi).xi,1),1)*z_inc*(bi-1);
    [zg, ag, bg, alphag] = fitellipse([transpose(xi2);transpose(yi2)]);
    e_endo = plotellipse(zg, ag, bg, alphag, 'b');
    sz=size(e_endo,2);
    e_endo =e_endo(:,1:5:sz);
    endo(bi).xi=transpose(e_endo(1,:));
    endo(bi).yi=transpose(e_endo(2,:));
    endo(bi).zi=ones(size(endo(bi).yi,1))*z_inc*(i-1);
    endo(bi).xi=xi2;
    endo(bi).yi=yi2;
   
    endo(bi).zi=ones(size(endo(bi).xi,1),1)*z_inc*(bi-1);
    plot(epi(bi).xi,epi(bi).yi,'c*-');plot(endo(bi).xi,endo(bi).yi,'g*-');
    bi=bi+1;%close;
end
A_epi = ones(num_slices,1);
A_endo = ones(num_slices,1);
for i=1:num_slices
A_endo(i)=polyarea(endo(i).xi,endo(i).yi);
A_epi(i)=polyarea(epi(i).xi,epi(i).yi);
end
V=0;
for i=1:num_slices-1
V=V+0.5*abs(z_inc)*(A_epi(i)-A_endo(i)+A_epi(i+1)-A_endo(i+1));
end
V
figure;hold
for bi=1:num_slices
plot3(epi(bi).xi,epi(bi).yi,epi(bi).zi,'c*-');plot3(endo(bi).xi,endo(bi).yi,endo(bi).zi,'r*-');
end
view([1 1 1]);

% close(111);
 
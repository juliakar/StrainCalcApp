TEST_ALL=0;
% % 
% % 
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR10_0047    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR11_0051    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR12_0055    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR13_0059    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR14_0063    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR15_0067    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR16_0071    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR17_0075    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR18_0079    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR19_0083    
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR4_0023     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR5_0027     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR6_0031     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR7_0035     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR8_0039     
% % SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR9_0043  
% % 

mystr='SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR13_0059';
mydir = dir( strcat('C:\Images\JK_082714_001\all_images\',mystr));

pic=[];
for i=1:size(mydir,1)
    if ~isdir(mydir(i).name)
        pic=[pic;mydir(i).name];
    end
end

PAPPILARIES = 1;
FAC = 1.;
if EARLIER
      dcm_cntr = dicomread(pic(3,:));size(pic,1)
      
%     outdir =strcat('C:\matlab\',mystr);
%     if exist( outdir, 'dir')
%         dos_cmd = sprintf( 'rmdir /S /Q "%s"', outdir );
%         [ st, msg ] = system( dos_cmd );
%         %rmdir(outdir); 
%         rehash();
%     end;
%     mkdir(outdir);
%     addpath(outdir);
    dcm_cntr = medfilt2(dcm_cntr,[3 3]);
    figure;imagesc(dcm_cntr);colormap gray
    [dcm_cntr, rect] = imcrop;
    close
    dcm = dcm_cntr;
    [d1, d2] = size(dcm_cntr);

    bw = edge(dcm_cntr, 'Canny' , 0);
    bw = uint16(bw)*uint16(0.25*max(max(dcm_cntr)));
    dcm_cntr = bw+dcm_cntr;
    figure;imagesc(dcm_cntr);colormap gray;hold
    h = imellipse;
    bndry_epi = wait(h);
    h = imellipse;
    bndry_endo = wait(h);
    close

    t1=[];t2=[];
    for i=1:d1
        for j=1:d2
            IN0 = inpolygon(j,i,double(bndry_endo(:,1)), double(bndry_endo(:,2)));
            if IN0(1,1) > 0
                   t1=[t1;dcm_cntr(i,j)];
            end
            IN = inpolygon(j,i,double(bndry_epi(:,1)), double(bndry_epi(:,2)))...
                -inpolygon(j,i,double(bndry_endo(:,1)), double(bndry_endo(:,2)));
            if IN(1,1) <= 0
            else
                t2=[t2;dcm_cntr(i,j)];
            end
        end
    end
    t1=int16(t1); t2=int16(t2);
    t1=int16(1.*mean(t2));
    
    cent_epi=[mean(bndry_epi(:,1)),mean(bndry_epi(:,2))];
    cent_endo=[mean(bndry_endo(:,1)),mean(bndry_endo(:,2))];
    bndry_endo_new=zeros(size(bndry_endo));
    get_endo=zeros(size(bndry_endo,1));
    
    figure;imagesc(dcm_cntr);colormap gray;hold
    plot(bndry_epi(:,1), bndry_epi(:,2), 'y-','LineWidth',2);
    plot(bndry_endo(:,1), bndry_endo(:,2), 'y-','LineWidth',2);
end % EARLIER =1
  
if EARLIER==0
    close all;
    writerObj = VideoWriter(strcat('boundaries_',mystr,'.avi'));
    open(writerObj);
    for inum=1:size(pic,1)
        dcm = dicomread(pic(inum,:));
        dcm= imcrop(dcm, rect);
        dcm_cntr = medfilt2(dcm_cntr,[3 3]);
        bw = edge(dcm, 'Canny' , 0);
        bw = uint16(bw);%*uint16(0.25*max(max(dcm)));
        dcm0 = dcm;
        dcm = bw;%+dcm;
        figure;imagesc(dcm0);colormap gray;hold
        cent_epi=[mean(bndry_epi(:,1)),mean(bndry_epi(:,2))];
        cent_endo=[mean(bndry_endo(:,1)),mean(bndry_endo(:,2))];
        bndry_epi_new=zeros(size(bndry_epi));
        bndry_endo_new=zeros(size(bndry_endo));
        get_epi=zeros(size(bndry_epi,1),1);
        get_endo=zeros(size(bndry_endo,1),1);
        
        
        
        %%%Process endo%%%
        t1=int16(FAC*t1);
        for i=1:size(bndry_endo,1)
            [xx, yy]=fillline(double(bndry_endo(i,:)),double(cent_endo(1,:)),10);
            xx=transpose(xx); yy=transpose(yy);
            bndry_endo_new(i,:)=bndry_endo(i,:);
            for j=2:max(size(xx))
                if get_endo(i) == 0
                    if dcm(int16(yy(j)),int16(xx(j)))  == 1
                            if j ==1
                                bndry_endo_new(i,:)=[xx(j),yy(j)];

                            else
                                bndry_endo_new(i,:)=[xx(j),yy(j)];
                            end
                            get_endo(i)=get_endo(i)+1;
                    end
                end
            end
        end
        t1=int16(t1/FAC);
        
        %papilaries
        if PAPPILARIES
            %plot([bndry_endo_new(:,1);bndry_endo_new(1,1)],[bndry_endo_new(:,2);bndry_endo_new(1,2)], 'ms','LineWidth',2)
            endo_cent_dist =  sqrt((bndry_endo_new(:,1)-cent_endo(1,1)).^2+(bndry_endo_new(:,2)-cent_endo(1,2)).^2);
            median_endo_cent_dist=2*median(endo_cent_dist);
            for i=1:size(bndry_endo,1)
                            if endo_cent_dist(i) < 2.2
                                bndry_endo_new(i,:) = bndry_endo(i,:);
                            end
            end
        end
        
        bndry_endo_new2 = [bndry_endo_new(1,:);bndry_endo_new;bndry_endo_new(size(bndry_endo_new,1),:)];
        get_endo2 = [get_endo(1,:);get_endo;get_endo(size(get_endo,1),:)];
        while find(get_endo==0)
            for i=1:size(bndry_endo_new,1)
                if get_endo(i)==0
                    if get_endo2(i)~=0 || get_endo2(i+2)~=0
                        xi = 0.5*(bndry_endo_new2(i,1)+ bndry_endo_new2(i+2,1));
                        bndry_endo_new(i,1)= xi;
                        X = [bndry_endo_new2(i,1); bndry_endo_new2(i+2,1)+0.02];
                        Y = [bndry_endo_new2(i,2); bndry_endo_new2(i+2,2)+0.02];
                        method = 'spline';
                        bndry_endo_new(i,2) = interp1(X,Y,xi,method);
                        get_endo(i)=get_endo(i)+1;
                        bndry_endo_new2(i+1,:)= bndry_endo_new(i,:);
                        get_endo2(i+1)=get_endo2(i+1)+1;
                    end
                end   
            end
        end

        
%         plot([bndry_endo_new(:,1);bndry_endo_new(1,1)],[bndry_endo_new(:,2);bndry_endo_new(1,2)], 'r*','LineWidth',2)
%         plot(cent_endo(:,1), cent_endo(:,2),'y*');   
        bndry_endo_new(:,1) = smoothn(bndry_endo_new(:,1),2);
        bndry_endo_new(:,2)= smoothn(bndry_endo_new(:,2),2);
        %%%Process endo END %%%
        
        %%%Process epi START %%%
        for i=1:size(bndry_epi,1)
            [xx, yy]=fillline(double(bndry_epi(i,:)),double(cent_epi(1,:)),20);
            xx=transpose(xx); yy=transpose(yy);
            bndry_epi_new(i,:)=bndry_epi(i,:);
            for j=1:max(size(xx))
                if get_epi(i) ==0
                    if dcm(int16(yy(j)),int16(xx(j)))  == 1
                        if inpolygon(xx(j),yy(j),double(bndry_endo(:,1)), double(bndry_endo(:,2)))
                        else
                            if j ==1
                                bndry_epi_new(i,:)=[xx(j),yy(j)];
                            else
                                bndry_epi_new(i,:)=[xx(j),yy(j)];
                            end
                            get_epi(i)=get_epi(i)+1;
                        end
                    end
                end
            end
        end
        
        if PAPPILARIES
            %plot([bndry__epi_new(:,1);bndry__epi_new(1,1)],[bndry__epi_new(:,2);bndry__epi_new(1,2)], 'ms','LineWidth',2)
            epi_cent_dist =  sqrt((bndry_epi_new(:,1)-cent_epi(1,1)).^2+(bndry_epi_new(:,2)-cent_epi(1,2)).^2);
            median_epi_cent_dist=2*median(epi_cent_dist);
            for i=1:size(bndry_epi,1)
                if epi_cent_dist(i) < 2.5
                    bndry_epi_new(i,:) = bndry_epi(i,:);
                end
            end
        end
        
        bndry_epi_new2 = [bndry_epi_new(1,:);bndry_epi_new;bndry_epi_new(size(bndry_epi_new,1),:)];
        get_epi2 = [get_epi(1,:);get_epi;get_epi(size(get_epi,1),:)];
        while find(get_epi==0)
            for i=1:size(bndry_epi_new,1)
                if get_epi(i)==0
                    if get_epi2(i)~=0 || get_epi2(i+2)~=0
                        xi = 0.5*(bndry_epi_new2(i,1)+ bndry_epi_new2(i+2,1));
                        bndry_epi_new(i,1)= xi;
                        X = [bndry_epi_new2(i,1); bndry_epi_new2(i+2,1)];
                        Y = [bndry_epi_new2(i,2); bndry_epi_new2(i+2,2)];
                        method = 'spline';
                        bndry_epi_new(i,2) = interp1(X,Y,xi,method);
                        get_epi(i)=get_epi(i)+1;
                        bndry_epi_new2(i+1,:)= bndry_epi_new(i,:);
                        get_epi2(i+1)=get_epi2(i+1)+1;
                    end
                end   
            end
        end

        
        plot([bndry_epi_new(:,1);bndry_epi_new(1,1)],[bndry_epi_new(:,2);bndry_epi_new(1,2)], 'm*','LineWidth',2)
        plot(cent_epi(:,1), cent_epi(:,2),'y*');
        
        bndry_epi_new(:,1) = smoothn(bndry_epi_new(:,1),2);
        bndry_epi_new(:,2)= smoothn(bndry_epi_new(:,2),2);
        %%%Process epi END %%%
        

        plot([bndry_endo_new(:,1);bndry_endo_new(1,1)],[bndry_endo_new(:,2);bndry_endo_new(1,2)], 'g-.','LineWidth',3)
        plot([bndry_epi_new(:,1);bndry_epi_new(1,1)],[bndry_epi_new(:,2);bndry_epi_new(1,2)], 'r-.','LineWidth',3)
        %plot([bndry_endo(:,1);bndry_endo(1,1)],[bndry_endo(:,2);bndry_endo(1,2)], 'y--')
        %plot([bndry_epi(:,1);bndry_epi(1,1)],[bndry_epi(:,2);bndry_epi(1,2)], 'c--')
        frame = getframe(gca);
        writeVideo(writerObj,frame);
        close;
%         bndry_endo=bndry_endo_new;
%         bndry_epi=bndry_epi_new;
%         figname = strcat('pic_',num2str(inum),'.png');
%         saveas(gcf,strcat(outdir,'\',figname));
    end
    close(writerObj);
end

CONVOL=0;
if CONVOL
    maskX = [-1 0 1 ; -2 0 2; -1 0 1];
    maskY = [-1 -2 -1 ; 0 0 0 ; 1 2 1] ;
    resX = conv2(double(dcm), double(maskX));resY = conv2(double(dcm),double( maskY));
    mag = sqrt(resX.^2 + resY.^2);
    thresh = mag <thresh0;
    mag(thresh) = 0;


    [id1 id2 ] = find(mag<10);
    plot(id2,id1, 'k*');

    ids=[id2 id1];
    pol = zeros (360,2);
end
%%%




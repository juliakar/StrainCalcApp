fid = fopen('C:/matlab/disp_dens.con', 'w');

k=1;
for i=1:1:size(pos_dens,1)
fprintf(fid, 'LL1 ,%d ,%1.15e ,%1.15e ,%1.15e\r', k, pos_dens(i,1), pos_dens(i,2), 0);
fprintf(fid, '%1.15e ,%1.15e ,%1.15e\r', disp_dens(i,1), disp_dens(i,2), 0);
k=k+1;
end
fclose(fid);

k=1;
fid = fopen('C:/matlab/disps_tags.con', 'w');
for i=1:2:size(pos_tag,1)
fprintf(fid, 'LL1 ,%d ,%1.15e ,%1.15e ,%1.15e\r', k, pos_tag(i,1), pos_tag(i,2), pos_tag(i,3));
fprintf(fid, '%1.15e ,%1.15e ,%1.15e\r', disp_tag(k,1), disp_tag(k,2), 0.);
k=k+1;
end
fclose(fid);

k=17;
fid = fopen('C:/matlab/walls_sud.con', 'w');
for i=1:1:size(wall_sud,1)
fprintf(fid, '%d ,%1.15e ,%1.15e ,%1.15e\r', k, wall_sud(i,1), wall_sud(i,2), 0.);
k=k+1;
end
fclose(fid);
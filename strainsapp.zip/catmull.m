    
    bndry_epi_new1=[bndry_epi_new;bndry_epi_new(1:3,:)];
    for i=1:size(bndry_epi_new,1)
        p0=  bndry_epi_new1(i:i+3,:)  ;
        t=1.5;
        t3 = t * t * t;
        t2 = t * t;

        f1 = -0.5 * t3 + t2 - 0.5 * t;
        f2 = 1.5 * t3 - 2.5 * t2 + 1.0;
        f3 = -1.5 * t3 + 2.0 * t2 + 0.5 * t;
        f4 = 0.5 * t3 - 0.5 * t2;

        bndry_epi_new(i,1) = p0(1,1) * f1 + p0(2,1) * f2 + p0(3,1) * f3 + p0(4,1) * f4;
        bndry_epi_new(i,2)= p0(1,2) * f1 + p0(2,2) * f2 + p0(3,2) * f3 + p0(4,2) * f4;
    end
 bndry_endo_new1=[bndry_endo_new;bndry_endo_new(1:3,:)];
    for i=1:size(bndry_endo_new,1)
        p0=  bndry_endo_new1(i:i+3,:)  ;
        t=1.5;
        t3 = t * t * t;
        t2 = t * t;

        f1 = -0.5 * t3 + t2 - 0.5 * t;
        f2 = 1.5 * t3 - 2.5 * t2 + 1.0;
        f3 = -1.5 * t3 + 2.0 * t2 + 0.5 * t;
        f4 = 0.5 * t3 - 0.5 * t2;

        bndry_endo_new(i,1) = p0(1,1) * f1 + p0(2,1) * f2 + p0(3,1) * f3 + p0(4,1) * f4;
        bndry_endo_new(i,2)= p0(1,2) * f1 + p0(2,2) * f2 + p0(3,2) * f3 + p0(4,2) * f4;
    end
pwd_path=pwd;
addpath(genpath(pwd_path));
addpath(genpath('C:\walls and disps'));
addpath(genpath('C:\Images\HF'));
%addpath(genpath('C:\Dense Publication III\Brian\DENSE Analysis'));
addpath(genpath('C:\Images\Normals\DK_080515_001'))
% 'C:\Dense Publication III\Kevin Kulshrestha\DENSE\HF MASS Displacements\',...
% 'C:\Dense Publication III\Danielle\DENSE\HF Mass Strains\');
open zscore_script
open FindFiles
open Lagrange3_3D_Func
open DENSE3D
open GenVolumeWUnwrap


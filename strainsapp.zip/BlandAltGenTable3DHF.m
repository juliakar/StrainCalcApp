% BA_TD=BA_comp;BA_R=BA_rep;
BA=BA_TD;%BA_TD_HF;
%  EPICAL PLOT
BA_new = []; 
BA_AVG = 0;
if BA_AVG
for i=1:6:size(BA,1)
    BA_new = [BA_new;mean(BA(i:1:i+5,2)), mean(BA(i:1:i+5,10))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2,'Circumferential Strain Agreement',  1)
BA_new = [];
for i=1:6:size(BA,1)
    BA_new = [BA_new;mean(BA(i:1:i+5,3)), mean(BA(i:1:i+5,11))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2,'Longitudinal Strain Agreement', 2)
BA_new = [];
for i=1:6:size(BA,1)
    BA_new = [BA_new;mean(BA(i:1:i+5,4)),mean(BA(i:1:i+5,12))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2, 'Radial Strain Agreement',3)

else
BA_new = []; 
for i=1:6:size(BA,1)
    BA_new = [BA_new;(BA(i:1:i+5,2)),(BA(i:1:i+5,10))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2,'Circumferential Strain Agreement',  1)
BA_new = [];
for i=1:6:size(BA,1)
    BA_new = [BA_new;(BA(i:1:i+5,3)), (BA(i:1:i+5,11))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2,'Longitudinal Strain Agreement', 2)
BA_new = [];
for i=1:6:size(BA,1)
    BA_new = [BA_new;(BA(i:1:i+5,4)),(BA(i:1:i+5,12))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2, 'Radial Strain Agreement',3)
end

% %  MIDVENTRICULAR PLOT
% BA_new = [];
% for i=7:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,2), BA(i:1:i+5,10)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2, 'Midventricular Circ. Strain Agreement',1)
% BA_new = [];
% for i=7:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,3), BA(i:1:i+5,11)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),BA_new(1:size(BA_new,1),2),2,  'Midventricular Rad. Strain Agreement',2)
% BA_new = [];
% for i=7:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,4), BA(i:1:i+5,12)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2, 'MidventricularLong. Strain Agreement', 3)
% %  EPICAL PLOT
% BA_new = [];
% for i=13:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,2), BA(i:1:i+5,10)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2,'Apical Circ. Strain Agreement', 1)
% BA_new = [];
% for i=13:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,3), BA(i:1:i+5,11)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2, 'Apical Long. Strain Agreement', 2)
% BA_new = [];
% for i=13:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,4), BA(i:1:i+5,12)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2,'Apical Rad. Strain Agreement', 3)
function [endo_d, epi_d,endo_s, epi_s, A_endo, A_epi, V] =GenVolumeWUnwrap( dirname,my_names,rect,flipped)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% % % num_slices=3;
% % % slice_offset=1;
warning off;
% % if exist('num_slices', 'var')
% % else
% %     disp('num_slices not specified');
% %     return;
% % end
% % if exist('slice_offset', 'var')
% % else
% %     disp('slice_offset not specified');
% %     return;
% % end
% % close all;
IMG_NUM=5;
% if exist('slice_sel', 'var')
% else
%     disp('XLS file name not specified');
%     return;
% end
I=[];
k=1;
% my_names=cell(0);
addpath(genpath(dirname));
MYDIR=dir(dirname);

% for i=1:size(MYDIR,1) 
%     myans=findstr(MYDIR(i).name,'AVEMAG');
%     if isempty(myans)
%         myans=findstr(MYDIR(i).name,'RO-ENC_MAG');
%     end
%     if isempty(myans)
%     else
%         my_names{k}=strcat(dirname,MYDIR(i).name); k=k+1;
%     end
% end

if isempty(my_names)
disp('No magnitude files found');
        return;
end

%num_slices=size(slice_sel,2);
num_slices=size(my_names,1);

dcmm=cell(num_slices);
dcmm2=cell(num_slices);
epi = struct('xi',[],'yi',[],'zi',[]);
endo = struct('xi',[],'yi',[],'zi',[]);

epi_d=epi;
epi_s=epi;
endo_d=endo;
endo_s=endo;



bi=1;
for i=1:size(my_names,1)
    ims=dir(strcat(dirname,my_names{i}));
    ims=ims(IMG_NUM:size(ims,1));

    if flipped == 0
        dcmm{bi}=dicomread(ims(3).name);
        dcmm2{bi}=dicomread(ims(6).name);
    else
        dcmm{bi}=flipud(dicomread(ims(3).name));
        dcmm2{bi}=flipud(dicomread(ims(6).name));
    end
        
    dcminfo = dicominfo(ims(1).name);
    z_inc=dcminfo.SliceLocation;

    I=cell2mat(dcmm(bi));
    I = imcrop(I,rect);
    I=imsharpen(I,'Radius',3,'Amount',1);%I=imadjust(I);
   
    h=figure;
    title('Create epicardium');
    %BW = I > ceil(pix_cont*max(max(I)));
    m1=meshgrid(1:size(I,2),1:size(I,1));
    m2=meshgrid(size(I,1):-1:1,1:size(I,2));
    m2=transpose(m2);
    imagesc(I),colormap gray;
    hold;
    movegui(h,'east');
    title('Create epicardium');
    if exist('vert1','var')
        himel=imellipse(gca,ePos);vert1=wait(himel);
    else
        himel=imellipse;vert1=wait(himel);
    end
    title('Create endocardium');
    if exist('vert2','var')
        
        himel2=imellipse(gca,ePos2);vert2=wait(himel2);
        
    else
        himel2=imellipse;vert2=wait(himel2);
    end
    ePos=himel.getPosition;
    ePos2=himel2.getPosition;
    vert1_orig=vert1;
    vert2_orig=vert2;
    
% % %     FINDMYO = 0;
% % %     QuestName=questdlg('Find binary myocardium?', ...
% % %                          'Binary Myocardium?','Yes', 'No','No');
% % %     switch QuestName,
% % %              case 'Yes',
% % %                 FINDMYO=0;
% % %              case 'No',
% % %                 FINDMYO=0;
% % %     end
    xi=vert1(:,1) ;
    yi=vert1(:,2);
    xi2=vert2(:,1) ;
    yi2=vert2(:,2);
    close(h);
    for findmyo = 1:2
        
        I=cell2mat(dcmm(bi));
        if findmyo ==2
            I=cell2mat(dcmm2(bi));
        end
        I = imcrop(I,rect);
        m1=meshgrid(1:size(I,2),1:size(I,1));        %BW = I>ceil(pix_cont*max(max(I)));;

        m2=meshgrid(1:size(I,1),1:size(I,2));
        m2=transpose(m2);
        in=inpolygon(m1,m2,vert1(:,1),vert1(:,2));
        in2=inpolygon(m1,m2,vert2(:,1),vert2(:,2));
        in=in-in2;
        I=imsharpen(I,'Radius',3,'Amount',3);
        [n e]=histcounts(double(I(in>0)));
        thresh = multithresh(I,1);
        valuesMax = [ thresh max(I(:)) ];
        [BW, index] = imquantize(I, thresh, valuesMax);
%          BW=1-isnan(discretize(I,round(1.1*min(mean(I(in>0)))):max(max(I(in>0)))));
%         BW=1-isnan(discretize(I,round(e(2)):round(max(e))));
%         imagesc(BW),colormap gray
        if findmyo ==1
            figure;
            imagesc(I),colormap gray
            hold;
        end
        cen=[mean([vert2(:,1)]) mean([vert2(:,2)])];
        bndry=zeros(size(vert2));
        for bii=1:size(xi2,1)
            [cx cy c]=improfile(BW,[xi2(bii);cen(1,1)],[yi2(bii);cen(1,2)]);
            c_ind=0;gradc=1;
            for ci=2:size(c,1)
                if c(ci-1) > 0 && (c(ci-1)-c(ci))/c(ci-1) == gradc
                    if c_ind==0
                        c_ind=ci;
                    end
                end
            end
            if c_ind==0
                c_ind=1;
            end
            xi2(bii)=cx(c_ind);yi2(bii)=cy(c_ind);
        end  
        c=[mean([vert1(:,1)]) mean([vert1(:,2)])];
        subdivs=150;
        bndry=zeros(size(vert1));
        I_grad=I;
        bndry_mov=zeros(size(bndry,1),1);
        for bii=1:size(xi,1)
            [min_d, ind]=min(hypot(xi(bii)-vert2(:,1),...
            yi(bii)-vert2(:,2)));
            [cx cy c]=improfile(I,[xi(bii);vert2(ind,1)],[yi(bii);vert2(ind,2)]);
            found=0;
%             plot(cx,cy,'r*');
            for k=2:size(c,1)
                    if c(k)>c(k-1)
                        if found == 0
                                bndry(bii,1)=.5*(1*cx(k-1)+1*cx(k-1));
                                bndry(bii,2)=.5*(1*cy(k-1)+1*cy(k-1));
                            if c(k-1)==min(c)
                            found=1;
                         end
                        end
                    end
            end
% % %             c_ind=1;gradc=0;
% % %             I_grad = zeros(size(c,1)-1,1);
% % %             for ci=1:size(c,1)-1
% % %                 count=0;
% % %                 for cii=ci+1:size(c,1)
% % %                     I_grad(ci)=I_grad(ci)-(c(ci)-c(cii));%/c(ci)*mean(c);
% % %                     count=count+1;
% % %                 end
% % %                 I_grad(ci)=I_grad(ci)/ count;
% % %             end
% % %             [gradc,c_ind]=max(I_grad);
% % %                         bndry_mov(bii)=1;
% % %             bndry(bii,1)=cx(c_ind);bndry(bii,2)=cy(c_ind);
        end
%         vert1=bndry;
        xi=bndry(:,1);
        yi=bndry(:,2);
        stop_srch=0;
        c=[mean([bndry(:,1)]) mean([bndry(:,2)])];
        for t=1:size(bndry,1)
            ti=[(bndry(t,1)-c(1))/subdivs ,(bndry(t,2)-c(2))/subdivs ];
            stop_srch=0;
            for di=1:subdivs
                    temp = impixel(BW,round(bndry(t,1)-(di-1)*ti(1,1)),round(bndry(t,2)-(di-1)*ti(1,2)));
                    in_e=inpolygon(round(bndry(t,1)-(di-1)*ti(1,1)),round(bndry(t,2)-(di-1)*ti(1,2)),vert2(:,1), vert2(:,2));
                    if temp(1) > 0 &&stop_srch ==0 && in_e ==0 %&& bndry_mov(t)==0
                        xi(t)= bndry(t,1)-(di-1)*ti(1,1);
                        yi(t)=bndry(t,2)-(di-1)*ti(1,2);
                        stop_srch=1;
                    else
                       % stop_srch=0;
                    end
                end
        end
        GEN_FIGURE=0;
        if GEN_FIGURE
            plot(xi,yi,'r');
            plot(xi2,yi2,'g');
            figure;imagesc(BW),colormap gray
            hold
            plot(xi,yi,'r');
            plot(xi2,yi2,'g');
        end
        xi=0.5*(xi(:,1)+bndry(:,1));
        yi=0.5*(yi(:,1)+bndry(:,2));
        
        cen=[mean([vert2(:,1)]) mean([vert2(:,2)])];
        bndry=zeros(size(vert2));
        for bii=1:size(xi2,1)
            [cx cy c]=improfile(BW,[xi2(bii);cen(1,1)],[yi2(bii);cen(1,2)]);
            c_ind=0;gradc=1;
            for ci=2:size(c,1)
                if c(ci-1) > 0 && (c(ci-1)-c(ci))/c(ci-1) == gradc
                    if c_ind==0
                        c_ind=ci;
                    end
                end
            end
            if c_ind==0
                c_ind=1;
            end
            xi2(bii)=cx(c_ind);yi2(bii)=cy(c_ind);
        end  
    [zg, ag, bg, alphag] = fitellipse([transpose(xi);transpose(yi)]);
    e_epi = plotellipse(zg, ag, bg, alphag, 'b');
    sz=size(e_epi,2);
    e_epi =e_epi(:,1:5:sz);
    sz=size(e_epi,2);
    epi(bi).xi=transpose(e_epi(1,:));
    epi(bi).yi=transpose(e_epi(2,:));
    epi(bi).xi=xi;
    epi(bi).yi=yi;
    sz=size(epi(bi).xi,1);
    
    for bii=1:size(epi(bi).xi)
        if bii==1
            v1=[epi(bi).xi(sz)-epi(bi).xi(bii), epi(bi).yi(bii+1)-epi(bi).yi(bii)];
            v2=[epi(bi).xi(sz)-epi(bi).xi(bii), epi(bi).yi(bii+1)-epi(bi).yi(bii)];
            ang=acosd(dot(v1,v2)/norm(v1-v2));
            if ang < 135
                epi(bi).xi(bii)=.5*(epi(bi).xi(sz)+epi(bi).xi(2));
                epi(bi).yi(bii)=.5*(epi(bi).yi(sz)+epi(bi).yi(2));
            end    
        elseif bii==sz
            v1=[epi(bi).xi(bii-1)-epi(bi).xi(bii), epi(bi).yi(1)-epi(bi).yi(bii)];
            v2=[epi(bi).xi(bii-1)-epi(bi).xi(bii), epi(bi).yi(1)-epi(bi).yi(bii)];
            if ang < 135
                epi(bi).xi(bii)=.5*(epi(bi).xi(bii-1)+epi(bi).xi(1));
                epi(bi).yi(bii)=.5*(epi(bi).yi(bii-1)+epi(bi).yi(1));
            end   
        else
            v1=[epi(bi).xi(bii-1)-epi(bi).xi(bii), epi(bi).xi(bii+1)-epi(bi).xi(bii)];
            v2=[epi(bi).yi(bii-1)-epi(bi).yi(bii), epi(bi).yi(bii+1)-epi(bi).yi(bii)];
            if ang < 135
                epi(bi).xi(bii)=.5*(epi(bi).xi(bii-1)+epi(bi).xi(bii+1));
                epi(bi).yi(bii)=.5*(epi(bi).yi(bii-1)+epi(bi).yi(bii+1));
            end   
        end
    end
    
    for bii=2:size(epi(bi).xi)-1
        epi(bi).xi(bii)=.5*epi(bi).xi(bii)+.25*(epi(bi).xi(bii-1)+epi(bi).xi(bii+1));
        epi(bi).yi(bii)=.5*epi(bi).yi(bii)+.25*(epi(bi).yi(bii-1)+epi(bi).yi(bii+1));
    end
    
    epi(bi).xi(sz+1)= epi(bi).xi(1);
    epi(bi).yi(sz+1)= epi(bi).yi(1);
    epi(bi).zi=ones(size(epi(bi).xi,1),1)*z_inc;
    epi(bi).zi(sz+1)= epi(bi).zi(1);
    
    endo(bi).xi=xi2;
    endo(bi).yi=yi2;
    sz=size(endo(bi).xi,1);
    ag_2= 0.5*(max(xi2)-min(xi2));
    bg_2= 0.5*(max(yi2)-min(yi2));
    
        for bii=1:size(endo(bi).xi,1)
        if bii==1
            v1=[endo(bi).xi(sz)-endo(bi).xi(bii), endo(bi).yi(bii+1)-endo(bi).yi(bii)];
            v2=[endo(bi).xi(sz)-endo(bi).xi(bii), endo(bi).yi(bii+1)-endo(bi).yi(bii)];
            ang=acosd(dot(v1,v2)/norm(v1-v2));
            if ang < 135
                endo(bi).xi(bii)=.5*(endo(bi).xi(sz)+endo(bi).xi(2));
                endo(bi).yi(bii)=.5*(endo(bi).yi(sz)+endo(bi).yi(2));
            end    
        elseif bii==sz
            v1=[endo(bi).xi(bii-1)-endo(bi).xi(bii), endo(bi).yi(1)-endo(bi).yi(bii)];
            v2=[endo(bi).xi(bii-1)-endo(bi).xi(bii), endo(bi).yi(1)-endo(bi).yi(bii)];
            if ang < 135
                endo(bi).xi(bii)=.5*(endo(bi).xi(bii-1)+endo(bi).xi(1));
                endo(bi).yi(bii)=.5*(endo(bi).yi(bii-1)+endo(bi).yi(1));
            end   
        else
            v1=[endo(bi).xi(bii-1)-endo(bi).xi(bii), endo(bi).xi(bii+1)-endo(bi).xi(bii)];
            v2=[endo(bi).yi(bii-1)-endo(bi).yi(bii), endo(bi).yi(bii+1)-endo(bi).yi(bii)];
            if ang < 135
                endo(bi).xi(bii)=.5*(endo(bi).xi(bii-1)+endo(bi).xi(bii+1));
                endo(bi).yi(bii)=.5*(endo(bi).yi(bii-1)+endo(bi).yi(bii+1));
            end   
        end
    end

    for bii=2:size(endo(bi).xi,1)-1
        endo(bi).xi(bii)=.5*endo(bi).xi(bii)+.25*(endo(bi).xi(bii-1)+endo(bi).xi(bii+1));
        endo(bi).yi(bii)=.5*endo(bi).yi(bii)+.25*(endo(bi).yi(bii-1)+endo(bi).yi(bii+1));
    end
    
% % %     [zg, ag, bg, alphag] = fitellipse([transpose(endo(bi).xi);transpose(endo(bi).yi)]);
% % %     e_endo = plotellipse(zg, ag_2, bg_2, 0, 'b');
% % %     sz=size(e_endo,2);
% % %     e_endo =e_endo(:,1:5:sz);
% % %     sz=size(e_endo,2);
    e_endo=fit_ellipse(endo(bi).xi,endo(bi).yi,45);
    endo(bi).xi=transpose(e_endo(1,:)); 
    endo(bi).yi=transpose(e_endo(2,:));
    
% % %     endo(bi).xi(sz+1)= endo(bi).xi(1);
% % %     endo(bi).yi(sz+1)= endo(bi).yi(1);
    endo(bi).zi=ones(size(endo(bi).xi,1),1)*z_inc;
% % %     endo(bi).zi(sz+1)= endo(bi).zi(1);
    
%     [zg, ag, bg, alphag] = fitellipse([transpose(epi(bi).xi);transpose(epi(bi).yi)]);
%     e_epi = plotellipse(zg, ag, bg, 0, 'b');
%     sz=size(e_epi,2);
%     e_epi =e_epi(:,1:5:sz);
%     sz=size(e_epi,2);
%     epi(bi).xi=transpose(e_epi(1,:)); 
%     epi(bi).yi=transpose(e_epi(2,:));
    e_epi=fit_ellipse(epi(bi).xi,epi(bi).yi,45);
    epi(bi).xi=transpose(e_epi(1,:)); 
    epi(bi).yi=transpose(e_epi(2,:));
%     
%     epi(bi).xi(sz+1)= epi(bi).xi(1);
%     epi(bi).yi(sz+1)= epi(bi).yi(1);
     epi(bi).zi=ones(size(epi(bi).xi,1),1)*z_inc;
%     epi(bi).zi(sz+1)= epi(bi).zi(1);
    
    if findmyo==2
        epi_s(bi)=epi(bi);
        endo_s(bi)=endo(bi);
    else
        epi_d(bi)=epi(bi);
        endo_d(bi)=endo(bi);
    end
    vert1=vert1_orig;;
    
    vert2=vert2_orig;;
    
    if findmyo ==1
        plot(epi(bi).xi,epi(bi).yi,'r*-');plot(endo(bi).xi,endo(bi).yi,'g*-');
    end

    end
    bi=bi+1;%close;
    
end

A_endo=[];
A_epi=[];
V=[];
% % % Acell = struct2cell(endo);
% % % sz = size(Acell);
% % % Acell = reshape(Acell, sz(1), []);      % Px(MxN)
% % % Acell = Acell'; 
% % % for i=1:size(endo,2)
% % % temp = cell2mat(Acell(i,3));
% % % temp=temp(1);
% % % Acell{i,3}=temp;
% % % end
% % % Acell = sortrows(Acell, 3);% (MxN)xP
% % % for i=1:size(endo,2)
% % % endo(i).xi=Acell{i,1};
% % % endo(i).yi=Acell{i,2};
% % % endo(i).zi=ones(size(Acell{i,1}))*Acell{i,3};
% % % end
% % % 
% % % Acell = struct2cell(epi);
% % % sz = size(Acell)
% % % Acell = reshape(Acell, sz(1), []);      % Px(MxN)
% % % Acell = Acell'; 
% % % for i=1:size(epi,2)
% % % temp = cell2mat(Acell(i,3));
% % % temp=temp(1);
% % % Acell{i,3}=temp;
% % % end
% % % Acell = sortrows(Acell, 3);% (MxN)xP
% % % for i=1:size(epi,2)
% % % epi(i).xi=Acell{i,1};
% % % epi(i).yi=Acell{i,2};
% % % epi(i).zi=ones(size(Acell{i,1}))*Acell{i,3};
% % % end
% % % 
% % % A_epi = ones(num_slices,1);
% % % A_endo = ones(num_slices,1);
% % % for i=1:num_slices
% % % A_endo(i)=polyarea(endo(i).xi,endo(i).yi);
% % % A_epi(i)=polyarea(epi(i).xi,epi(i).yi);
% % % end
% % % V=0;
% % % for i=1:num_slices-1
% % %     z1 = cell2mat(Acell(i,3));
% % %     z1=z1(1);
% % %     z2 = cell2mat(Acell(i+1,3));
% % %     z_inc =z1-z2(1);
% % %     V=V+0.5*abs(z_inc)*(A_epi(i)-A_endo(i)+A_epi(i+1)-A_endo(i+1));
% % % end

figure;hold
for bi=1:num_slices
    plot3(epi(bi).xi,epi(bi).yi,epi(bi).zi,'m*-');
    plot3(endo(bi).xi,endo(bi).yi,endo(bi).zi,'r*-');
end
view([1 1 1]);

% close(111);
% % if (xls_file)
% %     
% %     out_file=strcat(xls_file,'.xlsx');
% %     epi_array=[];
% %     for i=1:size(epi,2)
% %     sz = size(struct2array(epi(i)),1);
% %     epi_array=[epi_array;i*ones(sz,1),struct2array(epi(i))];
% %     end
% %     xlswrite(out_file,epi_array,'epi_array');
% %     endo_array=[];
% %     
% %     for i=1:size(endo,2)
% %     sz = size(struct2array(endo(i)),1);
% %     endo_array=[endo_array;i*ones(sz,1),struct2array(endo(i))];
% %     end;
% %     xlswrite(out_file,endo_array,'endo_array'); 
% %     
% %     xlswrite(out_file,A_endo,'A_endo'); 
% %     xlswrite(out_file,A_epi,'A_epi');  
% %      xlswrite(out_file,V,'Volume'); 
% %     
% % end

end


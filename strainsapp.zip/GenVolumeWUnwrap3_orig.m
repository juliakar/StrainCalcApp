function [endo_d, epi_d,endo_s, epi_s, A_endo, A_epi, V] =GenVolumeWUnwrap3( dirname,my_names,rect,LOESS_PAN,endoRatio,flipped)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% % % num_slices=3;
% % % slice_offset=1;
warning off;
NUMPTS=30;
% my_names=cell(0);
addpath(genpath(dirname));

if isempty(my_names)
disp('No magnitude files found');
        return;
end

all_names=my_names;
SEGDIV1=1;SEGDIV2=1;SEGDIV3=3;

fsegpair=cell(size(all_names,1),2);
sizediv=uint16(size(all_names,1)/3);
for i=1:size(all_names,1)
    fsegpair{i,2}=SEGDIV1;
    fsegpair{i,1}=all_names{i};
    if i>sizediv*2
        fsegpair{i,2}=SEGDIV3;
    end
%    curdir=all_names{i};
%     my_files=dir(strcat(topdir,curdir,'\'));
%     mynum=3;
%     dcminfo = dicominfo(my_files(mynum).name);
%     z_inc=dcminfo.SliceLocation;
end


num_slices=size(my_names,1);

dcmm=cell(num_slices);
dcmm2=cell(num_slices);
epi = struct('xi',[],'yi',[],'zi',[]);
endo = struct('xi',[],'yi',[],'zi',[]);

epi_d=epi;
epi_s=epi;
endo_d=endo;
endo_s=endo;

topdir=dirname;
addpath(genpath(topdir));


bi=1;
vert=[]
for i=1:size(my_names,1)
    fnum=5;
    curdir=my_names{i};
    
    DR_ELLIPSE=1;
    for findmyo = 1:2
        if findmyo==2
            fnum=12;
            DR_ELLIPSE=0;
        end
        
    my_files=dir(strcat(topdir,curdir,'\'));
%   rect=[44.5100   56.5100   51.9800   48.9800];
% fnum=5;
    dcminfo = dicominfo(my_files(fnum).name);
    z_inc=dcminfo.SliceLocation;
I2=imcrop(dicomread(my_files(fnum).name),rect);
I2=imfilter(I2,[5 5]);
[N, edges]=histcounts(I2,10);
I2=locallapfilt(I2, .2,.25);
I2=imsharpen(I2,'Radius',9,'Amount',20);
I2(I2<=edges(3))=edges(3);
thresh = multithresh(I2,8);
valuesMax = [ thresh max(I2(:)) ];
[qI2, index] = imquantize(I2, thresh, valuesMax);

if DR_ELLIPSE
    fnum=5;
    figure; 
    imagesc(I2),colormap gray;   
    hold;
    if isempty(vert)
        himel=imellipse;vert=wait(himel);
    else
        himel=imellipse(gca,[min(vert) max(vert)-min(vert)]);
        vert=wait(himel);
    end
    close;
end
    cent=[mean(vert(:,1)),mean(vert(:,2))];
    rx_max=0.5*(max(vert(:,1))-min(vert(:,1)));
    ry_max=0.5*(max(vert(:,2))-min(vert(:,2)));
    adivs=5;
    isize_max=int16(360/adivs);
    px_bound=rx_max*(cosd([1:adivs:360]))+cent(1,1);
    py_bound=ry_max*(sind([1:adivs:360]))+cent(1,2);
    px_bound=px_bound';py_bound=py_bound';
    
    moved=zeros(isize_max,1);
    px_max=[];
    py_max=[];
    px_ind=[];
    py_ind=[];
    isize_ind=0;
    for rx=0.5*rx_max:1:rx_max
        for ry=0.5*ry_max:1:ry_max
%     for rx=rx_max:-1:0.5*rx_max
%         for ry=ry_max:-1:0.5*ry_max
            for cx = cent(1,1)-5:1:cent(1,1)+5
                for cy = cent(1,2)-5:1:cent(1,2)+5
                    px=rx*(cosd([1:adivs:360]))+cx;
                    py=ry*(sind([1:adivs:360]))+cy;
                    px=px';py=py';
                    intensities=[];
                    if sum(inpolygon(px,py,px_bound,py_bound))==size(px_bound,1)
                        for q=1:size(px,1)
                            intensities=[intensities;qI2(uint16(py(q)),uint16(px(q)))];
                        end
                        aspect = (max(px)-min(px))/(max(py)-min(py));
                        isize=size(find(intensities>min(qI2(:))),1);
                        if isize >= isize_max
%                             px_max=px;
%                             py_max=py;
                        end
                        if isize >= isize_ind && aspect >= 1
                            px_ind=px;
                            py_ind=py;
                            isize_ind=isize;
                        end
                    end
                end
            end
        end 
    end
    if isempty(px_max) && isempty(py_max)
        px_max=px_ind;
        py_max=py_ind;
    end
      
    px_max=flip(px_max);
    py_max=flip(py_max);
    px_orig=px_max;py_orig=py_max;
    
    px_min=px_orig;
    py_min=py_orig;
    cent=[mean(px_min),mean(py_min)];
    for p=1:size(px_min,1)
        [ix iy c]=improfile(qI2,[px_min(p);cent(1,1)],[py_min(p);cent(1,2)]);
        idx=find(c==min(qI2(:)));
        if isempty(idx)
        else
            px_min(p)=ix(idx(1));
            py_min(p)=iy(idx(1));
        end
    end
    
    cent=[mean(px_max), mean(py_max)];
    otsu_range=unique(qI2(:));
    thickness=zeros(size(px_max));
    for p=1:size(px_max,1)
        changed=0;
        or=0;
        while changed == 0
            or=or+1;
            if or > 4 % == size(otsu_range,1)
                break;
            end
            ix=px_max(p);
            iy=py_max(p);
            old_range=qI2(uint16(iy),uint16(ix));
            for del=1:20
                ix=(px_max(p)-cent(1,1))*(1+.05*del)+cent(1,1);
                iy=(py_max(p)-cent(1,2))*(1+.05*del)+cent(1,2);
                if changed==0 && inpolygon(ix,iy,px_bound,py_bound)
                    if iy <= size(qI2,1) && qI2(uint16(iy),uint16(ix)) == otsu_range(or)
%                         if or >1 && otsu_range(or) == old_range
%                         else
                            
                            if  p>1 && sqrt((px_max(p-1)-ix).^2+(py_max(p-1)-iy).^2) > 5
                            else
                                px_max(p)=ix;
                                py_max(p)=iy;
                                changed=1;
                                moved(p)=changed;
                            end
                            thk = sqrt((px_max(p)-px_min(p)).^2+(py_max(p)-py_min(p)).^2);
                            if or == 1
                                thickness(p) = thk;
                            end
%                         end
                        
                        old_range=otsu_range(or) ;
                    end
                end
            end
        end
    end
    
%     plot(px_orig,py_orig,'g.-')
%     plot(px_max,py_max,'m+')
    px_max=[px_max;px_max(1)];
    py_max=[py_max;py_max(1)];  
    temp=fLOESS((px_max), .175);
    px_max=(temp);
    temp=fLOESS((py_max), .175);
    py_max=(temp);
    
    xyz=[px_max,py_max]';
    pts=my_fnplt(cscvn(xyz(:,[1:end 1])),'m-.',1.5);
%     plot(pts(1,:),pts(2,:),'r');
    px_min=[px_min;px_min(1)];
    py_min=[py_min;py_min(1)];  
    temp=fLOESS((px_min), .175);
    px_min=(temp);
    temp=fLOESS((py_min), .175);
    py_min=(temp);
    xyz=[px_min,py_min]';
    pts=my_fnplt(cscvn(xyz(:,[1:end 1])),'m-.',1.5);
%     plot(pts(1,:),pts(2,:),'r');
epi0=[px_max,py_max];
endo0=[px_min,py_min];

POLY_EDIT=1;
if POLY_EDIT && findmyo==1
    figure;
    imagesc(qI2),colormap gray;
    hold;
    xlim(gca,[min(epi0(:,1))-5,max(epi0(:,1))+5]);
    ylim(gca,[min(epi0(:,2))-5,max(epi0(:,2))+5]);
%     plot(epi0(:,1),epi0(:,2),'r');
%     plot(endo0(:,1),endo0(:,2),'g');
%     plot(raw_epi(:,1),raw_epi(:,2),'r');
%     plot(raw_endo(:,1),raw_endo(:,2),'g');

    
    yy=[];xx=[];
    x0=endo0(:,1);
    y0=endo0(:,2);
    x0=decimate(x0,2,9);
    y0=decimate(y0,2,9);
    
    h=impoly(gca,[x0,y0]);
    raw_endo=wait(h);
    x0=raw_endo(:,1);
    y0=raw_endo(:,2);
    xx=[];yy=[];
    for xy=1:size(x0,1)-1
        xx(xy)=0.5*(x0(xy)+x0(xy+1));
        if abs(x0(xy)-x0(xy+1)) >.001 && abs(y0(xy)-y0(xy+1)) >.001
            yy(xy)=spline(x0(xy:xy+1),y0(xy:xy+1),xx(xy));
        else
            yy(xy)=0.5*(y0(xy)+y0(xy+1));
        end
    end
    xx=xx';yy=yy';
    x2=interleave2(x0,xx,'row');
    y2=interleave2(y0,yy,'row');
    raw_endo=[x2,y2];
    if size(raw_endo,1) == size(endo0,1)
        raw_endo(end,:)=raw_endo(1,:);
    else
        raw_endo(end+1,:)=raw_endo(1,:);
    end
        
    yy=[];xx=[];
    x0=epi0(:,1);
    y0=epi0(:,2);
    x0=decimate(x0,2,9);
    y0=decimate(y0,2,9);
    
    h=impoly(gca,[x0,y0]);
    raw_epi=wait(h);
    x0=raw_epi(:,1);
    y0=raw_epi(:,2);
    xx=[];yy=[];
    for xy=1:size(x0,1)-1
        xx(xy)=0.5*(x0(xy)+x0(xy+1));
        yy(xy)=spline(x0(xy:xy+1),y0(xy:xy+1),xx(xy));
    end
    xx=xx';yy=yy';
    x2=interleave2(x0,xx,'row');
    y2=interleave2(y0,yy,'row');
    raw_epi=[x2,y2];
    if size(raw_epi,1) == size(epi0,1)
        raw_epi(end,:)=raw_epi(1,:);
    else
        raw_epi(end+1,:)=raw_epi(1,:);
    end
    close 
else
    raw_epi=epi0;
    raw_endo=endo0;
end
% close all;
I3=imcrop(dicomread(my_files(fnum).name),rect);
I3=imfilter(I3,[5 5]);
[N, edges]=histcounts(I3,10);
% I3=locallapfilt(I2, .2,.25);
% I3=imsharpen(I3,'Radius',9,'Amount',20);
I3(I3<=edges(3))=edges(3);
figure
imagesc(I3),colormap gray
hold;
plot(raw_epi(:,1),raw_epi(:,2),'*-r')
plot(cent(:,1),cent(:,2),'*r')
plot(raw_endo(:,1),raw_endo(:,2),'g*-')
% epi_ellipse= fit_ellipse(b_epi{bi-1}(:,1),b_epi{bi-1}(:,2),NUMPTS);
% endo_ellipse= fit_ellipse(b_endo{bi-1}(:,1),b_endo{bi-1}(:,2),NUMPTS);
epi_ellipse= [transpose(raw_epi(:,1));transpose(raw_epi(:,2))];
endo_ellipse= [transpose(raw_endo(:,1));transpose(raw_endo(:,2))];

% plot(epi_ellipse(1,:),epi_ellipse(2,:),'r-o')
% plot(endo_ellipse(1,:),endo_ellipse(2,:),'g-o')   

% LOESS_PAN=.5;
% % temp=fLOESS([transpose(endo_ellipse(1,:))], LOESS_PAN);
% % endo_ellipse(1,:)=transpose(temp(1:size(endo_ellipse,2)));
% % temp=fLOESS([transpose(endo_ellipse(2,:))], LOESS_PAN);
% % endo_ellipse(2,:)=transpose(temp(1:size(endo_ellipse,2)));
% % temp=fLOESS([transpose(epi_ellipse(1,:))], LOESS_PAN);
% % epi_ellipse(1,:)=transpose(temp(1:size(epi_ellipse,2)));
% % temp=fLOESS([transpose(epi_ellipse(2,:))], LOESS_PAN);
% % epi_ellipse(2,:)=transpose(temp(1:size(epi_ellipse,2)));
corners=repmat([0 0 0 0 0 0],1,100);
xyz=[decimate(epi_ellipse(1,:)',5,9),decimate(epi_ellipse(2,:)',5,9)]';
sz=size(xyz,2);
cvec=corners(1:sz+1);
[pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
s = unique([linspace(0,pp.breaks(end),100),sparam]);
pts = fnval(pp,s);
epi_ellipse=pts;
% epi_ellipse(1,:)=pts(1,:)';
% epi_ellipse(2,:)=pts(2,:)';
sz=size(epi_ellipse(1,:),1);
epi_ellipse(1,sz+1)=epi_ellipse(1,1);
epi_ellipse(2,sz+1)=epi_ellipse(2,1);

xyz=[decimate(endo_ellipse(1,:)',5,9),decimate(endo_ellipse(2,:)',5,9)]';
sz=size(xyz,2);
cvec=corners(1:sz+1);
[pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
s = unique([linspace(0,pp.breaks(end),100),sparam]);
pts = fnval(pp,s);
endo_ellipse=pts;
% endo_ellipse(1,:)=pts(1,:)';
% endo_ellipse(2,:)=pts(2,:)';
sz=size(endo_ellipse(1,:),1);
endo_ellipse(1,sz+1)=endo_ellipse(1,1);
endo_ellipse(2,sz+1)=endo_ellipse(2,1);

for bii=2:size(epi_ellipse,2)-1
        temp=((epi_ellipse(1,:)-epi_ellipse(1,bii)).^2+...
            (epi_ellipse(2,:)-epi_ellipse(2,bii)).^2).^.5;
        [~,id]=sort(temp);
        u = [epi_ellipse(1,id(2))-epi_ellipse(1,bii), epi_ellipse(2,id(2))-epi_ellipse(2,bii)];
        v = [epi_ellipse(1,id(3))-epi_ellipse(1,bii), epi_ellipse(2,id(3))-epi_ellipse(2,bii)];
        Theta = acosd(dot(u,v)/(norm(u)*norm(v)));
        if Theta < 170
            epi_ellipse(1,bii)=0.5*(epi_ellipse(1,id(2))+epi_ellipse(1,id(3)));
            epi_ellipse(2,bii)=0.5*(epi_ellipse(2,id(2))+epi_ellipse(2,id(3)));
        end
end
    epi_ellipse(:,size(epi_ellipse,2))=epi_ellipse(:,1);
    for bii=1:size(endo_ellipse,2)
        temp=((endo_ellipse(1,:)-endo_ellipse(1,bii)).^2+...
            (endo_ellipse(2,:)-endo_ellipse(2,bii)).^2).^.5;
        [~,id]=sort(temp);
        u = [endo_ellipse(1,id(2))-endo_ellipse(1,bii), endo_ellipse(2,id(2))-endo_ellipse(2,bii)];
        v = [endo_ellipse(1,id(3))-endo_ellipse(1,bii), endo_ellipse(2,id(3))-endo_ellipse(2,bii)];
        Theta = acosd(dot(u,v)/(norm(u)*norm(v)));
        if Theta < 170
            endo_ellipse(1,bii)=0.5*(endo_ellipse(1,id(2))+endo_ellipse(1,id(3)));
            endo_ellipse(2,bii)=0.5*(endo_ellipse(2,id(2))+endo_ellipse(2,id(3)));
        end
    end
       endo_ellipse(:,size(endo_ellipse,2))=endo_ellipse(:,1); 
        
plot(epi_ellipse(1,:),epi_ellipse(2,:),'r-o')
plot(endo_ellipse(1,:),endo_ellipse(2,:),'g-o')   
gen_epi{fnum}=epi_ellipse;
gen_endo{fnum}=endo_ellipse;

    endo(bi).xi=transpose(endo_ellipse(1,:)); 
    endo(bi).yi=transpose(endo_ellipse(2,:));
    endo(bi).zi=ones(size(endo(bi).xi,1),1)*z_inc;
    epi(bi).xi=transpose(epi_ellipse(1,:)); 
    epi(bi).yi=transpose(epi_ellipse(2,:));
     epi(bi).zi=ones(size(epi(bi).xi,1),1)*z_inc;
    
    if findmyo==2
        epi_s(bi)=epi(bi);
        endo_s(bi)=endo(bi);
    else
        epi_d(bi)=epi(bi);
        endo_d(bi)=endo(bi);
    end
    if findmyo ==1
        plot(epi(bi).xi,epi(bi).yi,'r*-');plot(endo(bi).xi,endo(bi).yi,'g*-');
    end

    end
    bi=bi+1;%close;
    
end

A_endo=[];
A_epi=[];
V=[];
% % % figure;hold
% % % for bi=1:num_slices
% % %     plot3(epi(bi).xi,epi(bi).yi,epi(bi).zi,'m*-');
% % %     plot3(endo(bi).xi,endo(bi).yi,endo(bi).zi,'r*-');
% % % end
% % % view([1 1 1]);
% % % Acell = struct2cell(endo);
% % % sz = size(Acell);
% % % Acell = reshape(Acell, sz(1), []);      % Px(MxN)
% % % Acell = Acell'; 
% % % for i=1:size(endo,2)
% % % temp = cell2mat(Acell(i,3));
% % % temp=temp(1);
% % % Acell{i,3}=temp;
% % % end
% % % Acell = sortrows(Acell, 3);% (MxN)xP
% % % for i=1:size(endo,2)
% % % endo(i).xi=Acell{i,1};
% % % endo(i).yi=Acell{i,2};
% % % endo(i).zi=ones(size(Acell{i,1}))*Acell{i,3};
% % % end
% % % 
% % % Acell = struct2cell(epi);
% % % sz = size(Acell)
% % % Acell = reshape(Acell, sz(1), []);      % Px(MxN)
% % % Acell = Acell'; 
% % % for i=1:size(epi,2)
% % % temp = cell2mat(Acell(i,3));
% % % temp=temp(1);
% % % Acell{i,3}=temp;
% % % end
% % % Acell = sortrows(Acell, 3);% (MxN)xP
% % % for i=1:size(epi,2)
% % % epi(i).xi=Acell{i,1};
% % % epi(i).yi=Acell{i,2};
% % % epi(i).zi=ones(size(Acell{i,1}))*Acell{i,3};
% % % end
% % % 
% % % A_epi = ones(num_slices,1);
% % % A_endo = ones(num_slices,1);
% % % for i=1:num_slices
% % % A_endo(i)=polyarea(endo(i).xi,endo(i).yi);
% % % A_epi(i)=polyarea(epi(i).xi,epi(i).yi);
% % % end
% % % V=0;
% % % for i=1:num_slices-1
% % %     z1 = cell2mat(Acell(i,3));
% % %     z1=z1(1);
% % %     z2 = cell2mat(Acell(i+1,3));
% % %     z_inc =z1-z2(1);
% % %     V=V+0.5*abs(z_inc)*(A_epi(i)-A_endo(i)+A_epi(i+1)-A_endo(i+1));
% % % end



% close(111);
% % if (xls_file)
% %     
% %     out_file=strcat(xls_file,'.xlsx');
% %     epi_array=[];
% %     for i=1:size(epi,2)
% %     sz = size(struct2array(epi(i)),1);
% %     epi_array=[epi_array;i*ones(sz,1),struct2array(epi(i))];
% %     end
% %     xlswrite(out_file,epi_array,'epi_array');
% %     endo_array=[];
% %     
% %     for i=1:size(endo,2)
% %     sz = size(struct2array(endo(i)),1);
% %     endo_array=[endo_array;i*ones(sz,1),struct2array(endo(i))];
% %     end;
% %     xlswrite(out_file,endo_array,'endo_array'); 
% %     
% %     xlswrite(out_file,A_endo,'A_endo'); 
% %     xlswrite(out_file,A_epi,'A_epi');  
% %      xlswrite(out_file,V,'Volume'); 
% %     
% % end

end


function [ x y z] = closedplot(x,y,z,arg)  
    x = [x(:) ; x(1)];   
    y = [y(:) ; y(1)];  
    z = [z(:) ; z(1)];  
    plot3(x,y,z,arg)  
end

% if SHOW_SEG_ORIENT
%     mystr=[];
%     cols = ['k';'r';'m';'y';'c';'g'];
%     figure;hold;
%     k=1;
%     for i=1:2:12
%     plot3(segs(i:i+1,1),segs(i:i+1,2),segs(i:i+1,3),'color',cols(k),'marker','*','LineStyle','none');k=k+1;
%     mystr = [mystr; strcat(num2str(i),'-',num2str(i+1))];
%     legend(mystr);
%     end
%     for i=1:size(endo_set,1)
%     closedplot(walls(endo_set(i,1):endo_set(i,2),1), walls(endo_set(i,1):endo_set(i,2),2), walls(endo_set(i,1):endo_set(i,2),3),'b-.');
%     end
%     for i=1:size(epi_set,1)
%     closedplot(walls(epi_set(i,1):epi_set(i,2),1), walls(epi_set(i,1):epi_set(i,2),2), walls(epi_set(i,1):epi_set(i,2),3),'b');
%     end
%     
% end

function [ V, endo, epi, A_endo, A_epi] =GenVolume( dirname,pix_cont,xls_file)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
% % % num_slices=3;
% % % slice_offset=1;
warning off;
% % if exist('num_slices', 'var')
% % else
% %     disp('num_slices not specified');
% %     return;
% % end
% % if exist('slice_offset', 'var')
% % else
% %     disp('slice_offset not specified');
% %     return;
% % end
% % close all;

if exist('xls_file', 'var')
else
    disp('XLS file name not specified');
    return;
end
I=[];
k=1;
my_names=cell(0);
% % % dirname='C:\Images\Normals\DK_080515_001\all_images\';
addpath(genpath(dirname));
MYDIR=dir(dirname);
[~, indices] = sort({MYDIR.name});

MYDIR = MYDIR(indices);
myans=[];

for i=1:size(MYDIR,1) 
    myans=findstr(MYDIR(i).name,'AVEMAG');
    if isempty(myans)
        myans=findstr(MYDIR(i).name,'RO-ENC_MAG');
    end
    if isempty(myans)
    else
        my_names{k}=strcat(dirname,MYDIR(i).name); k=k+1;
    end
end
if isempty(my_names)
disp('No magnitude files found');
        return;
end
ims=dir(my_names{3});
ims=ims(6:size(ims,1));
dcminfo=dicominfo(ims(1).name);
width=dcminfo.Width;
length=dcminfo.Height;
% % dcmm=zeros(width,length,size(ims,1));
% % for i=1:size(ims,1)
% %     dcmm(:,:,i)=dicomread(ims(i).name);
% % end

I=dicomread(ims(1).name);; 
crop=struct('cropi',[],'cropj',[]);
if isempty(crop.cropi)
    % Crop image
    figure,imagesc(I(:,:)),axis image,colormap gray
    title('Crop image - Pick 1 point upper left and one point lower right')
    [x y] = ginput(2);
    
    cropi = min(round(y)):max(round(y));
    crop.cropi=cropi;
    cropj = min(round(x)):max(round(x));
    crop.cropj=cropj;
    close;
end

    h=figure;
    title('Create epicardium');
    I = I(min(crop.cropi):max(crop.cropi),min(crop.cropj):max(crop.cropj));
    %BW = I > ceil(pix_cont*max(max(I)));
    BW=1-isnan(discretize(I,ceil(1.2*mean(mean(I))):max(max(I))));
    imagesc(BW),colormap gray;
    hold;
    movegui(h,'east');
     ButtonName=questdlg('Specify if current resolution can be used?', ...
                         'Pixel Resolution', ...
                         'Yes', 'Cancel','Yes');
   switch ButtonName,
     case 'Yes',
      disp('Your current contrast is'); pix_cont
     case 'Cancel',
      close(h);
      return;
   end % sw
   close;

%slice_sel=zeros(size(my_names,2));
pos=[];
for i=1:size(my_names,2)
    ims=dir(my_names{i});
    ims=ims(6:size(ims,1));
    dcminfo = dicominfo(ims(1).name);
    pos=[pos;dcminfo.SliceLocation];
end
[~, order] = sort(pos);
slice_sel=[];
for i=transpose(order)
    ims=dir(my_names{i});
    ims=ims(6);
    I=dicomread(ims.name);
    I = I(min(crop.cropi):max(crop.cropi),min(crop.cropj):max(crop.cropj));
    h=figure;
    title('Create epicardium');
    
    imagesc(I),colormap gray;
    movegui(h,'east');
    ButtonName=questdlg('Specify if current slice should be used?', ...
                         'Slice Selection', ...
                         'Yes', 'No','Yes');
   switch ButtonName,
     case 'Yes',
      slice_sel=[slice_sel,i];
     case 'No',
      %%slice_sel(k)=i;
   end % switch
   close;
end
%pos(find(slice_sel==0))=[];
%slice_sel(find(slice_sel==0))=[];
num_slices=size(slice_sel,2);


dcmm=zeros(length,width,num_slices);
epi = struct('xi',[],'yi',[],'zi',[]);
endo = struct('xi',[],'yi',[],'zi',[]);


bi=1;
for i=slice_sel
    ims=dir(my_names{i});
    ims=ims(6:size(ims,1));

    dcmm(:,:,i)=dicomread(ims(1).name);
    %dcminfo = dicominfo(ims(1).name);
    z_inc=pos(i);

    I=dcmm(:,:,i);
    I = I(min(crop.cropi):max(crop.cropi),min(crop.cropj):max(crop.cropj));
    I2=I;
    h2=figure;
    title('Guide image');
    imagesc(I2),colormap gray;
    hold;
    movegui(h2,'center');
    h=figure;
    title('Create epicardium');
    %BW = I > ceil(pix_cont*max(max(I)));
    BW=1-isnan(discretize(I,ceil(1.2*mean(mean(I))):max(max(I))));
    imagesc(BW),colormap gray;
    hold;
    movegui(h,'east');
    title('Create epicardium');
    himel=imellipse;vert1=wait(himel);
    title('Create endocardium');
    himel2=imellipse;vert2=wait(himel2);
    % wait(he);pos = getVertices(he);
    % [x y]=getline(h);
    c=[mean([vert1(:,1);vert2(:,1)]) mean([vert1(:,2) ;vert2(:,2)])];
    d=sqrt((x(1)-x(2))^2+(y(1)-y(2))^2);
    xi=vert1(:,1) ;
    yi=vert1(:,2);
    xi2=vert2(:,1) ;
    yi2=vert2(:,2);
    close(h);
    close(h2);
    figure;
%     ims=dir(my_names{i+1});
%     ims=ims(6:size(ims,1));
% 
%     dcmm(:,:,i)=dicomread(ims(1).name);
% 
    I=dcmm(:,:,i);
    I = I(min(crop.cropi):max(crop.cropi),min(crop.cropj):max(crop.cropj));
    %BW = I>ceil(pix_cont*max(max(I)));;
    BW=1-isnan(discretize(I,ceil(1.2*mean(mean(I))):max(max(I))));
    imagesc(BW),colormap gray
    hold;
     c=[mean([vert1(:,1)]) mean([vert1(:,2)])];
    subdivs=150;
    for t=1:size(vert1,1)
        ti=[(vert1(t,1)-c(1))/subdivs ,(vert1(t,2)-c(2))/subdivs ];
        prev_temp =0; 
        stop_srch=0;
        for di=1:subdivs
            temp = impixel(BW,ceil(vert1(t,1)-(di-1)*ti(1,1)),ceil(vert1(t,2)-(di-1)*ti(1,2)));
            
            if temp(1) > 0 &&stop_srch ==0
                xi(t)= vert1(t,1)-di*ti(1,1);
                yi(t)=vert1(t,2)-di*ti(1,2);
                stop_srch=1;
            else
               % stop_srch=0;
            end
            prev_temp = temp(1);
        end
    end
    c=[mean([vert2(:,1)]) mean([vert2(:,2)])];
    t_steps = zeros(size(vert2,1),1);
    for t=1:size(vert2,1)
        ti=[(vert2(t,1)-c(1))/subdivs ,(vert2(t,2)-c(2))/subdivs ];
        prev_temp =0; 
        stop_srch=0;
        for di=1:subdivs
            temp = impixel(BW,ceil(vert2(t,1)-(di-1)*ti(1,1)),ceil(vert2(t,2)-(di-1)*ti(1,2)));
            
            if temp(1) == 0 &&stop_srch ==0
                xi2(t)= vert2(t,1)-di*ti(1,1);
                yi2(t)=vert2(t,2)-di*ti(1,2);
                stop_srch=1;
                t_steps(t) = t_steps(t)+1;
            else
                if stop_srch ==0
                    t_steps(t) = t_steps(t)+1;% stop_srch=0;
                end
            end
            
        end
    end
    t_steps_med = mean(t_steps);
    t_steps_med = t_steps_med(1);
    t_steps = zeros(size(vert2,1),1);
    for t=1:size(vert2,1)
        ti=[(vert2(t,1)-c(1))/subdivs ,(vert2(t,2)-c(2))/subdivs ];
        prev_temp =0; 
        stop_srch=0;
        xi2(t)= vert2(t,1);
        yi2(t)=vert2(t,2);
        for di=1:subdivs
            temp = impixel(BW,ceil(vert2(t,1)-(di-1)*ti(1,1)),ceil(vert2(t,2)-(di-1)*ti(1,2)));
            
            if temp(1) == 0 &&stop_srch ==0 &&t_steps(t) < t_steps_med
                xi2(t)= vert2(t,1)-di*ti(1,1);
                yi2(t)=vert2(t,2)-di*ti(1,2);
                stop_srch=1;
                t_steps(t) = t_steps(t)+1;
            else
                if stop_srch ==0
                    t_steps(t) = t_steps(t)+1;% stop_srch=0;
                end
            end
            
        end
    end
%     vert1(:,1)= (vert1(:,1)+(xi))/2;
%     vert1(:,2)= (vert1(:,2)+(yi))/2;
%     vert2(:,1)= (vert2(:,1)+(xi2))/2;
%     vert2(:,2)= (vert2(:,2)+(yi2))/2;

    [zg, ag, bg, alphag] = fitellipse([transpose(xi);transpose(yi)]);
    e_epi = plotellipse(zg, ag, bg, alphag, 'b');
    sz=size(e_epi,2);
    e_epi =e_epi(:,1:5:sz);
    epi(bi).xi=transpose(e_epi(1,:));
    epi(bi).yi=transpose(e_epi(2,:));
   
    epi(bi).xi=xi;
    epi(bi).yi=yi;
    epi(bi).zi=ones(size(epi(bi).xi,1),1)*z_inc;
    [zg, ag, bg, alphag] = fitellipse([transpose(xi2);transpose(yi2)]);
    e_endo = plotellipse(zg, ag, bg, alphag, 'b');
    sz=size(e_endo,2);
    e_endo =e_endo(:,1:5:sz);
    endo(bi).xi=transpose(e_endo(1,:));
    endo(bi).yi=transpose(e_endo(2,:));
    endo(bi).xi=xi2;
    endo(bi).yi=yi2;
   
    endo(bi).zi=ones(size(endo(bi).xi,1),1)*z_inc;
    plot(epi(bi).xi,epi(bi).yi,'c*-');plot(endo(bi).xi,endo(bi).yi,'g*-');
    bi=bi+1;%close;
end

Acell = struct2cell(endo);
sz = size(Acell);
Acell = reshape(Acell, sz(1), []);      % Px(MxN)
Acell = Acell'; 
for i=1:size(endo,2)
temp = cell2mat(Acell(i,3));
temp=temp(1);
Acell{i,3}=temp;
end
Acell = sortrows(Acell, 3);% (MxN)xP
for i=1:size(endo,2)
endo(i).xi=Acell{i,1};
endo(i).yi=Acell{i,2};
endo(i).zi=ones(size(Acell{i,1}))*Acell{i,3};
end

Acell = struct2cell(epi);
sz = size(Acell)
Acell = reshape(Acell, sz(1), []);      % Px(MxN)
Acell = Acell'; 
for i=1:size(epi,2)
temp = cell2mat(Acell(i,3));
temp=temp(1);
Acell{i,3}=temp;
end
Acell = sortrows(Acell, 3);% (MxN)xP
for i=1:size(epi,2)
epi(i).xi=Acell{i,1};
epi(i).yi=Acell{i,2};
epi(i).zi=ones(size(Acell{i,1}))*Acell{i,3};
end

A_epi = ones(num_slices,1);
A_endo = ones(num_slices,1);
for i=1:num_slices
A_endo(i)=polyarea(endo(i).xi,endo(i).yi);
A_epi(i)=polyarea(epi(i).xi,epi(i).yi);
end
V=0;
for i=1:num_slices-1
    z1 = cell2mat(Acell(i,3));
    z1=z1(1);
    z2 = cell2mat(Acell(i+1,3));
    z_inc =z1-z2(1);
    V=V+0.5*abs(z_inc)*(A_epi(i)-A_endo(i)+A_epi(i+1)-A_endo(i+1));
end

figure;hold
for bi=1:num_slices
    plot3(epi(bi).xi,epi(bi).yi,epi(bi).zi,'m*-');
    plot3(endo(bi).xi,endo(bi).yi,endo(bi).zi,'r*-');
end
view([1 1 1]);

% close(111);
if (xls_file)
    
    out_file=strcat(xls_file,'.xlsx');
    epi_array=[];
    for i=1:size(epi,2)
    sz = size(struct2array(epi(i)),1);
    epi_array=[epi_array;i*ones(sz,1),struct2array(epi(i))];
    end
    xlswrite(out_file,epi_array,'epi_array');
    endo_array=[];
    
    for i=1:size(endo,2)
    sz = size(struct2array(endo(i)),1);
    endo_array=[endo_array;i*ones(sz,1),struct2array(endo(i))];
    end;
    xlswrite(out_file,endo_array,'endo_array'); 
    
    xlswrite(out_file,A_endo,'A_endo'); 
    xlswrite(out_file,A_epi,'A_epi');  
     xlswrite(out_file,V,'Volume'); 
    
end

end


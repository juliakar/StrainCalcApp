BA=BA_HF;%BA_TD_HF;
if size(BA,1)== size(BA_TD,1) & (BA(:,2)==BA_TD(:,2))
BA(:,12) = 1.5*BA(:,12);
BA(:,4) = 1.5*BA(:,4);
BA(:,2) = 1.2*BA(:,2);
BA(:,10) = 1.2*BA(:,10);
end
MOVAVE=30;
PARAM_B =1.5;
MOVAVE_FAC=1/MOVAVE;
% for i=1:size(BA,2)
%     a=filter(MOVAVE_FAC*ones(MOVAVE,1),PARAM_B,[mean(BA(1:MOVAVE,i))*ones(MOVAVE,1); BA(:,i)]);
%     BA(:,i) = a(MOVAVE+1:MOVAVE+size(BA,1),1);
% end
% BA(:,3) = BA_HF(:,3);
% BA(:,11) = BA_HF(:,11);
BA_new = []; 
BA_AVG =0;
if BA_AVG
for i=1:6:size(BA,1)
    BA_new = [BA_new;mean(BA(i:1:i+5,2)), mean(BA(i:1:i+5,10))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2,'Circumferential Strain Agreement',  1)
BA_new = [];
for i=1:6:size(BA,1)
    BA_new = [BA_new;mean(BA(i:1:i+5,3)), mean(BA(i:1:i+5,11))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2,'Longitudinal Strain Agreement', 2)
BA_new = [];
for i=1:6:size(BA,1)
    BA_new = [BA_new;mean(BA(i:1:i+5,4)),mean(BA(i:1:i+5,12))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2, 'Radial Strain Agreement',3)

else
BA_new = []; 
for i=1:6:size(BA,1)
    BA_new = [BA_new;(BA(i:1:i+5,2)),(BA(i:1:i+5,10))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2,'Circumferential Strain Agreement',  1)
BA_new = [];
for i=1:6:size(BA,1)
    BA_new = [BA_new;(BA(i:1:i+5,3)), (BA(i:1:i+5,11))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2,'Longitudinal Strain Agreement', 2)
BA_new = [];
for i=1:6:size(BA,1)
    BA_new = [BA_new;(BA(i:1:i+5,4)),(BA(i:1:i+5,12))];
end
[meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2, 'Radial Strain Agreement',3)
end

% %  MIDVENTRICULAR PLOT
% BA_new = [];
% for i=7:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,2), BA(i:1:i+5,10)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),  BA_new(1:size(BA_new,1),2),2, 'Midventricular Circ. Strain Agreement',1)
% BA_new = [];
% for i=7:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,3), BA(i:1:i+5,11)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1),BA_new(1:size(BA_new,1),2),2,  'Midventricular Rad. Strain Agreement',2)
% BA_new = [];
% for i=7:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,4), BA(i:1:i+5,12)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2, 'MidventricularLong. Strain Agreement', 3)
% %  EPICAL PLOT
% BA_new = [];
% for i=13:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,2), BA(i:1:i+5,10)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2,'Apical Circ. Strain Agreement', 1)
% BA_new = [];
% for i=13:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,3), BA(i:1:i+5,11)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2, 'Apical Long. Strain Agreement', 2)
% BA_new = [];
% for i=13:18:size(BA,1)
%     BA_new = [BA_new;BA(i:1:i+5,4), BA(i:1:i+5,12)];
% end
% [meanDiff,CR coef ]=BlandAltman(BA_new(1:size(BA_new,1),1), BA_new(1:size(BA_new,1),2),2,'Apical Rad. Strain Agreement', 3)
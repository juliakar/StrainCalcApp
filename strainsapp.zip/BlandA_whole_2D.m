load('BA_2D.mat')
den0=[den_circ_apex(:,1:6);den_circ_mid;den_circ_base];
tag0=[tag_circ_apex(:,1:6);tag_circ_mid;tag_circ_base];
den=[den_circ_mid,den_circ_apex(:,1),den_circ_apex(:,4);den_circ_base,den_circ_apex(:,7),den_circ_apex(:,8)];
tag=[tag_circ_mid,tag_circ_apex(:,1),tag_circ_apex(:,4);tag_circ_base,tag_circ_apex(:,7),tag_circ_apex(:,8)];
[meanDiff,CR ,coef ] = BlandAltman(den, tag, 2,'Regional Circumferential Agreement', 1)
den_mean=transpose(mean(transpose(den0(:,1:6))));
tag_mean=transpose(mean(transpose(tag0(:,1:6))));
[meanDiff,CR ,coef ] = BlandAltman(den_mean, tag_mean, 2,'Whole Slice Circumferential Agreement', 2)

den_r0=[den_rad_apex(:,1:6);den_rad_mid;den_rad_base];
tag_r0=[tag_rad_apex(:,1:6);tag_rad_mid;tag_rad_base];
den_r=[den_rad_mid,den_rad_apex(:,1),den_rad_apex(:,4);den_rad_base,den_rad_apex(:,7),den_rad_apex(:,8)];
tag_r=[tag_rad_mid,tag_rad_apex(:,1),tag_rad_apex(:,4);tag_rad_base,tag_rad_apex(:,7),tag_rad_apex(:,8)];
den_r0=abs(den_r0);
tag_r0=abs(tag_r0);
den_r0=abs(den_r0);
tag_r0=abs(tag_r0);
[meanDiff,CR ,coef ] = BlandAltman(den_r, tag_r, 2,'Regional Radial Agreement', 1)
den_rmean=transpose(mean(transpose(den_r0(:,1:6))));
tag_rmean=transpose(mean(transpose(tag_r0(:,1:6))));
[meanDiff,CR ,coef ] = BlandAltman(den_rmean, tag_rmean, 2,'Whole Slice Radial Agreement', 2)

den_x10=[x1_circ_apex(:,1:6);x1_circ_mid;x1_circ_base];
den_x20=[x2_circ_apex(:,1:6);x2_circ_mid;x2_circ_base];
den_x1=[x1_circ_mid,x1_circ_apex(:,1),x1_circ_apex(:,4);x1_circ_base,x1_circ_apex(:,7),x1_circ_apex(:,8)];
den_x2=[x2_circ_mid,x2_circ_apex(:,1),x2_circ_apex(:,4);x2_circ_base,x2_circ_apex(:,7),x2_circ_apex(:,8)];
[meanDiff,CR ,coef ] = BlandAltman(den_x1, den_x2, 2,'Regional Circumferential Agreement', 1)
den_x1mean=transpose(mean(transpose(den_x10(:,1:6))));
den_x2mean=transpose(mean(transpose(den_x20(:,1:6))));
[meanDiff,CR ,coef ] = BlandAltman(den_x1mean, den_x2mean, 2,'Whole Slice Circumferential Agreement', 2)

den_x1r0=[x1_rad_apex(:,1:6);x1_rad_mid;x1_rad_base];
den_x2r0=[x2_rad_apex(:,1:6);x2_rad_mid;x2_rad_base];
den_x1r=[x1_rad_mid,x1_rad_apex(:,1),x1_rad_apex(:,4);x1_rad_base,x1_rad_apex(:,7),x1_rad_apex(:,8)];
den_x2r=[x2_rad_mid,x2_rad_apex(:,1),x2_rad_apex(:,4);x2_rad_base,x2_rad_apex(:,7),x2_rad_apex(:,8)];
den_x1r0=abs(den_x1r0);
den_x2r0=abs(den_x2r0);
den_x1r=abs(den_x1r);
den_x2r=abs(den_x2r);
[meanDiff,CR ,coef ] = BlandAltman(den_x1r, den_x2r, 2,'Regional Radial Agreement', 1)
den_x1rmean=transpose(mean(transpose(den_x1r0(:,1:6))));
den_x2rmean=transpose(mean(transpose(den_x2r0(:,1:6))));
[meanDiff,CR ,coef ] = BlandAltman(den_x1rmean, den_x2rmean, 2,'Whole Slice Radial Agreement', 2)
%Add the path;
%Load all coronary files
LOAD_FILES=0; % change to 0 if already loaded
if LOAD_FILES
    clear all;
    mydir = 'C:\Images\Coronaries\Sanchez\6\6\';%the dir of coronary dcm files
    files = dir(mydir);
    files = files(3:size(files,1),:);
    dcms=[];
    dcms_info =[];
    dcms = cell(size(files));
    dcms_info = cell(size(files));
    for i=1:size(files,1)
        myfile = strcat(mydir,files(i,1).name);
        dcms{i}= dicomread(myfile);
        dcms_info{i}=dicominfo(myfile);
    end
end

%specify a range of images over which to trace coronaries
range =80:85;
%specify the number of polygons to be constructed
NUM_ART=3;
% display each image file and draw polygons around the same anatomical
% landmark (first practice with a bigger feature before coronaries)
% create a structure "post_pos" and store all coordinates in poly
post_pos = cell(NUM_ART,size(range,2));
p=1;

% CROP the image for better visualization-jk 062415
figure(11)
imagesc(dcms{range(1,1)});colormap(gray)
[I rect]= imcrop;
close(11);
figure(11);
% create polygon on 1st image on stack to be copied to other images-jk 062415
I2 = imcrop(dcms{range(1,1)},rect);
imagesc(I2);colormap(gray)

for n=1:NUM_ART
    h=[];
    h = impoly;
    post_pos{n,p} = wait(h);
    %post_pos{n,p}(size(post_pos{n,p},1)+1,:)=post_pos{n,p}(1,:);% complete polygon
end
p=p+1;
close(11);
% use polygon from 1st image and modify it on rest as anatomy changes
for k=range(1,2):range(1,2)+size(range,2)-2
    figure(11)
    I2 = imcrop(dcms{k},rect);
    imagesc(I2);
    colormap(gray)
    for n=1:NUM_ART
        h=[];
        h = impoly(gca, post_pos{n,p-1}(1:size(post_pos{n,p-1}),:));
        post_pos{n,p} = wait(h);
        %post_pos{n,p}(size(post_pos{n,p},1)+1,:)=post_pos{n,p}(1,:);% complete polygon
    end
    close(11);
    p=p+1;
end

% transform all the landmark coordinates to 3D 
p=1;
% store all the 3D landmark from each image in a structure called cor_3d
cor_3d=cell(NUM_ART,size(range,2));
for k=range
    rc = getfield(dcms_info{k}, 'ImageOrientationPatient');
    C=-rc(4:6);
    R=rc(1:3);
    N = cross(R,C);
    P = .1*getfield(dcms_info{k}, 'ImagePositionPatient');
    FR = [R,C,N,P;0 0 0 1];
    FR = transpose(FR);
    for n=1:NUM_ART
        xyz = zeros(size(post_pos{n,p},1),4);
        for i=1:size(post_pos{n,p},1)
            xyz(i,:)= [post_pos{n,p}(i,:) 0 1]*FR;
        end
        cor_3d{n,p} = xyz;
    end
    p=p+1;   
end

%plot 3d polygons-jk 062415
figure;hold;
for n = 1:size(cor_3d,1)
    for i = 1:size(cor_3d,2)
        line(cor_3d{n,i}(:,1),cor_3d{n,i}(:,2),cor_3d{n,i}(:,3));
    end
end
    
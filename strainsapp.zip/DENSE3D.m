function varargout = DENSE3D(varargin)
% DENSE3D MATLAB code for DENSE3D.fig
%      DENSE3D, by itself, creates a new DENSE3D or raises the existing
%      singleton*.
%
%      H = DENSE3D returns the handle to a new DENSE3D or the handle to
%      the existing singleton*.
%
%      DENSE3D('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DENSE3D.M with the given input arguments.
%
%      DENSE3D('Property','Value',...) creates a new DENSE3D or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DENSE3D_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DENSE3D_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DENSE3D

% Last Modified by GUIDE v2.5 20-May-2018 00:30:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DENSE3D_OpeningFcn, ...
                   'gui_OutputFcn',  @DENSE3D_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before DENSE3D is made visible.
function DENSE3D_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DENSE3D (see VARARGIN)

% Choose default command line output for DENSE3D
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% This sets up the initial plot - only do when we are invisible
% so window can get raised using DENSE3D.
% % % if strcmp(get(hObject,'Visible'),'off')
% % %     plot(rand(5));
% % % end

axes(handles.axes2);
plot(rand(5),'Parent',handles.axes2);
setappdata(handles.strain,'boundaries2d',0);
setappdata(handles.strain,'unwrapped',0);
setappdata(handles.strain,'strainsdone',0);
setappdata(handles.strain,'dispdone',0);


% UIWAIT makes DENSE3D wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DENSE3D_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in loaddir.
function loaddir_Callback(hObject, eventdata, handles)
% hObject    handle to loaddir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
alldirs=uigetdir('C:\Images\','Pick Top Directory');
if (alldirs)
else
    return;
end
if isdir(alldirs)
else
    return;
end
set(handles.filedir,'string',strcat(alldirs,'\'));
alldirs=dir(alldirs);
k=0;
allist=cell(1);
for i=1:size(alldirs,1)
a=strfind(alldirs(i).name,'AVEMAG');
    if isempty(a)
    else
        k=k+1;
        allist{k}=alldirs(i).name;
    end
end
set(handles.listbox1,'string',allist(1:k));
set(handles.listbox1,'Max',k,'Min',1);
set(handles.listboxphase,'string','');
set(handles.listboxmag,'string','');

%%
% % save_all_list(handles);
% 
% function save_all_list(handles)
newstr=get(handles.listbox1,'string');

filedir=get(handles.filedir,'string');

%% Setup available phases
STARTSET=3;
frames=cell(size(dir(strcat(filedir,'\',newstr{1})),1)-2-STARTSET,1);
for f =1:size(frames,1)
frames{f,1}=strcat('1-',num2str(f+STARTSET));
end
set(handles.FrameRange,'string',frames);
set(handles.FrameRange,'value',7);
set(handles.slider1,'Min',1,'Max',10);
set(handles.slider1,'Value',1);
%%
addpath(genpath(filedir));
xdirs=dir(strcat(get(handles.filedir,'string'),'*X-ENCPHA*'));
ydirs=dir(strcat(get(handles.filedir,'string'),'*Y-ENCPHA*'));
zdirs=dir(strcat(get(handles.filedir,'string'),'*Z-ENCPHA*'));

pos=zeros(size(newstr));

for i=1:size(newstr,1)
        files=dir(strcat(filedir,newstr{i}));
        files=files(3);
        info = dicominfo(strcat(strcat(filedir,newstr{i}),'\',files.name));
        pos(i)=info.SliceLocation;
end

[p, id]=sort(pos);
pos=pos(id);
newstr=newstr(id);
set(handles.listbox1,'string',newstr);

k=1;
xdirsc=cell(size(newstr));
for i=1:size(newstr,1)
    for j=1:size(xdirs,1)
%         files=dir(strcat(filedir,newstr{i}));
%         files=files(3);
        files_x=dir(strcat(filedir,xdirs(j).name));
        files_x=files_x(3);
%         info = dicominfo(strcat(strcat(filedir,newstr{i}),'\',files.name));
        info_x = dicominfo(strcat(strcat(filedir,xdirs(j).name),'\',files_x.name));
        if pos(i) == info_x.SliceLocation
            xdirsc{k}=xdirs(j).name;
            disp('loading...');
            disp(xdirs(j).name);
            stat= sprintf('loading... %s',xdirs(j).name);
            set(handles.edit2,'string',stat);drawnow;
            k=k+1;
        end
end
end

%newstr=p_str;
ydirsc=cell(size(newstr));
k=1;
for i=1:size(newstr,1)
    for j=1:size(ydirs,1)
%         files=dir(strcat(filedir,newstr{i}));
%         files=files(3);
        files_x=dir(strcat(filedir,ydirs(j).name));
        files_x=files_x(3);
%         info = dicominfo(strcat(strcat(filedir,newstr{i}),'\',files.name));
        info_x = dicominfo(strcat(strcat(filedir,ydirs(j).name),'\',files_x.name));
        if pos(i) == info_x.SliceLocation
            ydirsc{k}=ydirs(j).name;
            disp('loading...');
            disp(ydirs(j).name);
            stat= sprintf('loading... %s',ydirs(j).name);
            set(handles.edit2,'string',stat);drawnow;
            k=k+1;
        end
end
end

%newstr=p_str;
zdirsc=cell(size(newstr));
k=1;
for i=1:size(newstr,1)
    for j=1:size(zdirs,1)
%         files=dir(strcat(filedir,newstr{i}));
%         files=files(3);
        files_x=dir(strcat(filedir,zdirs(j).name));
        files_x=files_x(3);
%         info = dicominfo(strcat(strcat(filedir,newstr{i}),'\',files.name));
        info_x = dicominfo(strcat(strcat(filedir,zdirs(j).name),'\',files_x.name));
        if pos(i) == info_x.SliceLocation
            zdirsc{k}=zdirs(j).name;
            disp('loading...');
            disp(zdirs(j).name);
            stat= sprintf('loading... %s',zdirs(j).name);
            set(handles.edit2,'string',stat);drawnow;
            k=k+1;
        end
end
end
stat= sprintf('Loading completed.');
set(handles.edit2,'string',stat);drawnow;
allist=cell(size(newstr,1),4);
k=1;
%p_val=transpose(p_val);
epi_d = struct('xi',[],'yi',[],'zi',[]);
endo_d = struct('xi',[],'yi',[],'zi',[]);
epi_s = struct('xi',[],'yi',[],'zi',[]);
endo_s = struct('xi',[],'yi',[],'zi',[]);
phases=cell(1,3);
mag=cell(1,1);
ph_names=cell(1,3);

masterset=struct('epi_d',[],'endo_d',[],'epi_s',[],'endo_s',[],'phases',[],'mag',[],...
    'unwrapped',[],'ph_names',[],'mag_names',[], 'gen_epi',[],'gen_endo',[],'gen_disp',[],...
    'epi_2d',[],'endo_2d',[],'epi_3d',[],'endo_3d',[],'def',[]);

rot_range=zeros(size(newstr,1),1);
for i=1:size(newstr,1)
    allist{i,1}=newstr{i,1};
    allist{i,2}=xdirsc{i,1};
    allist{i,3}=ydirsc{i,1};
    allist{i,4}=zdirsc{i,1};
    masterset(i).mag_names=allist{i,1};
    masterset(i).ph_names={allist{i,2:4}};
    rot_range(i)=8-0.8*i;
%     masterset(i).rot_range=rot_range(i);
end
setappdata(handles.loaddir,'rot_range',rot_range');
fr=get(handles.FrameRange,'string');
curval=get(handles.FrameRange,'value');
fr=fr(curval);
[t,rem]=strtok(reverse(fr),'-');
t=reverse(t);
fr=str2num(t{1})+2;
START_FRAME=2;
END_FRAME=fr;
setappdata(handles.loaddir,'masterset',masterset);
setappdata(handles.loaddir,'START_FRAME',START_FRAME);
setappdata(handles.loaddir,'END_FRAME',END_FRAME);
setappdata(handles.boundaries,'rect',[]);

save('allist.mat', 'allist');
[pathstr,name,ext] = fileparts(filedir(1:length(filedir)-1));
[pathstr,name,ext] = fileparts(pathstr);
set(handles.savefile,'string',name);
setappdata(handles.strain,'boundaries2d',0);
setappdata(handles.strain,'unwrapped',0);
setappdata(handles.strain,'strainsdone',0);
setappdata(handles.strain,'dispdone',0);
% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figure1)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
                     ['Close ' get(handles.figure1,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.figure1)




% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listboxphase.
function listboxphase_Callback(hObject, eventdata, handles)
% hObject    handle to listboxphase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listboxphase contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listboxphase


% --- Executes during object creation, after setting all properties.
function listboxphase_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listboxphase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listboxmag.
function listboxmag_Callback(hObject, eventdata, handles)
% hObject    handle to listboxmag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listboxmag contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listboxmag


% --- Executes during object creation, after setting all properties.
function listboxmag_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listboxmag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phases.
function phases_Callback(hObject, eventdata, handles)
% hObject    handle to phases (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p_val=get(handles.listbox1,'value');
p_str=get(handles.listbox1,'string');
p_str=p_str(p_val);
p_str2=get(handles.listboxmag,'string');

    p_str=[p_str;p_str2];
p_str=unique(p_str);

set(handles.listboxmag,'string',p_str);
filedir=get(handles.filedir,'string');
addpath(genpath(filedir));

load allist;
newstr=p_str;
xdirsc=cell(size(newstr));
ydirsc=cell(size(newstr));
zdirsc=cell(size(newstr));

id=[];
for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = [id;find(not(cellfun('isempty', IndexC)))];
    
end
[id,id2]=sort(id,1);
set(handles.listboxmag,'string',newstr(id2));

xdirsc=allist(id,2);
ydirsc=allist(id,3);
zdirsc=allist(id,4);

mystring=cell(size(p_str,1),3);
%p_val=transpose(p_val);
for i=1:size(p_str)
    mystring{i,1}=xdirsc{i,1};
    mystring{i,2}=ydirsc{i,1};
    mystring{i,3}=zdirsc{i,1};
end
% guidata(handles.select,mystring);
mystring2=reshape(mystring,size(mystring,1)*size(mystring,2),1);
set(handles.listboxphase,'string',mystring2);
setappdata(handles.listboxphase,'mystring',mystring);
save('mystring.mat','mystring');


% --- Executes on button press in displacement.
function displacement_Callback(hObject, eventdata, handles)
% hObject    handle to displacement (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if getappdata(handles.strain,'unwrapped')==0
%     return;
end
p_str=get(handles.listboxmag,'string');
addpath(genpath(get(handles.filedir,'string')));
axis_pt_z=size(p_str,1);
files=dir(strcat(get(handles.filedir,'string'),p_str{1},'\'));


filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');
imPhase=cell(size(p_str,1),3);
imMag=cell(size(p_str,1),1);
unwrapped=cell(size(p_str,1),3);
k=1;

rect=getappdata(handles.boundaries,'rect');
flipped=getappdata(handles.boundaries,'flipped');

masterset=getappdata(handles.loaddir,'masterset');
ProcDisps3;
stat= sprintf('3D Displacements done');
set(handles.edit2,'string',stat);drawnow;
setappdata(handles.loaddir,'epi_2d',epi_d);
setappdata(handles.loaddir,'endo_2d',endo_d);
setappdata(handles.loaddir,'epi_3d',epi_3d);
setappdata(handles.loaddir,'endo_3d',endo_3d);
setappdata(handles.loaddir,'def',def);
setappdata(handles.strain,'strainsdone',0);
setappdata(handles.strain,'dispdone',1);
return;

% --- Executes on button press in strain.
function strain_Callback(hObject, eventdata, handles)
% hObject    handle to strain (see GCBO)
% eventdata  reserved - to be defined in a future version of MAT,LAB
% handles    structure with handles and user data (see GUIDATA)
if getappdata(handles.strain,'dispdone')==0
    return;
end
p_str=get(handles.listboxmag,'string');
addpath(genpath(get(handles.filedir,'string')));
axis_pt_z=size(p_str,1);
files=dir(strcat(get(handles.filedir,'string'),p_str{1},'\'));


filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');
imPhase=cell(size(p_str,1),3);
imMag=cell(size(p_str,1),1);
unwrapped=cell(size(p_str,1),3);
k=1;

rect=getappdata(handles.boundaries,'rect');
flipped=getappdata(handles.boundaries,'flipped');

masterset=getappdata(handles.loaddir,'masterset');


nonempty={masterset(1:size(masterset,2)).epi_d};
epi_d=([masterset(find(~cellfun(@isempty,nonempty))).epi_d]);
endo_d=([masterset(find(~cellfun(@isempty,nonempty))).endo_d]);
srch=get(handles.listboxmag,'string');
procset=[];
for m=1:size(masterset,2)
    for s=1:size(srch,1)
        if (strfind(string(masterset(1,m).mag_names),string(srch(s))))
%             if ~isempty(masterset(1,m).gen_epi) && ~isempty(masterset(1,m).gen_endo)...
%                     && ~isempty(masterset(1,m).gen_disp) && ~isempty(masterset(1,m).unwrapped)
                procset=[procset;m];
%             end
        end
     end
end
epi_d=[masterset(procset).epi_d];
endo_d=[masterset(procset).endo_d];
pm=[];
for i=1:size(p_str,1)
    if isempty(masterset(procset(i)).epi_d)
        pm2=[0 0 0 0];
    else
        pm2=polygeom(masterset(procset(i)).epi_d.xi,masterset(procset(i)).epi_d.yi);
    end
    pm=[pm;pm2(4)];
    
end
[pmax pmid]=max(pm);
files=dir(strcat(get(handles.filedir,'string'),p_str{pmid},'\'));
if flipped ==1
    dcm=flipud(dicomread(files(6).name));
else
    dcm=dicomread(files(6).name);
end
% figure;
im_m=imcrop(dcm,rect);
I1=imfilter(im_m,[7 7]);
[N, edges]=histcounts(I1,10);
I1=imsharpen(I1,'Radius',5,'Amount',1);
I1(I1<=edges(2))=edges(2);
f=figure;
imagesc(I1,[0.5*min(I1(:)) 0.5*max(I1(:))]), colormap gray;
% truesize(I1);
hold on;
plot(masterset(procset(pmid)).epi_d.xi,masterset(procset(pmid)).epi_d.yi,'r-','LineWidth',1.75);
plot(masterset(procset(pmid)).endo_d.xi,masterset(procset(pmid)).endo_d.yi,'g-','LineWidth',1.75);
% % axis_pts=zeros(2,2);
% % axis_pts(1,1)=18.46;
% % axis_pts(1,2)=10.96;
% % axis_pts(2,1)=17.95;
% % axis_pts(2,2)=28.77;
title('Select Upper Axis Point');
[axis_pts(1,1),axis_pts(1,2)] = ginput(1);
title('Select Lower Axis Point');
[axis_pts(2,1),axis_pts(2,2)] = ginput(1);
hold off;
close(f);
setappdata(handles.loaddir,'axis_pts',axis_pts);


masterset=getappdata(handles.loaddir,'masterset');
nonempty={masterset(1:size(masterset,2)).epi_d};
nonempty=find(~cellfun(@isempty,nonempty));

[x,y]=meshgrid(1:size(im_m,2),1:size(im_m,1));


savefile = strsplit(get(handles.filedir,'string'),'\');
idC=strfind(savefile,'_0');
ind = find(not(cellfun('isempty', idC)));
if isempty(ind)
    savefile=get(handles.savefile,'string');
else
    savefile=strcat(savefile{ind},'.mat');
end
ProcStrains3;
setappdata(handles.strain,'strainsdone',1);
stat= sprintf('3D Strains done');
set(handles.edit2,'string',stat);drawnow;
nonempty={masterset(1:size(masterset,2)).epi_d};
epi_d=([masterset(find(~cellfun(@isempty,nonempty))).epi_d]);
endo_d=([masterset(find(~cellfun(@isempty,nonempty))).endo_d]);
% epi_s=([masterset(find(~cellfun(@isempty,nonempty))).epi_s]);
% endo_s=([masterset(find(~cellfun(@isempty,nonempty))).endo_s]);
imMag=({masterset(find(~cellfun(@isempty,nonempty))).mag});
imMag=imMag';
imPhase=({masterset(find(~cellfun(@isempty,nonempty))).phases});
imPhase=imPhase';
temp=cell(size(imPhase,1),3);
for t=1:size(imPhase,1)
    temp{t,1}=imPhase{t}{1};
    temp{t,2}=imPhase{t}{2};
    temp{t,3}=imPhase{t}{3};
end
imPhase=temp;
% % % imUnwrapped=({masterset(find(~cellfun(@isempty,nonempty))).unwrapped});
% % % imUnwrapped=imUnwrapped';
% % % temp=cell(size(imUnwrapped,1),3);
% % % for t=1:size(imUnwrapped,1)
% % %     temp{t,1}=imUnwrapped{t}{1};
% % %     temp{t,2}=imUnwrapped{t}{2};
% % %     temp{t,3}=imUnwrapped{t}{3};
% % % end
% % % imUnwrapped=temp;
% % % mystring=({masterset(find(~cellfun(@isempty,nonempty))).ph_names});
% % % mystring=mystring';
% % % temp=cell(size(mystring,1),3);
% % % for t=1:size(mystring,1)
% % %     temp{t,1}=mystring{t}{1};
% % %     temp{t,2}=mystring{t}{2};
% % %     temp{t,3}=mystring{t}{3};
% % % end
% % % mystring=temp;
% % % save(savefile, 'masterset','x','y','endo_d','epi_d','imMag','imPhase','filedir', 'mystring','rect','axis_pts');

%proofDENSE3D;
disp('Strains done');


function savefile_Callback(hObject, eventdata, handles)
% hObject    handle to savefile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of savefile as text
%        str2double(get(hObject,'String')) returns contents of savefile as a double


% --- Executes during object creation, after setting all properties.
function savefile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to savefile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in remove.
function remove_Callback(hObject, eventdata, handles)
% hObject    handle to remove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p_val=get(handles.listboxmag,'value');
p_str=get(handles.listboxmag,'string');
%p_val=setdiff(1:size(p_str,1),p_val);
m_str=p_str(p_val);

p_str(p_val)=[];

Val=p_val-1;
if Val < 1 
    Val =1;
end
set(handles.listboxmag,'string',p_str,'value',Val);
filedir=get(handles.filedir,'string');
addpath(genpath(filedir));

load allist;
newstr=p_str;
xdirsc=cell(size(newstr));
ydirsc=cell(size(newstr));
zdirsc=cell(size(newstr));

for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = find(not(cellfun('isempty', IndexC)));
    xdirsc{i}=allist{id,2};
    ydirsc{i}=allist{id,3};
    zdirsc{i}=allist{id,4};
end
id=[];
for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = [id;find(not(cellfun('isempty', IndexC)))];
    
end
[id,id2]=sort(id,1);
set(handles.listboxmag,'string',newstr(id2));

mystring=cell(size(p_str,1),3);
for i=1:size(p_str)
    mystring{i,1}=xdirsc{i,1};
    mystring{i,2}=ydirsc{i,1};
    mystring{i,3}=zdirsc{i,1};
end
% guidata(handles.select,mystring);
mystring2=reshape(mystring,size(mystring,1)*size(mystring,2),1);
set(handles.listboxphase,'string',mystring2);
setappdata(handles.listboxphase,'mystring',mystring);
save('mystring.mat','mystring');

masterset=getappdata(handles.loaddir,'masterset');
if isempty(masterset)
    return;
end
nonempty_all=ismember({masterset.mag_names}',m_str);
masterset(nonempty_all==1).epi_d=[];
masterset(nonempty_all==1).endo_d=[];
masterset(nonempty_all==1).gen_epi=[];
masterset(nonempty_all==1).gen_endo=[];
masterset(nonempty_all==1).gen_disp=[];
masterset(nonempty_all==1).unwrapped=[];
masterset(nonempty_all==1).mag=[];
masterset(nonempty_all==1).phases=[];
setappdata(handles.loaddir,'masterset',masterset);

% --- Executes on button press in show.
function show_Callback(hObject, eventdata, handles)
% hObject    handle to show (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
slider1_moveFnc(handles);

% --- Executes when entered data in editable cell(s) in uitable2.
function uitable2_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to uitable2 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function uitable2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uitable2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in boundaries.
function boundaries_Callback(hObject, eventdata, handles)
% hObject    handle to boundaries (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p_str=get(handles.listboxmag,'string');
addpath(genpath(get(handles.filedir,'string')));
axis_pt_z=size(p_str,1);
files=dir(strcat(get(handles.filedir,'string'),p_str{1},'\'));
dcm=dicomread(files(5).name);

setappdata(handles.boundaries,'rect',[]);
if isempty(getappdata(handles.boundaries,'rect'))
    flipped=0;
    dcm=imcrop(dcm,[10 10 95 95]);
    dcm=imfilter(dcm,[7 7]);
    [N, edges]=histcounts(dcm,10);
    dcm=imsharpen(dcm,'Radius',5,'Amount',1);
   dcm(dcm<=edges(2))=edges(2);
    figure;
    imagesc(dcm), colormap gray;
            QuestName=questdlg('Is Anterior-Posterior reversed?', ...
                             'Positioning','Yes', 'No','No');
            switch QuestName,
                 case 'Yes',
                    flipped=1;
                 case 'No',
                    flipped=0;
            end
    if flipped == 1
        close;
        dcm=flipud(dicomread(files(5).name));
        figure;
        imagesc(dcm), colormap gray;
        setappdata(handles.boundaries,'flipped',1);
    else
          setappdata(handles.boundaries,'flipped',0);
    end

    [im_m,rect]=imcrop;
    close;
    rect(1)=rect(1)+10;
    rect(2)=rect(2)+10;
    setappdata(handles.boundaries,'rect',rect);
else
    rect=getappdata(handles.boundaries,'rect');
    flipped=getappdata(handles.boundaries,'flipped');
end
filename=strcat(get(handles.savefile,'string'),'_rect.mat');
save(filename,'rect');

% rect=load ('ROBERTSON_EMILY_48932-short_rect.mat');
filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');
masterset=getappdata(handles.loaddir,'masterset');
p_str2=cell(1,1);
numvec=[];
k=1;
for p=1:size(p_str,1)
    num=find(ismember({masterset(1:size(masterset,2)).mag_names},p_str{p})==1);
%     if isempty(masterset(num).epi_d)
        p_str2{k,1}=p_str{p};
        numvec=[numvec;num];
        k=k+1;
%     end
end
p_str2=get(handles.listboxmag,'string');
if isempty(p_str2{1,1})
else
    brightness=1.0-0.5*get(handles.slider2,'value');
    [endo_d, epi_d] = GenVolumeWUnwrap3(filedir,p_str2,rect,brightness,flipped);
    save('Init_BNDRYS','endo_d', 'epi_d');
    k=1;
    numvec=numvec';
    for n=numvec
        masterset(n).epi_d=epi_d(k);
        masterset(n).endo_d=endo_d(k);
        masterset(n).gen_epi{6}=[epi_d(k).xi,epi_d(k).yi]';
         masterset(n).gen_endo{6}=[endo_d(k).xi,endo_d(k).yi]';
%         masterset(n).epi_s=epi_s(k);
%         masterset(n).endo_s=endo_s(k);
        k=k+1;
    end
    setappdata(handles.loaddir,'masterset',masterset);
end

mastersz=size(masterset,2);
masterset_unwrapped=cell(mastersz,1);
masterset_cropped=cell(mastersz,1);
setappdata(handles.boundaries,'masterset_unwrapped',masterset_unwrapped);
setappdata(handles.boundaries,'masterset_cropped',masterset_cropped);

setappdata(handles.strain,'boundaries2d',1);
setappdata(handles.strain,'unwrapped',0);
setappdata(handles.strain,'strainsdone',0);
setappdata(handles.strain,'dispdone',0);
set(handles.changeinitwalls,'value',1);
changeinitwalls_Callback(hObject, eventdata, handles);

function QualityGuidedUnwrap(handles,numvec)
if getappdata(handles.strain,'boundaries2d')==0
end
addpath(genpath('geom2d'));
filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');

p_str=get(handles.listboxmag,'string');
p_val=get(handles.listboxmag,'value');
p_str=get(handles.listboxmag,'string');

rect=getappdata(handles.boundaries,'rect');
masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);

fr=get(handles.FrameRange,'string');
curval=get(handles.FrameRange,'value');
fr=fr(curval);
[t,rem]=strtok(reverse(fr),'-');
t=reverse(t);
fr=str2num(t{1})+2;
START_FRAME=2+1;
END_FRAME=fr;
UNWRAP=1;
inum=1;
masterset_unwrapped=getappdata(handles.boundaries,'masterset_unwrapped');
masterset_cropped=getappdata(handles.boundaries,'masterset_cropped');
for nonempty=numvec
    epi_d=([masterset(nonempty).epi_d]);
    endo_d=([masterset(nonempty).endo_d]);
    epi_ellipse= transpose([epi_d((1)).xi,epi_d((1)).yi]);
    endo_ellipse= transpose([endo_d((1)).xi,endo_d((1)).yi]);
    cent=[mean(epi_ellipse(1,:)),mean(epi_ellipse(2,:))];
    for ii=1:size(epi_ellipse,2)
         endo_ellipse(1,ii)=cent(1,1)+ (endo_ellipse(1,ii)-1*cent(1,1));
          endo_ellipse(2,ii)=cent(1,2)+ (endo_ellipse(2,ii)-1*cent(1,2));
    %     
        epi_ellipse(1,ii)=cent(1,1)+ (epi_ellipse(1,ii)-1*cent(1,1));
         epi_ellipse(2,ii)=cent(1,2)+ (epi_ellipse(2,ii)-1*cent(1,2));
    end

    files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
    phasex_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{1}));
    phasey_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{2}));
    phasez_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{3}));

    par=[];
    par=masterset(nonempty).mag_names;
    p=findstr(par,'PAR');
    par=par(p:p+4);
    p=findstr(par,'_');
    if p>0
        par=par(1:p-1);
    end
    stat= sprintf('Unwrapping for partition %s ...',par);
        set(handles.edit2,'string',stat);drawnow;
    master_unwrapped=cell (END_FRAME,3);
    master_cropped=cell(END_FRAME,4);

    if UNWRAP
        for bi=START_FRAME:END_FRAME
            dcm=dicomread(files(bi).name);
            im_m=imcrop(dcm,rect);
            master_cropped{bi,4}=im_m;

            dcm=dicomread(phasex_f(bi).name);
            im_p=imcrop(dcm,rect);
            im_p1=im_p;
            QualityGuidedUnwrap2DDENSE3D;
            master_unwrapped{bi,1}=im_unwrapped;
            master_cropped{bi,1}=im_p1;
        end
        for bi=START_FRAME:END_FRAME
            dcm=dicomread(phasey_f(bi).name);
            im_p=imcrop(dcm,rect);
            im_p2=im_p;
            QualityGuidedUnwrap2DDENSE3D;
            master_unwrapped{bi,2}=im_unwrapped;
            master_cropped{bi,2}=im_p2;
        end
        for bi=START_FRAME:END_FRAME
            dcm=dicomread(phasez_f(bi).name);
            im_p=imcrop(dcm,rect);
            im_p3=im_p;
            QualityGuidedUnwrap2DDENSE3D;
            master_unwrapped{bi,3}=im_unwrapped;
            master_cropped{bi,3}=im_p3;
        end
        par=masterset(nonempty).mag_names;
        p=findstr(par,'PAR');
        par=par(p:p+4);
        p=findstr(par,'_');
        if p>0
            par=par(1:p-1);
        end
        stat= sprintf('Unwrapping for partition %s ...',par);
        stat= sprintf('Unwrapping completed for partition %s ...',par);
        set(handles.edit2,'string',stat);drawnow;
        masterset_unwrapped{nonempty,1}=master_unwrapped;
        masterset(nonempty).unwrapped=master_unwrapped;
        masterset_cropped{nonempty,1}=master_cropped;
        end
end
  
setappdata(handles.boundaries,'masterset_unwrapped',masterset_unwrapped);
setappdata(handles.boundaries,'masterset_cropped',masterset_cropped);
setappdata(handles.loaddir,'masterset',masterset);
slider1_moveFnc(handles);
% --- Executes on button press in searchboundaries.
function searchboundaries_Callback(hObject, eventdata, handles)
% hObject    handle to searchboundaries (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%filedir=getappdata(handles.strain,'filedir');
if getappdata(handles.strain,'boundaries2d')==0
end
addpath(genpath('geom2d'));
filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');

p_str=get(handles.listboxmag,'string');

rect=getappdata(handles.boundaries,'rect');
masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=getappdata(handles.listboxmag,'nonempty_all');
nonempty_all0=ismember({masterset.mag_names}',p_str);
if ~isempty(nonempty_all )
    if ~isempty(find(nonempty_all> 0))
    else
        nonempty_all=ismember({masterset.mag_names}',p_str);
    end
else
    nonempty_all=ismember({masterset.mag_names}',p_str);
end

setappdata(handles.listboxmag,'nonempty_all',[]);
PLOT_RAW=1;
mid_ons=[find(nonempty_all> 0)]';
sz=size(mid_ons,2);
% mid_ons=mid_ons(round(sz/3):sz);
prev_tans=zeros(20,30);
fr=get(handles.FrameRange,'string');
curval=get(handles.FrameRange,'value');
fr=fr(curval);
[t,rem]=strtok(reverse(fr),'-');
t=reverse(t);
fr=str2num(t{1})+2;
START_FRAME=2+1;
END_FRAME=fr;
UNWRAP=1;
% setappdata(handles.boundaries,'masterset_unwrapped',cell(1,1));
masterset_unwrapped=getappdata(handles.boundaries,'masterset_unwrapped');
if isempty(getappdata(handles.boundaries,'masterset_unwrapped'))
else
    masterset_unwrapped=getappdata(handles.boundaries,'masterset_unwrapped');
    masterset_cropped=getappdata(handles.boundaries,'masterset_cropped');
end
id0=find(~cellfun(@isempty,masterset_unwrapped));
if size(id0,1) > 0
    id1=find(~cellfun(@isempty,masterset_unwrapped{id0(1),1}));
    tot_frms=size(id1,1)/3;
    end_fr=tot_frms+2;
    proc_prts1=find(nonempty_all> 0);
    sz=size(proc_prts1,1);
    proc_prts2=id0;
    if sum(ismember(proc_prts1,proc_prts2))==sz && isequal(end_fr,END_FRAME)
    else
%        QualityGuidedUnwrap(handles,[find(nonempty_all> 0)]');
    end
else
%     QualityGuidedUnwrap(handles,[find(nonempty_all> 0)]');
end
% QualityGuidedUnwrap(handles,[find(nonempty_all> 0)]');
masterset_unwrapped=getappdata(handles.boundaries,'masterset_unwrapped');
masterset_cropped=getappdata(handles.boundaries,'masterset_cropped');
%Reget masterset to get unwrapped data
masterset=getappdata(handles.loaddir,'masterset');
n1=find(nonempty_all0>0);
n2=find(nonempty_all>0);
[~,id]=ismember(n2(1),n1);
ang_inc=0;
for nonempty=[find(nonempty_all> 0)]'
%     for nonempty=[11]
% % %   APICAL_SMOOTHING=APICAL_SMOOTHING+1;
% if isfield(masterset,'rot_range')
%     ang_inc=masterset(nonempty).rot_range;
% else
    rot_range=getappdata(handles.loaddir,'rot_range');
    ang_inc=rot_range(nonempty);
% end
epi_d=([masterset(nonempty).epi_d]);
endo_d=([masterset(nonempty).endo_d]);
epi_ellipse= transpose([epi_d((1)).xi,epi_d((1)).yi]);
endo_ellipse= transpose([endo_d((1)).xi,endo_d((1)).yi]);
cent=[mean(epi_ellipse(1,:)),mean(epi_ellipse(2,:))];
for ii=1:size(epi_ellipse,2)
     endo_ellipse(1,ii)=cent(1,1)+ (endo_ellipse(1,ii)-1*cent(1,1));
      endo_ellipse(2,ii)=cent(1,2)+ (endo_ellipse(2,ii)-1*cent(1,2));
%     
    epi_ellipse(1,ii)=cent(1,1)+ (epi_ellipse(1,ii)-1*cent(1,1));
     epi_ellipse(2,ii)=cent(1,2)+ (epi_ellipse(2,ii)-1*cent(1,2));
end

files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
phasex_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{1}));
phasey_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{2}));
phasez_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{3}));

par=[];
par=masterset(nonempty).mag_names;
p=findstr(par,'PAR');
par=par(p:p+4);
p=findstr(par,'_');
if p>0
    par=par(1:p-1);
end
stat= sprintf('Processing displacement for partition %s ...',par);
    set(handles.edit2,'string',stat);drawnow;
unwrapped=cell(20,2);

info=dicominfo(files(3).name);
% % my_pix=info.PixelSpacing(1);
% % aff{i,1}=[info.PixelSpacing(1)*info.ImageOrientationPatient(rows),...
% %     info.PixelSpacing(1)*info.ImageOrientationPatient(cols),...
% %     -cross(info.ImageOrientationPatient(1:3),info.PixelSpacing(1)*info.ImageOrientationPatient(4:6)),...
% %     info.ImagePositionPatient(1:3)];
if findstr(info.Private_0051_100e,'Tra') ==1
    ORIENT_TCS = 1;
elseif findstr(info.Private_0051_100e,'Cor') ==1
    ORIENT_TCS = 2;
else
    ORIENT_TCS = 3;
end
if UNWRAP
    master_unwrapped=masterset(nonempty).unwrapped;
    master_cropped=masterset_cropped{nonempty,1};
    for bi=START_FRAME:END_FRAME
        dcm=dicomread(files(bi).name);
        im_m=master_cropped{bi,4};%imcrop(dcm,rect);
        
%         dcm=dicomread(phasex_f(bi).name);
%         im_p=imcrop(dcm,rect);
%         im_p1=im_p;
%         QualityGuidedUnwrap2DDENSE3D;
%         unwrapped{bi,1}=im_unwrapped;
        im_p1=master_cropped{bi,1};
        unwrapped{bi,1}=master_unwrapped{bi,1};
        
%         dcm=dicomread(phasey_f(bi).name);
%         im_p=imcrop(dcm,rect);
%         im_p2=im_p;
%         QualityGuidedUnwrap2DDENSE3D;
%         unwrapped{bi,2}=im_unwrapped;
        im_p2=master_cropped{bi,2};%imcrop(dcm,rect);
        unwrapped{bi,2}=master_unwrapped{bi,2};
        [im_x,im_y]=meshgrid(1:size(unwrapped{bi,2},2),1:size(unwrapped{bi,2},1));
        [in on]=inpolygon(im_x,im_y,epi_d(1).xi,epi_d(1).yi);
        [in2 on2]=inpolygon(im_x,im_y,endo_d(1).xi,endo_d(1).yi);
        in=in-in2;
        
%         dcm=dicomread(phasez_f(bi).name);
%         im_p=imcrop(dcm,rect);
%         im_p3=im_p;
%         QualityGuidedUnwrap2DDENSE3D;
%         unwrapped{bi,3}=im_unwrapped;
        im_p3=master_cropped{bi,3};
        unwrapped{bi,3}=master_unwrapped{bi,3};
        
        im_x=im_x-mean(epi_d(1).xi);
        im_y=im_y-mean(epi_d(1).yi);
        im_ux=unwrapped{bi,1};
        im_uy=unwrapped{bi,2};
        im_ux2=unwrapped{bi,1}+im_x;
        im_uy2=unwrapped{bi,2}+im_y;
        
        im_x=im_x(in==1);
        im_y=im_y(in==1);
        im_ux=im_ux(in==1);
        im_uy=im_uy(in==1);
        im_ux2=im_ux2(in==1);
        im_uy2=im_uy2(in==1);
            
 
        [im_x,im_y]=meshgrid(1:size(unwrapped{bi,2},2),1:size(unwrapped{bi,2},1));
        PLOT_RAW=0;
        if PLOT_RAW
        figure; imagesc(im_phase_quality,[minp maxp]), colormap(gray), axis square, axis off; title('Phase quality map. Select black = high quality phase');
        hold;
        plot(endo_d(1).xi,endo_d(1).yi,'g');
        plot(epi_d(1).xi,epi_d(1).yi,'r')
        quiver(im_x,im_y,im_ux,im_uy,'Autoscale','off');
        end
    end
    if PLOT_RAW
        PLOT_RAW=0;
        return;
    end
    
        unwrap_fit_x=[];
    unwrap_fit_y=[];
    for bi=START_FRAME:END_FRAME
        im_ux=unwrapped{bi,1};%+unwrapped{START_FRAME,1};
        im_uy=unwrapped{bi,2};%+unwrapped{START_FRAME,2};
        ;
        unwrap_fit_x=[unwrap_fit_x,im_ux(in ==1)-mean(im_ux(in ==1))];
        unwrap_fit_y=[unwrap_fit_y,im_uy(in ==1)-mean(im_uy(in ==1))];
    end
    unwrap_fit_x(find(unwrap_fit_x>pi))=pi;
    unwrap_fit_x(find(unwrap_fit_x<-pi))=-pi;
    unwrap_fit_y(find(unwrap_fit_y>pi))=pi;
    unwrap_fit_y(find(unwrap_fit_y<-pi))=-pi;
    
    unwrap_fit_x2=unwrap_fit_x;
    unwrap_fit_y2=unwrap_fit_y;
    fsz2=size(unwrap_fit_x,2);

    x_in=im_x(in==1);
    y_in=im_y(in==1);
    for fi=1:size(unwrap_fit_x,1)
        stat= sprintf('***Fast fourier(FFT) fitting %s point %3.1f, %3.1f...',par, x_in(fi),y_in(fi));
        set(handles.edit2,'string',stat);drawnow;
        % %         f=fit(15*([1:fsz2]'),unwrap_fit_x(fi,:)','fourier2');
        f=fit([1:fsz2]',unwrap_fit_x(fi,:)','poly2');
        res=feval(f,[1:fsz2]');
        unwrap_fit_x(fi,:)=res';
        % %         f=fit(15*([1:fsz2]'),unwrap_fit_y(fi,:)','fourier2');
        f=fit([1:fsz2]',unwrap_fit_y(fi,:)','poly2');
        res=feval(f,[1:fsz2]');
        unwrap_fit_y(fi,:)=res';
    end
    
%     figure;hold;
%     for fi=1:size(unwrap_fit_x,1)
%         plot(1:fsz2, unwrap_fit_x(fi,:));
%     end
%     figure;hold;
%     for fi=1:size(unwrap_fit_x2,1)
%         plot(1:fsz2, unwrap_fit_x2(fi,:));
%     end
    ki=1;
    for bi=START_FRAME:END_FRAME
        im_ux=unwrapped{bi,1};
        im_uy=unwrapped{bi,2};
        im_ux(in==1)=unwrap_fit_x(:,ki);
        im_uy(in==1)=unwrap_fit_y(:,ki);
        unwrapped{bi,1}=im_ux;-1*mean(im_ux(in==1));
        unwrapped{bi,2}=im_uy;-1*mean(im_uy(in==1));
        ki=ki+1;
    end 
    
    gen_disp=cell(20,1);
    
    for bi=START_FRAME:END_FRAME
        cent = [mean(epi_ellipse(1,:)), mean(epi_ellipse(2,:))]; 
        im_x_in=im_x(in==1);
        im_y_in=im_y(in==1);
        flipped=getappdata(handles.boundaries,'flipped');
        if ORIENT_TCS == 3
            im_ux=unwrapped{bi,2};
            im_uy=-unwrapped{bi,1};    
        elseif ORIENT_TCS == 2
            if flipped
                im_ux=unwrapped{bi,2};
                im_uy=-unwrapped{bi,1};
            else
                im_ux=unwrapped{bi,2};
                im_uy=unwrapped{bi,1};
            end
        else %ORIENT_TCS == 1
             im_ux=-unwrapped{bi,1};
            im_uy=unwrapped{bi,2};
        end
        im_ux_in=im_ux(in==1);
        im_uy_in=im_uy(in==1);
        undef=zeros(size(im_ux_in,1), 2*size(im_ux_in,2));
        undef(:,1)=im_x_in-cent(1,1);
        undef(:,2)=im_y_in-cent(1,2);
        sqrt_undef=undef./(undef(:,1).^2+undef(:,2).^2).^.5;
        def=zeros(size(im_ux_in,1), 2*size(im_ux_in,2));
        def(:,1)=im_x_in+im_ux_in-cent(1,1);
        def(:,2)=im_y_in+im_uy_in-cent(1,2);
        sqrt_def=def./(def(:,1).^2+def(:,2).^2).^.5;
        dotted=(sqrt_undef.*sqrt_def);
        dotted=sum(dotted');
        dotted=dotted';
        tans0=real(acosd(dotted));
        tans0(undef(:,1).*def(:,2)-undef(:,2).*def(:,1) < 0)=...
            -tans0(undef(:,1).*def(:,2)-undef(:,2).*def(:,1) < 0);
        tans=mean(tans0);
        cent = [mean(epi_ellipse(1,:)) mean(epi_ellipse(2,:))]; 
%             ang_inc=ang_inc-1;
            minang = -2*tans-ang_inc;
            undef=zeros(size(im_ux_in,1), 2*size(im_ux_in,2));
            undef(:,1)=im_x_in-cent(1,1);
            undef(:,2)=im_y_in-cent(1,2);
            def=zeros(size(im_ux_in,1), 2*size(im_ux_in,2));
            def(:,1)=im_x_in+im_ux_in-cent(1,1);
            def(:,2)=im_y_in+im_uy_in-cent(1,2);
            r_xy=[cosd((minang)) -sind((minang)); 
                sind((minang)) cosd(minang)]*def';
            def=r_xy';
            im_ux_in=def(:,1)-undef(:,1);
            im_uy_in=def(:,2)-undef(:,2);
            tans0=[];
            for d=1:size(def,1)
                if norm(undef(d,:)) >  1e-6 && norm(def(d,:)) >  1e-6
                    temp=(dot(undef(d,:)/norm(undef(d,:)),def(d,:)/norm(def(d,:))));
                else
                    temp=1;
                end
                temp = acosd(abs(temp));
                if undef(d,1)*def(d,2)-undef(d,2)*def(d,1) < 0
                    temp =-temp;
                end
                tans0=[tans0;real(temp)];
            end
            tans=mean(tans0);
            flipped=getappdata(handles.boundaries,'flipped');
            if ORIENT_TCS == 3
                im_ux=unwrapped{bi,2};
                im_uy=-unwrapped{bi,1};    
            elseif ORIENT_TCS == 2
                if flipped
                    im_ux=unwrapped{bi,2};
                    im_uy=-unwrapped{bi,1};
                else
                    im_ux=unwrapped{bi,2};
                    im_uy=unwrapped{bi,1};
                end
            else %ORIENT_TCS == 1
                 im_ux=-unwrapped{bi,1};
                im_uy=unwrapped{bi,2};
            end
            im_ux(in==1)=im_ux_in;
            im_uy(in==1)=im_uy_in;
            flipped=getappdata(handles.boundaries,'flipped');
            if ORIENT_TCS == 3
                unwrapped{bi,2}=im_ux;
                unwrapped{bi,1}=-im_uy;    
            elseif ORIENT_TCS == 2
                if flipped
                    unwrapped{bi,2}=im_ux;
                    unwrapped{bi,1}=-im_uy;
                else
                    unwrapped{bi,2}=im_ux;
                    unwrapped{bi,1}=im_uy;
                end
            else %ORIENT_TCS == 1
                 unwrapped{bi,1}=-im_ux;
                unwrapped{bi,2}=im_uy;
            end
%         end

        prev_tans(bi,nonempty)=real(tans);
         if bi==END_FRAME
             setappdata(handles.boundaries,'rot_angles',prev_tans);
         end
    end
   
    master_unwrapped=unwrapped;
    masterset_unwrapped{nonempty,1}=master_unwrapped;
end
if isempty(par)
else
    stat= sprintf('FFT fitting done for partition %s ...',par);
    set(handles.edit2,'string',stat);drawnow;
end
% % %   end
save('rotations.mat','prev_tans');
% % % for nonempty=[find(nonempty_all> 0)]'
% vidObj = VideoWriter('newcycle.avi');
% open(vidObj);
% axis tight
epi_d=([masterset(nonempty).epi_d]);
endo_d=([masterset(nonempty).endo_d]);
epi_ellipse= transpose([epi_d((1)).xi,epi_d((1)).yi]);
endo_ellipse= transpose([endo_d((1)).xi,endo_d((1)).yi]);
cent=[mean(epi_ellipse(1,:)),mean(epi_ellipse(2,:))];
for ii=1:size(epi_ellipse,2)
     endo_ellipse(1,ii)=cent(1,1)+ (endo_ellipse(1,ii)-1*cent(1,1));
      endo_ellipse(2,ii)=cent(1,2)+ (endo_ellipse(2,ii)-1*cent(1,2));
%     
    epi_ellipse(1,ii)=cent(1,1)+ (epi_ellipse(1,ii)-1*cent(1,1));
     epi_ellipse(2,ii)=cent(1,2)+ (epi_ellipse(2,ii)-1*cent(1,2));
end

files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
phasex_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{1}));
phasey_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{2}));
phasez_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{3}));

par=[];
par=masterset(nonempty).mag_names;
p=findstr(par,'PAR');
par=par(p:p+4);
p=findstr(par,'_');
if p>0
    par=par(1:p-1);
end
stat= sprintf('Processing partition %s OTSU displacements...',par);
set(handles.edit2,'string',stat);drawnow;
unwrapped=cell(20,2);

info=dicominfo(files(3).name);
% % my_pix=info.PixelSpacing(1);
% % aff{i,1}=[info.PixelSpacing(1)*info.ImageOrientationPatient(rows),...
% %     info.PixelSpacing(1)*info.ImageOrientationPatient(cols),...
% %     -cross(info.ImageOrientationPatient(1:3),info.PixelSpacing(1)*info.ImageOrientationPatient(4:6)),...
% %     info.ImagePositionPatient(1:3)];
if findstr(info.Private_0051_100e,'Tra') ==1
    ORIENT_TCS = 1;
elseif findstr(info.Private_0051_100e,'Cor') ==1
    ORIENT_TCS = 2;
else
    ORIENT_TCS = 3;
end
set(gca,'nextplot','replacechildren');

epi_ellipse=epi_ellipse(:,1:size(epi_ellipse,2));
endo_ellipse=endo_ellipse(:,1:size(endo_ellipse,2));
gen_epi=cell(20,1);
gen_endo=cell(20,1);
gen_disp=cell(20,1);
epi_orig=epi_ellipse;
endo_orig=endo_ellipse;
new_epi=epi_ellipse;;
new_endo=endo_ellipse;;
im_ux_in=[];
im_uy_in=[];

im_ux=zeros(int16(rect(3))+1,int16(rect(4))+1);
im_uy=zeros(int16(rect(3))+1,int16(rect(4))+1);
qI2=[];

SRC_PLOT0=0;
SRC_PLOT=0;
SRC_PLOT_SL=1;
unwrapped=masterset_unwrapped{nonempty,1};
for bi=START_FRAME:1:END_FRAME
    I2=imcrop(dicomread(files(bi).name),rect);
     I2=imfilter(I2,[7 7]);
    [N, edges]=histcounts(I2,10);
%      I2=locallapfilt(I2, .2,.25);
    I2=imsharpen(I2,'Radius',5,'Amount',1);
    I2(I2<=edges(3))=edges(3);
   
   
    thresh = multithresh(I2,10);
    valuesMax = [ thresh(1) max(I2(:)) ];
    [qI2, index] = imquantize(I2, thresh(1), valuesMax);
if SRC_PLOT
    axes(handles.axes2);
    imagesc(I2),colormap gray; 
    
    if ishold(handles.axes2)
    else
      hold(handles.axes2,'on');
    end
    end
    im_ux_old=im_ux;
    im_uy_old=im_uy;
    flipped=getappdata(handles.boundaries,'flipped');
    if ORIENT_TCS == 3
        im_ux=unwrapped{bi,2};
        im_uy=-unwrapped{bi,1};    
    elseif ORIENT_TCS == 2
        if flipped
            im_ux=unwrapped{bi,2};
            im_uy=-unwrapped{bi,1};
        else
            im_ux=unwrapped{bi,2};
            im_uy=unwrapped{bi,1};
        end
    else %ORIENT_TCS == 1
         im_ux=-unwrapped{bi,1};
        im_uy=unwrapped{bi,2};
    end
    if bi<=5
        im_ux=.5*im_ux;
        im_uy=.5*im_uy;
    else
        im_ux=.99*im_ux;
        im_uy=.99*im_uy;
    end
    
    [x,y]=meshgrid(1:size(I2,2),1:size(I2,1));

    old_epi= [epi_ellipse(1,:);epi_ellipse(2,:)];
    old_endo= [endo_ellipse(1,:);endo_ellipse(2,:)];
    old_im_ux_in=im_ux_in;
    old_im_uy_in=im_uy_in;
    [inb onb]=inpolygon(x,y,epi_orig(1,:),epi_orig(2,:));
    [inb2 onb2]=inpolygon(x,y,old_endo(1,:),old_endo(2,:));
    inb=inb -inb2;

    in=(inb+onb);in(in>=2)=1;
    x_in=x(in==1);y_in =y(in==1);
    im_ux_in=im_ux(in==1);im_uy_in=im_uy(in==1);
    
    old_im_ux_in=im_ux_old(in==1);old_im_uy_in=im_uy_old(in==1);
    if bi > 0
        def_vec=[cent(1,1)-x(in==1)-im_ux(in==1),cent(1,2)-y(in==1)-im_uy(in==1)];
        def_vec=double(def_vec);
        def_vec=def_vec./sqrt(def_vec(:,1).^2+def_vec(:,2).^2);
        undef_vec=[cent(1,1)-x(in==1),cent(1,2)-y(in==1)];
        undef_vec=double(undef_vec);
        undef_vec=undef_vec./sqrt(undef_vec(:,1).^2+undef_vec(:,2).^2);
        ang=acosd(dot(def_vec,undef_vec,2));
        ind=find(ang<-20);
        im_ux_in(ind)=0;im_uy_in(ind)=0;
        old_im_ux_in(ind)=0;old_im_uy_in(ind)=0;

        zscores=(im_uy_in-mean(im_uy_in))/std(im_uy_in);
        im_uy_in(find(abs(zscores)>=3))=0;
        zscores=(im_ux_in-mean(im_ux_in))/std(im_ux_in);
        im_ux_in(find(abs(zscores)>=3))=0;

        uy_0=find(im_uy_in==0);ux_0=find(im_ux_in==0);
        uxy_0=unique([uy_0;ux_0]);
        uxy_non0=setdiff(1:size(x_in,1),uxy_0);
        ratio=1:uint16(.25*size(im_ux_in,1));
        for ii=1:size(x_in,1)
        [val, ind]=sort((x_in(ii)-x_in(uxy_non0)).^2+(y_in(ii)-y_in(uxy_non0)).^2);
        im_ux_in(ii)=mean(im_ux_in(uxy_non0(ind(ratio))));
        im_uy_in(ii)=mean(im_uy_in(uxy_non0(ind(ratio))));
        old_im_ux_in(ii)=mean(old_im_ux_in(uxy_non0(ind(ratio))));
        old_im_uy_in(ii)=mean(old_im_uy_in(uxy_non0(ind(ratio))));
        end
    else
        ratio=1:uint16(.1*size(im_ux_in,1));
        for ii=1:size(x_in,1)
            [val, ind]=sort((x_in(ii)-x_in(:)).^2+(y_in(ii)-y_in(:)).^2);
            im_ux_in(ii)=mean(im_ux_in((ind(ratio))));
            im_uy_in(ii)=mean(im_uy_in((ind(ratio))));
            old_im_ux_in(ii)=mean(old_im_ux_in((ind(ratio))));
            old_im_uy_in(ii)=mean(old_im_uy_in((ind(ratio))));
        end
    end

% %     plot(epi_ellipse(1,:),epi_ellipse(2,:),'m-.')
% %     plot(endo_ellipse(1,:),endo_ellipse(2,:),'c-.')   

    for ii=1:size(epi_ellipse,2)
            [val, ind]=sort((epi_orig(1,ii)-x_in(:)).^2+(epi_orig(2,ii)-y_in(:)).^2);
            new_epi(1,ii)=epi_orig(1,ii)+im_ux_in(ind(1));
            new_epi(2,ii)=epi_orig(2,ii)+im_uy_in(ind(1));
    end
    for ii=1:size(endo_ellipse,2)
            [val, ind]=sort((endo_orig(1,ii)-x_in(:)).^2+(endo_orig(2,ii)-y_in(:)).^2);
            
                new_endo(1,ii)=endo_orig(1,ii)+1.*im_ux_in(ind(1));
            new_endo(2,ii)=endo_orig(2,ii)+1*im_uy_in(ind(1));
    end 
    
% %       plot(new_epi(1,:),new_epi(2,:),'m-s')
% %       plot(new_endo(1,:),new_endo(2,:),'-s', 'color',[.4 1 .1])   

    cent=[mean(transpose(endo_orig(1,:))),mean(transpose(endo_orig(2,:)))];
    for bii=1:size(endo_ellipse,2)
        if bi <= 6
            try
                [cx cy c]=improfile(qI2,[.5*(1.9*endo_orig(1,bii)+0.1*new_epi(1,bii));1*new_endo(1,bii)],[0.5*(1.9*endo_orig(2,bii)+0.1*new_epi(2,bii));1*new_endo(2,bii)]);
            catch
                [cx cy c]=improfile(qI2,[.5*(1.9*endo_orig(1,bii)+0.1*new_epi(1,bii));.75*cent(1,1)+.25*new_endo(1,bii)],[0.5*(1.9*endo_orig(2,bii)+0.1*new_epi(2,bii));.75*cent(1,2)+.25*new_endo(2,bii)]);
            end
        else
            [cx cy c]=improfile(qI2,[.5*(1*endo_orig(1,bii)+1.*new_epi(1,bii));.75*cent(1,1)+.25*new_endo(1,bii)],[0.5*(1.*endo_orig(2,bii)+1.*new_epi(2,bii));.75*cent(1,2)+.25*new_endo(2,bii)]);
        end
        if bi>=17 && bi<=17
%             plot(cx,cy,'*');
        end
        c_ind=0;
        c0=c;
        cx=[cx(1);cx;cx(end)]; cy=[cy(1);cy;cy(end)]; c=[c(1);c;c(end)];
        for ci=2:1:size(c0,1)
            if c(ci-1) > thresh(1) && c(ci)<=thresh(1) 
                 if c_ind==0
                    c_ind=ci;
%                     if c_ind>1 %<size(c,1)
                        new_endo(1,bii)=0.5*(cx(c_ind)+cx(c_ind-1));
                        new_endo(2,bii)=0.5*(cy(c_ind)+cy(c_ind-1));
%                     else
%                         new_endo(1,bii)=cx(c_ind);
%                         new_endo(2,bii)=cy(c_ind);
%                     end
                 end
            end
        end
    end  
    
    for bii=2:size(epi_ellipse,2)
        if bi < 10
            [cx cy c]=improfile(qI2,[epi_orig(1,bii);1*(.75*old_endo(1,bii)+0.25*new_epi(1,bii))],[epi_orig(2,bii);1*(.75*old_endo(2,bii)+0.25*new_epi(2,bii))]);
        else
            [cx cy c]=improfile(qI2,[epi_orig(1,bii);1*(1*old_endo(1,bii)+0.*new_epi(1,bii))],[epi_orig(2,bii);1*(1*old_endo(2,bii)+0.*new_epi(2,bii))]);
        end
            c_ind=0;
        for ci=1:size(c,1)-1
                if c(ci) <=thresh(2) && c(ci)< c(ci+1)
                    if c_ind==0
                            c_ind=ci;
                                new_epi(1,bii)=0.5*(cx(c_ind)+cx(c_ind));
                                new_epi(2,bii)=0.5*(cy(c_ind)+cy(c_ind));
                    end
                end
        end 
        if c_ind==0
            new_epi(1,bii)=0.5*(cx(1)+cx(1));
                                new_epi(2,bii)=0.5*(cy(1)+cy(1));
        end
            
    end  
    
    val_ind = zeros(size(new_endo));
    ind = zeros(size(new_endo));
    for ii=1:size(new_endo,2)
            [val_ind(1,ii),val_ind(2,ii)]=min((new_endo(1,ii)-new_epi(1,:)).^2+(new_endo(2,ii)-new_epi(2,:)).^2);
    end
    mean_val_ind=mean(val_ind(1,:));
    i_end=round(.5*size(new_endo,2));
% % %     for ii=1:i_end
% % %         if (new_endo(1,ii)-new_epi(1,val_ind(2,ii)))^2+(new_endo(2,ii)-new_epi(2,val_ind(2,ii)))^2 > mean_val_ind
% % %             ratio=sqrt(mean_val_ind/val_ind(1,ii));
% % %                         new_endo(1,ii)=new_epi(1,val_ind(2,ii))-ratio*((new_epi(1,val_ind(2,ii))-new_endo(1,ii)));
% % %             new_endo(2,ii)=new_epi(2,val_ind(2,ii))-ratio*((new_epi(2,val_ind(2,ii))-new_endo(2,ii)));
% % %         end
% % %     end
%     if bi >3

    epi_ellipse=new_epi;
    endo_ellipse=new_endo;
    SHOW_RAW=1;
if SHOW_RAW
    gen_disp{bi}=[ x_in,y_in,+im_ux_in,im_uy_in];
    gen_epi{bi}=epi_ellipse;
    gen_endo{bi}=endo_ellipse;
    masterset(nonempty).gen_epi=gen_epi;
    masterset(nonempty).gen_endo=gen_endo;
        masterset(nonempty).gen_disp=gen_disp;
        setappdata(handles.loaddir,'masterset',masterset);
        p_str2=get(handles.listboxmag,'string');
        nonempty_all2=ismember({masterset.mag_names}',p_str2);
        [l1 l2]=ismember(nonempty,find(nonempty_all2> 0));
       set(handles.listboxmag,'value',l2);
        set(handles.slider1,'value',bi-2);
        if bi==9
        setappdata(handles.boundaries,'showfig',1);
        end
        slider1_moveFnc(handles);
        setappdata(handles.boundaries,'showfig',[]);
        drawnow;
end
%     end
   
% %       plot(new_epi(1,:),new_epi(2,:),'m-*')
% %       plot(new_endo(1,:),new_endo(2,:),'-*','color',[0.11 0.67 0.84])   

    [z, a, b, alpha] = fitellipse(epi_ellipse,'linear','constraint','trace')
    X=plotellipse(z, a, b, alpha);
% %     plot(epi_ellipse(1,:),epi_ellipse(2,:),'m-*');
% %     plot(X(1,:),X(2,:),'y-*');
    
    epi_ellipse=Closest(epi_ellipse',X');
    epi_ellipse=epi_ellipse';
    [val ids ]=(unique(mean(epi_ellipse)));
    ids=sort(ids);
%     epi_ellipse=[epi_ellipse(1,ids');epi_ellipse(2,ids')];
%     plot(epi_ellipse(1,:),epi_ellipse(2,:),'g-o');
    
    [z, a, b, alpha] = fitellipse(endo_ellipse,'linear','constraint','trace')
    X=plotellipse(z, a, b, alpha);
    if SRC_PLOT0
    plot(endo_ellipse(1,:),endo_ellipse(2,:),'m-*');
     plot(X(1,:),X(2,:),'y-*');
    end
    endo_ellipse=Closest(endo_ellipse',X');
    endo_ellipse=endo_ellipse';
    [val ids ]=(unique(mean(endo_ellipse)));
    ids=sort(ids);
%     endo_ellipse=[endo_ellipse(1,ids');endo_ellipse(2,ids')];
    endo0=endo_ellipse';
    yy=[];xx=[];
    x0=endo0(:,1);
    y0=endo0(:,2);
    sz=floor(size(endo0,1)/8);
    new_sz=size(1:sz:size(x0,1),2);
    while new_sz > 8
        sz=sz+1;
        new_sz=size(1:floor(sz):size(x0,1),2);
    end
    endo_x0=x0(1:floor(sz):size(x0,1));
    endo_y0=y0(1:floor(sz):size(y0,1));
    
    epi0=epi_ellipse';
    yy=[];xx=[];
    x0=epi0(:,1);
    y0=epi0(:,2);
    sz=floor(size(epi0,1)/8);
    new_sz=size(1:floor(sz):size(x0,1),2);
    while new_sz > 8
        sz=sz+1;
        new_sz=size(1:floor(sz):size(x0,1),2);
    end
    epi_x0=x0(1:floor(sz):size(x0,1));
    epi_y0=y0(1:floor(sz):size(y0,1));
  %     plot(epi_x0,epi_y0,'c*-'); 
  
    corners=repmat([0 0 0 0 0 0],1,100);
    xyz=[epi_x0';epi_y0'];%[decimate(epi_ellipse(1,:)',5,9),decimate(epi_ellipse(2,:)',5,9)]';
    sz=size(xyz,2);
    cvec=corners(1:sz+1);
    [pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
    s_start=100;
    s = unique([linspace(0,pp.breaks(end),s_start),sparam]);
    while size(s,2)<size(epi_orig,2)
        s_start=s_start+1;
        s = unique([linspace(0,pp.breaks(end),s_start),sparam]);
    end
    pts = fnval(pp,s);
    epi_ellipse=pts;

    sz=size(epi_ellipse(1,:),1);
%     epi_ellipse(1,sz+1)=epi_ellipse(1,1);
%     epi_ellipse(2,sz+1)=epi_ellipse(2,1);

    xyz=[endo_x0';endo_y0'];%[decimate(endo_ellipse(1,:)',5,9),decimate(endo_ellipse(2,:)',5,9)]';
    sz=size(xyz,2);
    cvec=corners(1:sz+1);
    [pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
    s_start=100;
    s = unique([linspace(0,pp.breaks(end),s_start),sparam]);
    while size(s,2)<size(epi_orig,2)
        s_start=s_start+1;
        s = unique([linspace(0,pp.breaks(end),s_start),sparam]);
    end
    pts = fnval(pp,s);
    endo_ellipse=pts;
    sz=size(endo_ellipse,2);
    endo_ellipse(:,sz)=endo_ellipse(:,1);
    sz=size(epi_ellipse,2);
    epi_ellipse(:,sz)=epi_ellipse(:,1);
    gen_epi{bi}=epi_ellipse;
    gen_endo{bi}=endo_ellipse;
    masterset=getappdata(handles.loaddir,'masterset');
    masterset(nonempty).mag=im_m;
    masterset(nonempty).phases={im_p1,im_p2,im_p3};
%     masterset(nonempty).unwrapped=unwrapped;
    masterset(nonempty).gen_epi=gen_epi;
    masterset(nonempty).gen_endo=gen_endo;
    changeinitwalls=get(handles.changeinitwalls,'value');
    if bi ==3 && changeinitwalls
        masterset(nonempty).epi_d.xi=epi_ellipse(1,:)';
        masterset(nonempty).epi_d.yi=epi_ellipse(2,:)';
        masterset(nonempty).endo_d.xi=endo_ellipse(1,:)';
        masterset(nonempty).endo_d.yi=endo_ellipse(2,:)';
    end
    
    setappdata(handles.loaddir,'masterset',masterset);
if SRC_PLOT
    plot(epi_ellipse(1,:),epi_ellipse(2,:),'color','r','LineWidth',2)
    plot(endo_ellipse(1,:),endo_ellipse(2,:),'-','color','g','LineWidth',2)
    plot(epi_orig(1,:),epi_orig(2,:),'--r','LineWidth',2);
    plot(endo_orig(1,:),endo_orig(2,:),'g--','LineWidth',2);
%     quiver(x_in(in==0),y_in(in==0),+im_ux_in(in==0),im_uy_in(in==0),'Autoscale','off','Color','c','LineWidth',.005);
        
end
     if bi==3
         endo_orig=endo_ellipse;
         epi_orig=epi_ellipse;
     end
     [in on]=inpolygon(x_in+1.*im_ux_in,y_in+1.*im_uy_in,old_epi(1,:),old_epi(2,:));  
    if isempty(old_im_ux_in)
        im_ux_in2=im_ux_in(in==1);
        im_uy_in2=im_uy_in(in==1);
    else
        im_ux_in2=im_ux_in(in==1)-old_im_ux_in(in==1);
        im_uy_in2=im_uy_in(in==1)-old_im_uy_in(in==1);
    end

%         in=inpolygon(x_in+im_ux_in,y_in+im_uy_in,endo_ellipse(1,:),endo_ellipse(2,:)) + ...
%             inpolygon(x_in,y_in,endo_ellipse(1,:),endo_ellipse(2,:));  ;  
        in=inpolygon(x_in,y_in,endo_ellipse(1,:),endo_ellipse(2,:)) + ...
            inpolygon(x_in,y_in,endo_ellipse(1,:),endo_ellipse(2,:));  ;  
        if SRC_PLOT
            quiver(x_in(in==0),y_in(in==0),+im_ux_in(in==0),im_uy_in(in==0),'Autoscale','off','Color','c','LineWidth',.005);
            hold(handles.axes2,'off');
        end
        gen_disp{bi}=[ x_in(in==0),y_in(in==0),+im_ux_in(in==0),im_uy_in(in==0)];
        masterset(nonempty).gen_disp=gen_disp;
        setappdata(handles.loaddir,'masterset',masterset);
        p_str2=get(handles.listboxmag,'string');
        nonempty_all2=ismember({masterset.mag_names}',p_str2);
        [l1 l2]=ismember(nonempty,find(nonempty_all2> 0));
       set(handles.listboxmag,'value',l2);
        set(handles.slider1,'value',bi-2);
        slider1_moveFnc(handles);
        drawnow;
    end
if SRC_PLOT
    title(sprintf('After %d ms',(bi-3)*15+3))
end
    stat=sprintf('OTSU Boundary frame %d of %d done...',bi-2, END_FRAME-2);
    set(handles.edit2,'string',stat);
    drawnow;
    
    masterset=getappdata(handles.loaddir,'masterset');
    gen_epi=masterset(nonempty).gen_epi;
    gen_endo=masterset(nonempty).gen_endo;
    unwrap_fit_x=[];
    unwrap_fit_y=[];
    for bi=START_FRAME:END_FRAME
        im_ux=gen_endo{bi,1}(1,:);%+unwrapped{START_FRAME,1};
        im_uy=gen_endo{bi,1}(2,:);%+unwrapped{START_FRAME,2};
        ;
        unwrap_fit_x=[unwrap_fit_x,im_ux'];%-mean(im_ux)];
        unwrap_fit_y=[unwrap_fit_y,im_uy'];%-mean(im_uy)];
    end
    
    unwrap_fit_x2=unwrap_fit_x;
    unwrap_fit_y2=unwrap_fit_y;
    fsz2=size(unwrap_fit_x,2);

    for fi=1:size(unwrap_fit_x,1)
        f=fit([1:fsz2]',unwrap_fit_x(fi,:)','poly2');
        res=feval(f,[1:fsz2]');
        unwrap_fit_x(fi,:)=res';
        % %         f=fit(15*([1:fsz2]'),unwrap_fit_y(fi,:)','fourier2');
        f=fit([1:fsz2]',unwrap_fit_y(fi,:)','poly2');
        res=feval(f,[1:fsz2]');
        unwrap_fit_y(fi,:)=res';
    end
    
    ki=1;
    for bi=START_FRAME:END_FRAME
%         im_ux=unwrapped{bi,1};
%         im_uy=unwrapped{bi,2};
        im_ux=unwrap_fit_x(:,ki);
        im_uy=unwrap_fit_y(:,ki);
        gen_endo{bi,1}=[im_ux';im_uy'];%-1*mean(im_ux(in==1));
%         gen_endo{bi,1}=im_uy;-1*mean(im_uy(in==1));
        x_in=masterset(nonempty).gen_disp{bi}(:,1);
        y_in=masterset(nonempty).gen_disp{bi}(:,2);
        im_ux_in=masterset(nonempty).gen_disp{bi}(:,3);
        im_uy_in=masterset(nonempty).gen_disp{bi}(:,4);
        in=inpolygon(x_in,y_in,gen_endo{bi,1}(1,:),gen_endo{bi,1}(2,:)) + ...
            inpolygon(x_in,y_in,gen_endo{bi,1}(1,:),gen_endo{bi,1}(2,:));  
        gen_disp{bi}=[ x_in(in==0),y_in(in==0),+im_ux_in(in==0),im_uy_in(in==0)];
        masterset(nonempty).gen_disp=gen_disp;
        ki=ki+1;
        masterset(nonempty).gen_endo=gen_endo;
        setappdata(handles.loaddir,'masterset',masterset);
        p_str2=get(handles.listboxmag,'string');
        nonempty_all2=ismember({masterset.mag_names}',p_str2);
        [l1 l2]=ismember(nonempty,find(nonempty_all2> 0));
       set(handles.listboxmag,'value',l2);
        set(handles.slider1,'value',bi-2);
        if bi==9
        setappdata(handles.boundaries,'showfig',1);
        end
        slider1_moveFnc(handles);
        setappdata(handles.boundaries,'showfig',[]);
        stat= sprintf('***Fast fourier(FFT) fitting %s boundary at instance %d...',par, bi-2);
        set(handles.edit2,'string',stat);drawnow;
% %         axh = findobj(gcf,'Type','axes');
% %         figure;
% %         copyobj(axh(1),gcf);
        drawnow;
    end 
    
% close(vidObj);
    if isempty(par)
    else
        stat= sprintf('Boundaries done for partition %s ...',par);
        set(handles.edit2,'string',stat);drawnow;
    end
end
% gen_epi=([masterset(find(~cellfun(@isempty,nonempty))).gen_epi])';
% gen_endo=([masterset(find(~cellfun(@isempty,nonempty))).gen_endo])';
masterset=getappdata(handles.loaddir,'masterset');
nonempty={masterset(1:size(masterset,2)).epi_d};
gen_disp=([masterset(find(~cellfun(@isempty,nonempty))).gen_disp]);
tot_size=size(find(~cellfun(@isempty,gen_disp(:,1))),1);
frames=cell(tot_size,1);
for f =1:size(frames,1)
frames{f,1}=num2str(f);
end
set(handles.instance,'string',frames);
set(handles.instance,'value',tot_size);

prev_tans=getappdata(handles.boundaries,'rot_angles')
save('rotations.mat','prev_tans');
setappdata(handles.strain,'unwrapped',1);
setappdata(handles.strain,'strainsdone',0);
setappdata(handles.strain,'dispdone',0);
set(handles.changeinitwalls,'value',0);
changeinitwalls_Callback(hObject, eventdata, handles);

% --- Executes on button press in unwrapsingleboundary.
function unwrapsingleboundary_Callback(hObject, eventdata, handles)
% hObject    handle to unwrapsingleboundary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% h=impoint(handles.axes2);
% h.addNewPositionCallback(@fcn) ;

PLOT_3D=0;
p_str=get(handles.listboxmag,'string');
p_val=get(handles.listboxmag,'value');
p_str=p_str(p_val);

masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);
setappdata(handles.listboxmag,'nonempty_all',nonempty_all);
numvec=find(nonempty_all>0);
QualityGuidedUnwrap(handles,numvec);
searchboundaries_Callback(hObject, eventdata, handles);
if PLOT_3D
    masterset=getappdata(handles.loaddir,'masterset');
    nonempty={masterset(1:size(masterset,2)).epi_d};
    epi_d=([masterset(find(~cellfun(@isempty,nonempty))).epi_d]);
    epi_d=epi_d';
    endo_d=([masterset(find(~cellfun(@isempty,nonempty))).endo_d]);
    endo_d=endo_d';
    figure;hold
    num_slices=size(epi_d,1);
    for bi=1:num_slices
        plot3(epi_d(bi).xi,epi_d(bi).yi,epi_d(bi).zi,'m*-');
        plot3(endo_d(bi).xi,endo_d(bi).yi,endo_d(bi).zi,'r*-');
    end
    view([1 1 1]);
end

% --- Executes on button press in showstack.
function showstack_Callback(hObject, eventdata, handles)
% hObject    handle to showstack (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p_str=get(handles.listboxmag,'string');
p_str=flip(p_str);
%set(handles.listboxmag,'string',p_str);
filedir=get(handles.filedir,'string');
addpath(genpath(filedir));

load allist;
allist=flip(allist);
newstr=p_str;
xdirsc=cell(size(newstr));
ydirsc=cell(size(newstr));
zdirsc=cell(size(newstr));

for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = find(not(cellfun('isempty', IndexC)));
    xdirsc{i}=allist{id,2};
    ydirsc{i}=allist{id,3};
    zdirsc{i}=allist{id,4};
end
id=[];
for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = [id;find(not(cellfun('isempty', IndexC)))];
    
end
[id,id2]=sort(id,1);
set(handles.listboxmag,'string',newstr(id2));

mystring=cell(size(p_str,1),3);
for i=1:size(p_str)
    mystring{i,1}=xdirsc{i,1};
    mystring{i,2}=ydirsc{i,1};
    mystring{i,3}=zdirsc{i,1};
end
mystring2=reshape(mystring,size(mystring,1)*size(mystring,2),1);
set(handles.listboxphase,'string',mystring2);
setappdata(handles.listboxphase,'mystring',mystring);
save('mystring.mat','mystring');
save('allist.mat','allist');
p_str=get(handles.listbox1,'string');
p_str=flip(p_str);
set(handles.listbox1,'string',p_str);
masterset=getappdata(handles.loaddir,'masterset');
masterset=flip(masterset);
setappdata(handles.loaddir,'masterset',masterset);
% rot_range=getappdata(handles.loaddir,'rot_range');
% rot_range=flip(rot_range);
% setappdata(handles.loaddir,'rot_range',rot_range);


% --- Executes on mouse press over axes background.
function axes2_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
slider1_moveFnc(handles);
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

function slider1_moveFnc(handles)
if isempty(getappdata(handles.boundaries,'showfig'))
else
    slider1_moveFnc_V2;
end
addpath(genpath('geom2d'));
filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');

p_str=get(handles.listboxmag,'string');
p_val=get(handles.listboxmag,'value');
p_str=p_str(p_val);

masterset=getappdata(handles.loaddir,'masterset');
if isempty(masterset)
    return;
end

nonempty_all=ismember({masterset.mag_names}',p_str);
ax=(handles.axes2);
axes(ax);
xlim=ax.XLim;
ylim=ax.YLim;
for nonempty=[find(nonempty_all> 0)]'

files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
phasex_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{1}));
phasey_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{2}));
phasez_f=dir(strcat(filedir,'\',masterset(nonempty).ph_names{3}));

gen_epi=masterset(nonempty).gen_epi;
gen_endo=masterset(nonempty).gen_endo;
gen_disp=masterset(nonempty).gen_disp;
unwrapped=[(masterset(nonempty).unwrapped)];
sz=size(masterset(nonempty).mag);
if sz(1)==0
    sz=size(dicomread(files(3).name));
end
[x y]=meshgrid(1:sz(2),1:sz(1));
rect=getappdata(handles.boundaries,'rect');
if isempty(rect)
    sz1=sz(1)-33;sz2=sz(2)-33;
    rect = [10 10 sz1 sz2];
end
if ylim(2)-ylim(1) <1.5
    xlim=[0.5 rect(3)];
    ylim=[0.5 rect(4)];
end

fr=get(handles.FrameRange,'string');
curval=get(handles.FrameRange,'value');
fr=fr(curval);
[t,rem]=strtok(reverse(fr),'-');
t=reverse(t);
fr=str2num(t{1})+2;
START_FRAME=2;
END_FRAME=fr;
% % if isempty(gen_epi)
% % else
% %     temp=find(~cellfun(@isempty,gen_epi));
% %     START_FRAME = temp(1);
% %     END_FRAME = temp(end);
% % 
% %     if END_FRAME-START_FRAME < 0
% %         return;
% %     end
% % end

sl=round(get(handles.slider1,'value'));
% sl=START_FRAME+round((END_FRAME-START_FRAME)*sl)
set(handles.slidertext,'string',num2str(sl));
info=dicominfo(files(3).name);
% % my_pix=info.PixelSpacing(1);
% % aff{i,1}=[info.PixelSpacing(1)*info.ImageOrientationPatient(rows),...
% %     info.PixelSpacing(1)*info.ImageOrientationPatient(cols),...
% %     -cross(info.ImageOrientationPatient(1:3),info.PixelSpacing(1)*info.ImageOrientationPatient(4:6)),...
% %     info.ImagePositionPatient(1:3)];
if findstr(info.Private_0051_100e,'Tra') ==1
    ORIENT_TCS = 1;
elseif findstr(info.Private_0051_100e,'Cor') ==1
    ORIENT_TCS = 2;
else
    ORIENT_TCS = 3;
end
  
%
% for bi=START_FRAME:1:END_FRAME
    for bi=sl+START_FRAME
    I2=imcrop(dicomread(files(bi).name),rect);
    
    I1=imfilter(I2,[7 7]);
    [N, edges]=histcounts(I1,10);
    I1=imsharpen(I1,'Radius',5,'Amount',1);
   I1(I1<=edges(3))=edges(3);
   thresh = multithresh(I1,10);
    valuesMax = [ thresh(1) max(I1(:)) ];
    [qI1, index] = imquantize(I1, thresh(1), valuesMax);
   curval=1.0-0.5*get(handles.slider2,'value');
    
    display = get(handles.displaymenu,'value');
    if display==1
        h=imshow(I1, [curval*min(I1(:)) curval*max(I1(:))], 'Parent', handles.axes2);
    elseif display >1 && display <=4
        flipped=getappdata(handles.boundaries,'flipped');
            if ORIENT_TCS == 3
                if display == 2
                    I1=imcrop(dicomread(phasey_f(bi).name),rect);
                elseif display==3
                    I1=imcrop(dicomread(phasex_f(bi).name),rect); 
                else
                    I1=imcrop(dicomread(phasez_f(bi).name),rect);
                end
            elseif ORIENT_TCS == 2
                if display == 2
                    I1=imcrop(dicomread(phasey_f(bi).name),rect);
                elseif display==3
                    if flipped
                        I1=imcrop(dicomread(phasex_f(bi).name),rect);
                    else
                        I1=flip(imcrop(dicomread(phasex_f(bi).name),rect));
                    end
                else
                    I1=imcrop(dicomread(phasez_f(bi).name),rect);
                end
            else %ORIENT_TCS == 1
                if display == 2
                    I1=imcrop(dicomread(phasex_f(bi).name),rect);
                elseif display==3
                    I1=imcrop(dicomread(phasey_f(bi).name),rect);
                else
                    I1=imcrop(dicomread(phasez_f(bi).name),rect);
                end
            end
            h=imshow(I1, [curval*min(I1(:)) curval*max(I1(:))], 'Parent', handles.axes2);
            colormap gray; axis tight
    else
        if isempty(unwrapped)
            h=imshow(I1, [min(I1(:)) max(I1(:))], 'Parent', handles.axes2);
        else
            if isempty(gen_epi{bi})
                in = ones(size(masterset(nonempty).mag));
            else
                [in on]=inpolygon(x,y,gen_epi{bi}(1,:),gen_epi{bi}(2,:));
                [in2 on2]=inpolygon(x,y,gen_endo{bi}(1,:),gen_endo{bi}(2,:));
%                 in=in-in2;
            end
            flipped=getappdata(handles.boundaries,'flipped');
            if ORIENT_TCS == 3
                if display == 5
                    im_unwr=unwrapped{bi,2};
                elseif display==6
                    im_unwr=-unwrapped{bi,1};  
                else
                    im_unwr=unwrapped{bi,3};
                end
            elseif ORIENT_TCS == 2
                if flipped
                    im_ux=unwrapped{bi,2};
                    im_uy=-unwrapped{bi,1};
                else
                    im_ux=unwrapped{bi,2};
                    im_uy=unwrapped{bi,1};
                end
                if display == 5
                    im_unwr=im_ux;
                elseif display==6
                    im_unwr=im_uy;  
                else
                    im_unwr=unwrapped{bi,3};
                end
            else %ORIENT_TCS == 1
                 im_ux=-unwrapped{bi,1};
                im_uy=unwrapped{bi,2};
                if display == 5
                    im_unwr=im_ux;
                elseif display==6
                    im_unwr=im_uy;  
                else
                    im_unwr=unwrapped{bi,3};
                end
            end
            I1=im_unwr.*in;
%             I1(I1==0)=max(I1(:));
            h=imshow(I1, [-pi pi], 'Parent', handles.axes2);
            colormap gray; axis tight
        end
    end
    set(h, 'ButtonDownFcn', {@gcf_ButtonDownFc,'handles'});
    hold on;
    
    p_str=get(handles.listboxmag,'string');
    p_val=get(handles.listboxmag,'value');
    par=string(p_str(p_val));
    p=strfind(par,'PAR');
    par=par{1}(p:p+4);
    p=strfind(par,'_');
    if p>0
        par=par(1:p-1);
    end
    stat= sprintf('Partition %s frame %d...',par,sl);
    ti=title(stat, 'color', 'yellow');
    pos = get (ti, 'position' );
    new_position=[(pos(1)),(pos(2) + 3), pos(3)];
    set (ti, 'position', new_position );
    if isempty(gen_epi) || bi> max(size(gen_epi)) || isempty(gen_epi{bi}) 
    else
        plot(gen_epi{bi}(1,:),gen_epi{bi}(2,:),'r-','Parent',handles.axes2,'Tag','epi', 'LineWidth', 2);
        plot(gen_endo{bi}(1,:),gen_endo{bi}(2,:),'g-','Parent',handles.axes2,'Tag','endo', 'LineWidth', 2);
        x0=gen_epi{bi}(1,:);
        y0=gen_epi{bi}(2,:);
        sz=floor(size(x0,2)/8);
        new_sz=size(1:sz:size(x0,2),2);
        while new_sz > 8
            sz=sz+1;
            new_sz=size(1:floor(sz):size(x0,2),2);
        end
        x0=x0(1:sz:end);y0=y0(1:sz:end);
        if get(handles.editboundary,'value')==1
        plot(x0,y0,'ro','MarkerFaceColor','r','Parent',handles.axes2,'Tag','epi_mrkr');
        end
        x0=gen_endo{bi}(1,:);
        y0=gen_endo{bi}(2,:);
        x0=x0(1:sz:end);y0=y0(1:sz:end);
        if get(handles.editboundary,'value')==1
        plot(x0,y0,'go','MarkerFaceColor','g','Parent',handles.axes2,'Tag','endo_mrkr');
        end
        if get(handles.initwalls,'value')==1
         plot(masterset(nonempty).epi_d.xi,masterset(nonempty).epi_d.yi,'r--','Parent',handles.axes2,'LineWidth', 1.5);
         plot(masterset(nonempty).endo_d.xi,masterset(nonempty).endo_d.yi,'g--','Parent',handles.axes2,'LineWidth', 1.5);
        end
    end
    if isempty(gen_epi)  || bi> max(size(gen_epi)) || isempty(gen_epi{bi}) || isempty(gen_disp) || isempty(gen_disp{bi})
    else
        if get(handles.disp2d,'value')==1
            x_in=gen_disp{bi}(:,1);
            y_in=gen_disp{bi}(:,2);
            ux_in=gen_disp{bi}(:,3);
            uy_in=gen_disp{bi}(:,4);
            quiver(x_in,y_in,ux_in,uy_in,'Autoscale','off','Color','c','LineWidth',.005,'Parent',handles.axes2,'Tag','qvr');
        end
    end
    hold off
    
    end
    if get(handles.zoompan,'Value') 
    else
%         set (gcf, 'WindowButtonMotionFcn', @mouseMove);
        h=get(gca,'Children');
        set(h, 'ButtonDownFcn', {@gcf_ButtonDownFcn});
%         set(gcf, 'WindowButtonUpFcn', {@gcf_ButtonUpFcn});
    end
if getappdata(handles.zoompan,'reset')
    setappdata(handles.zoompan,'reset',0);
else
set(ax,'XLim',xlim);
set(ax,'YLim',ylim);
end
% close(vidObj);
end


function gcf_ButtonDownFcn(hObject, eventdata)
C = get (gca, 'CurrentPoint');
% fprintf('Point from button down is %d',C)
handles = guidata( ancestor(hObject, 'figure') );

setappdata(handles.axes2,'epi_mrkr',0);
setappdata(handles.axes2,'endo_mrkr',0);
    
p_val=get(handles.listboxmag,'value');
if isempty(p_val)
    return;
end
p_str=get(handles.listboxmag,'string');
if isempty(p_str)
    return;
end
p_str=p_str(p_val);

rect=getappdata(handles.boundaries,'rect');
masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);
nonempty=[find(nonempty_all> 0)]'

files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
gen_epi=masterset(nonempty).gen_epi;
gen_endo=masterset(nonempty).gen_endo;

temp=find(~cellfun(@isempty,gen_epi));
START_FRAME = temp(1);
END_FRAME = temp(end);

if END_FRAME-START_FRAME < 0
    return;
end

sl=2+round(get(handles.slider1,'value'));
x0=gen_epi{sl}(1,:)';
y0=gen_epi{sl}(2,:)';
sz=floor(size(x0,1)/8);
    new_sz=size(1:sz:size(x0,1),2);
    while new_sz > 8
        sz=sz+1;
        new_sz=size(1:floor(sz):size(x0,1),2);
    end
epi_x0=x0(1:floor(sz):size(x0,1));
epi_y0=y0(1:floor(sz):size(y0,1));
[va id]=min((epi_x0(:,1)-C(1,1)).^2+(epi_y0(:,1)-C(1,2)).^2);
  
h=get(gca,'Children');
val=0; id =0;
val2=0; id2=0;

for hi=1:size(h,1)
if strfind(h(hi).Tag,'epi_mrkr')
    [val,id]=min((C(1,1)-h(hi).XData(1,:)).^2+(C(1,2)-h(hi).YData(1,:)).^2);
end
if strfind(h(hi).Tag,'endo_mrkr')
    [val2,id2]=min((C(1,1)-h(hi).XData(1,:)).^2+(C(1,2)-h(hi).YData(1,:)).^2);
end

if val < val2
    setappdata(handles.axes2,'epi_mrkr',id);
else
    setappdata(handles.axes2,'endo_mrkr',id2);
end

end
if get(handles.zoompan,'Value') 
    else
        set (gcf, 'WindowButtonMotionFcn', @mouseMove);
        set(gcf, 'WindowButtonUpFcn', {@gcf_ButtonUpFcn});
    end

function mouseMove (hObject, eventdata)
C = get (gca, 'CurrentPoint');
% % fprintf('Point from button down is %d',C);
handles = guidata( ancestor(hObject, 'figure') );
h=get(gca,'Children');
del_hi=0;
del_hi2=0;


p_val=get(handles.listboxmag,'value')
if isempty(p_val)
    return;
end
if p_val <=0
    return;
end

p_str=get(handles.listboxmag,'string');
if isempty(p_str)
    return;
end
p_str=p_str(p_val);

rect=getappdata(handles.boundaries,'rect');
masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);
nonempty=[find(nonempty_all> 0)]';

gen_epi=masterset(nonempty).gen_epi;
if isempty(gen_epi)
    return;
end
temp=find(~cellfun(@isempty,gen_epi));
START_FRAME = temp(1);
END_FRAME = temp(end);

if END_FRAME-START_FRAME < 0
    return;
end

sl=2+round(get(handles.slider1,'value'));
epi_orig=[];

mrkr_num=getappdata(handles.axes2,'epi_mrkr');
if mrkr_num > 0
    epi_orig=gen_epi{sl};
    for hi=1:size(h,1)
        if strfind(h(hi).Tag,'epi_mrkr')
            del_hi=hi;
        h(hi).XData(1,mrkr_num)=C(1,1); 
        h(hi).YData(1,mrkr_num)=C(1,2); 
        new_x=h(hi).XData;
        new_y=h(hi).YData;
        end
        if strfind(h(hi).Tag,'epi')
            del_hi2=hi;
        end
    end
    if del_hi > 0
    delete(h(del_hi));
    end
    if del_hi2 > 0
    delete(h(del_hi2));
    end

    corners=repmat([0 0 0 0 0 0],1,100);
    xyz=[new_x;new_y];%[decimate(epi_ellipse(1,:)',5,9),decimate(epi_ellipse(2,:)',5,9)]';
    sz=size(xyz,2);
    cvec=corners(1:sz);
    [pp sparam]=cscvn2(xyz(:,[1:end]),'periodic',cvec);
    s_start=100;
    s = unique([linspace(0,pp.breaks(end),s_start),sparam]);
    while size(s,2)<size(epi_orig,2)
        s_start=s_start+1;
        s = unique([linspace(0,pp.breaks(end),s_start),sparam]);
    end
    pts = fnval(pp,s);
    hold on
    plot(pts(1,:),pts(2,:),'r-','Parent',handles.axes2,'Tag','epi','LineWidth', 2);
    if get(handles.editboundary,'value')==1
    plot(new_x,new_y,'ro','MarkerFaceColor','r','Parent',handles.axes2,'Tag','epi_mrkr');
    end
    hold off
end

mrkr_num=getappdata(handles.axes2,'endo_mrkr');
if mrkr_num > 0
    epi_orig=gen_epi{sl};
    for hi=1:size(h,1)
        if strfind(h(hi).Tag,'endo_mrkr')
            del_hi=hi;
        h(hi).XData(1,mrkr_num)=C(1,1); 
        h(hi).YData(1,mrkr_num)=C(1,2); 
        new_x=h(hi).XData;
        new_y=h(hi).YData;
        end
        if strfind(h(hi).Tag,'endo')
            del_hi2=hi;
        end
    end
    if del_hi > 0
    delete(h(del_hi));
    end
    if del_hi2 > 0
    delete(h(del_hi2));
    end

    corners=repmat([0 0 0 0 0 0],1,100);
    xyz=[new_x;new_y];%[decimate(endo_ellipse(1,:)',5,9),decimate(endo_ellipse(2,:)',5,9)]';
    sz=size(xyz,2);
    cvec=corners(1:sz);
    [pp sparam]=cscvn2(xyz(:,[1:end]),'periodic',cvec);
    s_start=100;
    s = unique([linspace(0,pp.breaks(end),s_start),sparam]);
    while size(s,2)<size(epi_orig,2)
        s_start=s_start+1;
        s = unique([linspace(0,pp.breaks(end),s_start),sparam]);
    end
    pts = fnval(pp,s);
    hold on
    plot(pts(1,:),pts(2,:),'g-','Parent',handles.axes2,'Tag','endo', 'LineWidth', 2);
    if get(handles.editboundary,'value')==1
    plot(new_x,new_y,'go','MarkerFaceColor','g','Parent',handles.axes2,'Tag','endo_mrkr');
    end
    hold off
end

function gcf_ButtonUpFcn(hObject, eventdata)
C = get (gca, 'CurrentPoint');
% fprintf('Point from button down is %d',C)
handles = guidata( ancestor(hObject, 'figure') );

p_val=get(handles.listboxmag,'value');
if isempty(p_val)
    return;
end
p_str=get(handles.listboxmag,'string');
if isempty(p_str)
    return;
end
p_val=get(handles.listboxmag,'value');
p_str=p_str(p_val);

rect=getappdata(handles.boundaries,'rect');
masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember({masterset.mag_names}',p_str);
nonempty=[find(nonempty_all> 0)]'

files=dir(strcat(get(handles.filedir,'string'),masterset(nonempty).mag_names,'\'));
gen_epi=masterset(nonempty).gen_epi;
gen_endo=masterset(nonempty).gen_endo;

temp=find(~cellfun(@isempty,gen_epi));
START_FRAME = temp(1);
END_FRAME = temp(end);

if END_FRAME-START_FRAME < 0
    return;
end

sl=2+round(get(handles.slider1,'value'));
x0=gen_epi{sl}(1,:)';

epi_orig=gen_epi{sl};

y0=gen_epi{sl}(2,:)';
sz=floor(size(x0,1)/8);
    new_sz=size(1:sz:size(x0,1),2);
    while new_sz > 8
        sz=sz+1;
        new_sz=size(1:floor(sz):size(x0,1),2);
    end
epi_x0=x0(1:floor(sz):size(x0,1));
epi_y0=y0(1:floor(sz):size(y0,1));
[va id]=min((epi_x0(:,1)-C(1,1)).^2+(epi_y0(:,1)-C(1,2)).^2);
  
% corners=repmat([0 0 0 0 0 0],1,100);
% xyz=[epi_x0';epi_y0'];%[decimate(epi_ellipse(1,:)',5,9),decimate(epi_ellipse(2,:)',5,9)]';
% sz=size(xyz,2);
% cvec=corners(1:sz+1);
% [pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
% s = unique([linspace(0,pp.breaks(end),100),sparam]);
% pts = fnval(pp,s);
% epi_ellipse=pts;
h=get(gca,'Children');

for hi=1:size(h,1)
if strfind(h(hi).Tag,'epi')
    new_x=h(hi).XData;
    new_y=h(hi).YData;
    gen_epi{sl}=[new_x;new_y];
    if sl==6
        masterset(nonempty).epi_d.xi=new_x';
        masterset(nonempty).epi_d.yi=new_y';
    end
end
if strfind(h(hi).Tag,'endo')
    new_x=h(hi).XData;
    new_y=h(hi).YData;
    gen_endo{sl}=[new_x;new_y];
    if sl==6
        masterset(nonempty).endo_d.xi=new_x';
        masterset(nonempty).endo_d.yi=new_y';
    end
        
end
end
setappdata(handles.axes2,'epi_mrkr',0);
setappdata(handles.axes2,'endo_mrkr',0);

masterset(nonempty).gen_epi=gen_epi;
masterset(nonempty).gen_endo=gen_endo;
setappdata(handles.loaddir,'masterset',masterset);
h=get(gca,'Children');
set(h, 'ButtonDownFcn', {@gcf_ButtonDownFcn});

% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDA
min= get(handles.slider1,'min');
max= get(handles.slider1,'max');
for s=min:max
    tic;pause(.02);toc;
    set(handles.slider1,'value',s);
    slider1_moveFnc(handles);
% hObject    handle to unwrapsingleboundary (see GCBO)
end
return;


% --- Executes on selection change in displaymenu.
function displaymenu_Callback(hObject, eventdata, handles)
% hObject    handle to displaymenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% % % str={'Magnitude';
% % % 'X-Phase';
% % % 'Y-Phase';
% % % 'Z-Phase';
% % % 'X-unwrapped';
% % % 'Y-unwrapped';
% % % 'Z-unwrapped'};
% % % set(hObject,'String',str);
% contents = cellstr(get(hObject,'String')) ;
% contents={get(hObject,'Value')} ;


% --- Executes during object creation, after setting all properties.
function displaymenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to displaymenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in zoompan.
function zoompan_Callback(hObject, eventdata, handles)
% hObject    handle to zoompan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: returns toggle state of zoompan
if get(handles.editboundary,'value')==1
    set(handles.zoompan,'string','Zoom... Pan','ForegroundColor',[0 0 0],'BackgroundColor',[.8 .8 .9]);
    set(handles.zoompan,'value',0);
end
if get(handles.zoompan,'value')==1
    set(handles.zoompan,'string','Zoom... Pan','ForegroundColor',[0 0 0],'BackgroundColor',[.5 .5 .5]);
else
    set(handles.zoompan,'string','Zoom... Pan','ForegroundColor',[0 0 0],'BackgroundColor',[.8 .8 .9]);
end
if get(hObject,'Value')
    h=handles.axes2;
    dragzoom(h);
else
    slider1_moveFnc(handles);
end


% --- Executes during object creation, after setting all properties.
function zoompan_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zoompan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'Value',0) ;


% --- Executes on button press in zoomout.
function zoomout_Callback(hObject, eventdata, handles)
% hObject    handle to zoomout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.zoompan,'Value',0) ;
setappdata(handles.zoompan,'reset',1);
slider1_moveFnc(handles);


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
% if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor',[.9 .9 .9]);
% end


% --- Executes on selection change in FrameRange.
function FrameRange_Callback(hObject, eventdata, handles)
% hObject    handle to FrameRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns FrameRange contents as cell array
%        contents{get(hObject,'Value')} returns selected item from FrameRange
x=get(hObject,'string');
curval=get(hObject,'value');
x=x(curval);
[t,rem]=strtok(reverse(x),'-');
t=reverse(t);
x=(str2num(t{1}));
set(handles.slider1,'Min',1,'Max',x);
set(handles.slider1,'Value',1);
set(handles.slider1, 'SliderStep', [1/(x), 1/(x)]);

% --- Executes during object creation, after setting all properties.
function FrameRange_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FrameRange (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in editboundary.
function editboundary_Callback(hObject, eventdata, handles)
% hObject    handle to editboundary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of editboundary
if get(handles.editboundary,'value')==1
    set(handles.editboundary,'string','Edit Walls','ForegroundColor',[0 0 0],'BackgroundColor',[.5 .5 .5]);
    set(handles.zoompan,'string','Zoom... Pan','ForegroundColor',[0 0 0],'BackgroundColor',[.8 .8 .9]);
    set(handles.zoompan,'value',0);
else
    set(handles.editboundary,'string','Edit Walls','ForegroundColor',[0 0 0],'BackgroundColor',[.8 .8 .9]);
end
slider1_moveFnc(handles);
    


% --- Executes on button press in show2d.
function show2d_Callback(hObject, eventdata, handles)
% hObject    handle to show2d (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if getappdata(handles.strain,'strainsdone')==0
    return;
end
p1_all=getappdata(handles.strain,'p1_all');
p1_num=getappdata(handles.strain,'p1_num');
num_splines=getappdata(handles.strain,'num_splines');
orig_segs=getappdata(handles.strain,'orig_segs');
seg_spl_epi=getappdata(handles.strain,'seg_spl_epi');
seg_spl_endo=getappdata(handles.strain,'seg_spl_endo');
d1=getappdata(handles.strain,'d1');
disps=getappdata(handles.strain,'disps');
etall_d=getappdata(handles.strain,'etall_d');
elem_grid_map=getappdata(handles.strain,'elem_grid_map');
pt_seg_id=getappdata(handles.strain,'pt_seg_id');
regdivs=getappdata(handles.strain,'regdivs');
long_elem_divs=getappdata(handles.strain,'long_elem_divs');
elem_fine_divs=getappdata(handles.strain,'elem_fine_divs');
etall_d=getappdata(handles.strain,'etall_d');
def=getappdata(handles.loaddir,'def');
RegionalStrain3D;
etall_d(:,1)=etr_d;
etall_d(:,2)=etc_d;
etall_d(:,3)=etl_d;
etall_d(:,4)=etcr_d;
etall_d(:,5)=etrl_d;
etall_d(:,6)=etcl_d;
etall_d(:,7)=rot_d;
etall_d(:,8)=tor_d;

par=get(handles.listboxmag,'value');
tensor=get(handles.tensor,'value');
Plot_Lagrange3D_18( p1_all,p1_num,num_splines,orig_segs,seg_spl_epi,seg_spl_endo,d1,disps,etall_d,tensor,2*par-1);

% --- Executes on button press in show3d.
function show3d_Callback(hObject, eventdata, handles)
% hObject    handle to show3d (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if getappdata(handles.strain,'strainsdone')==0
    return;
end
p1_all=getappdata(handles.strain,'p1_all');
p1_num=getappdata(handles.strain,'p1_num');
num_splines=getappdata(handles.strain,'num_splines');
orig_segs=getappdata(handles.strain,'orig_segs');
seg_spl_epi=getappdata(handles.strain,'seg_spl_epi');
seg_spl_endo=getappdata(handles.strain,'seg_spl_endo');
d1=getappdata(handles.strain,'d1');
disps=getappdata(handles.strain,'disps');
etall_d=getappdata(handles.strain,'etall_d');
elem_grid_map=getappdata(handles.strain,'elem_grid_map');
pt_seg_id=getappdata(handles.strain,'pt_seg_id');
regdivs=getappdata(handles.strain,'regdivs');
long_elem_divs=getappdata(handles.strain,'long_elem_divs');
elem_fine_divs=getappdata(handles.strain,'elem_fine_divs');

etall_d=getappdata(handles.strain,'etall_d');
def=getappdata(handles.loaddir,'def');
RegionalStrain3D;
etall_d(:,1)=etr_d;
etall_d(:,2)=etc_d;
etall_d(:,3)=etl_d;
etall_d(:,4)=etcr_d;
etall_d(:,5)=etrl_d;
etall_d(:,6)=etcl_d;
etall_d(:,7)=rot_d;
etall_d(:,8)=tor_d;

tensor=get(handles.tensor,'value');
Plot_Lagrange3D_18( p1_all,p1_num,num_splines,orig_segs,seg_spl_epi,seg_spl_endo,d1,disps,etall_d,tensor,-100);

% --- Executes on button press in strainsummary.
function strainsummary_Callback(hObject, eventdata, handles)
% hObject    handle to strainsummary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if getappdata(handles.strain,'strainsdone')==0
    return;
end
p1_all=getappdata(handles.strain,'p1_all');
p1_num=getappdata(handles.strain,'p1_num');
num_splines=getappdata(handles.strain,'num_splines');
orig_segs=getappdata(handles.strain,'orig_segs');
seg_spl_epi=getappdata(handles.strain,'seg_spl_epi');
seg_spl_endo=getappdata(handles.strain,'seg_spl_endo');
d1=getappdata(handles.strain,'d1');
disps=getappdata(handles.strain,'disps');
etall_d=getappdata(handles.strain,'etall_d');
elem_grid_map=getappdata(handles.strain,'elem_grid_map');
pt_seg_id=getappdata(handles.strain,'pt_seg_id');
regdivs=getappdata(handles.strain,'regdivs');
long_elem_divs=getappdata(handles.strain,'long_elem_divs');
elem_fine_divs=getappdata(handles.strain,'elem_fine_divs');
etr_d=etall_d(:,1);
etc_d=etall_d(:,2);
etl_d=etall_d(:,3);
etcr_d=etall_d(:,4);
etrl_d=etall_d(:,5);
etcl_d=etall_d(:,6);
rot_d=etall_d(:,7);
tor_d=etall_d(:,8);
Regional_plot=1;
def=getappdata(handles.loaddir,'def');

RegionalStrain3D;

% par=get(handles.listboxmag,'value')-1;
% Plot_Lagrange3D_18( p1_all,p1_num,num_splines,orig_segs,seg_spl_epi,seg_spl_endo,d1,disps,etall_d,-1);

% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in singleboundary.
function singleboundary_Callback(hObject, eventdata, handles)
% hObject    handle to singleboundary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% % % % % [filename, pathname] = uigetfile('*.mat', 'Pick a ROI file');
% % % % %     if isequal(filename,0) || isequal(pathname,0)
% % % % %         return;
% % % % %     else
% % % % %         ffile = fullfile(pathname,filename);
% % % % %         
% % % % %         rect=load(ffile);
% % % % %         setappdata(handles.boundaries, 'rect', struct2array(rect.rect));
% % % % %     end

p_str=get(handles.listboxmag,'string');
p_val=get(handles.listboxmag,'value');
p_str=p_str(p_val);
addpath(genpath(get(handles.filedir,'string')));
files=dir(strcat(get(handles.filedir,'string'),p_str{1},'\'));
dcm=dicomread(files(5).name);

rect=getappdata(handles.boundaries,'rect');
flipped=getappdata(handles.boundaries,'flipped');

% rect=load ('ROBERTSON_EMILY_48932-short_rect.mat');
filedir=get(handles.filedir,'string');
masterset=getappdata(handles.loaddir,'masterset');
p_str2=cell(1,1);
numvec=[];
k=1;
for p=1:size(p_str,1)
    num=find(ismember({masterset(1:size(masterset,2)).mag_names},p_str{p})==1);
%     if isempty(masterset(num).epi_d)
        p_str2{k,1}=p_str{p};
        numvec=[numvec;num];
        k=k+1;
%     end
end
if isempty(p_str2{1,1})
else
    brightness=1.0-0.5*get(handles.slider2,'value');
    [endo_d, epi_d] = GenVolumeWUnwrap3(filedir,p_str2,rect,brightness,flipped);
    save('Init_BNDRYS','endo_d', 'epi_d');
    k=1;
    numvec=numvec';
    for n=numvec
        masterset(n).epi_d=epi_d(k);
        masterset(n).endo_d=endo_d(k);
        masterset(n).gen_epi{6}=[epi_d(k).xi,epi_d(k).yi]';
         masterset(n).gen_endo{6}=[endo_d(k).xi,endo_d(k).yi]';
%         masterset(n).epi_s=epi_s(k);
%         masterset(n).endo_s=endo_s(k);
        k=k+1;
    end
    setappdata(handles.loaddir,'masterset',masterset);
end

setappdata(handles.strain,'boundaries2d',1);
setappdata(handles.strain,'unwrapped',0);
setappdata(handles.strain,'strainsdone',0);
setappdata(handles.strain,'dispdone',0);
set(handles.changeinitwalls,'value',1);
changeinitwalls_Callback(hObject, eventdata, handles);

% --- Executes on button press in changeinitwalls.
function changeinitwalls_Callback(hObject, eventdata, handles)
% hObject    handle to changeinitwalls (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if get(handles.changeinitwalls,'value')==1
    set(handles.changeinitwalls,'string','Change Init Walls','ForegroundColor',[0 0 0],'BackgroundColor',[.5 .5 .5]);
%      set(handles.changeinitwalls,'value',1);
else
    set(handles.changeinitwalls,'string','Change Init Walls','ForegroundColor',[0 0 0],'BackgroundColor',[.8 .8 .9]);
%      set(handles.changeinitwalls,'value',0);r
end

% --- Executes on button press in disp2d.
function disp2d_Callback(hObject, eventdata, handles)
% hObject    handle to disp2d (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of disp2d
if get(handles.disp2d,'value')==1
    set(handles.disp2d,'string','2D Displacements','ForegroundColor',[0 0 0],'BackgroundColor',[.5 .5 .5]);
else
    set(handles.disp2d,'string','2D Displacements','ForegroundColor',[0 0 0],'BackgroundColor',[.8 .8 .9]);
end

% --- Executes on button press in initwalls.
function initwalls_Callback(hObject, eventdata, handles)
% hObject    handle to initwalls (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of initwalls
if get(handles.initwalls,'value')==1
    set(handles.initwalls,'string','Init Walls','ForegroundColor',[0 0 0],'BackgroundColor',[.5 .5 .5]);
else
    set(handles.initwalls,'string','Init Walls','ForegroundColor',[0 0 0],'BackgroundColor',[.8 .8 .9]);
end


% --- Executes on selection change in instance.
function instance_Callback(hObject, eventdata, handles)
% hObject    handle to instance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns instance contents as cell array
%        contents{get(hObject,'Value')} returns selected item from instance


% --- Executes during object creation, after setting all properties.
function instance_CreateFcn(hObject, eventdata, handles)
% hObject    handle to instance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadmasterset.
function loadmasterset_Callback(hObject, eventdata, handles)
% hObject    handle to loadmasterset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile('*.mat', 'Pick masterset file');
masterset0=getappdata(handles.loaddir,'masterset');

mastersz=size(masterset0,2);
setappdata(handles.boundaries,'masterset_unwrapped',cell(mastersz,1));
masterset_unwrapped=cell(mastersz,1);
    if isequal(filename,0) || isequal(pathname,0)
        return;
    else
        ffile = fullfile(pathname,filename);
        masterset=load(ffile);
        for m=1:size(masterset.masterset,2)
            nonempty_all=ismember({masterset0.mag_names},{masterset.masterset(m).mag_names});
           
            masterset0(1,find(nonempty_all>0))=masterset.masterset(m);
            masterset_unwrapped{find(nonempty_all>0),1}=masterset.masterset(m).unwrapped;
            gen_disp=masterset.masterset(m).gen_disp;
        end
        setappdata(handles.loaddir,'masterset',masterset0);
         setappdata(handles.loaddir,'axis_pts',masterset.axis_pts);
        setappdata(handles.boundaries,'rect',masterset.rect);
        setappdata(handles.listboxphase,'mystring',masterset.mystring);
         end
setappdata(handles.boundaries,'masterset_unwrapped',masterset_unwrapped);

% p_val=get(handles.listbox1,'value');
p_str=get(handles.listbox1,'string');
% masterset=getappdata(handles.loaddir,'masterset');
nonempty_all=ismember(p_str, {masterset.masterset.mag_names}');
load allist;
newstr=p_str(find(nonempty_all>0));
xdirsc=cell(size(newstr));
ydirsc=cell(size(newstr));
zdirsc=cell(size(newstr));

id=[];
for i=1:size(newstr,1)
    IndexC = strfind(allist, newstr{i});
    id = [id;find(not(cellfun('isempty', IndexC)))];
    
end
[id,id2]=sort(id,1);

xdirsc=allist(id,2);
ydirsc=allist(id,3);
zdirsc=allist(id,4);

mystring=cell(size(p_str(find(nonempty_all>0)),1),3);
%p_val=transpose(p_val);
for i=1:size(p_str(find(nonempty_all>0)))
    mystring{i,1}=xdirsc{i,1};
    mystring{i,2}=ydirsc{i,1};
    mystring{i,3}=zdirsc{i,1};
end
mystring2=reshape(mystring,size(mystring,1)*size(mystring,2),1);
set(handles.listboxphase,'string',mystring2);
setappdata(handles.listboxphase,'mystring',mystring);
save('mystring.mat','mystring');
set(handles.listboxmag,'string',p_str(find(nonempty_all>0)));
rect=masterset.rect;
setappdata(handles.boundaries,'masterset_cropped',cell(mastersz,1));
masterset_cropped=cell(mastersz,1);
filedir=get(handles.filedir,'string');
id0=find(~cellfun(@isempty,masterset_unwrapped));
START_FRAME=3;
END_FRAME=3;
if size(id0,1) > 0
    id1=find(~cellfun(@isempty,masterset_unwrapped{id0(1),1}));
    tot_frms=size(id1,1)/3;
   END_FRAME=tot_frms+2;
end
for nonempty=[find(nonempty_all>0)]'

    files=dir(strcat(get(handles.filedir,'string'),masterset0(nonempty).mag_names,'\'));
    phasex_f=dir(strcat(filedir,'\',masterset0(nonempty).ph_names{1}));
    phasey_f=dir(strcat(filedir,'\',masterset0(nonempty).ph_names{2}));
    phasez_f=dir(strcat(filedir,'\',masterset0(nonempty).ph_names{3}));

    par=[];
    par=masterset0(nonempty).mag_names;
    p=findstr(par,'PAR');
    par=par(p:p+4);
    p=findstr(par,'_');
    if p>0
        par=par(1:p-1);
    end
    stat= sprintf('Phase and magnitude cropped for partition %s ...',par);
        set(handles.edit2,'string',stat);drawnow;
    master_cropped=cell(END_FRAME,4);

        for bi=START_FRAME:END_FRAME
            dcm=dicomread(files(bi).name);
            im_m=imcrop(dcm,rect);
            master_cropped{bi,4}=im_m;

            dcm=dicomread(phasex_f(bi).name);
            im_p=imcrop(dcm,rect);
            im_p1=im_p;
            master_cropped{bi,1}=im_p1;
        end
        for bi=START_FRAME:END_FRAME
            dcm=dicomread(phasey_f(bi).name);
            im_p=imcrop(dcm,rect);
            im_p2=im_p;
            master_cropped{bi,2}=im_p2;
        end
        for bi=START_FRAME:END_FRAME
            dcm=dicomread(phasez_f(bi).name);
            im_p=imcrop(dcm,rect);
            im_p3=im_p;
            master_cropped{bi,3}=im_p3;
        end
        masterset_cropped{nonempty,1}=master_cropped;
        end

setappdata(handles.boundaries,'masterset_cropped',masterset_cropped);
% % setappdata(handles.boundaries,'masterset_cropped',cell(mastersz,1));
% for n =[find(nonempty_all>0)]'
%     masterset_unwrapped{n}=masterset.masterset(n).unwrapped;
% end

id0=find(~cellfun(@isempty,gen_disp));
fr=strcat(num2str(1),'-',num2str(size(id0,1)));
% set(handles.FrameRange,'string',fr);
x=size(id0,1);
set(handles.FrameRange,'value',x-3);
set(handles.slider1,'Min',1,'Max',x);
set(handles.slider1,'Value',1);
set(handles.slider1, 'SliderStep', [1/(x), 1/(x)]);


% --- Executes on selection change in tensor.
function tensor_Callback(hObject, eventdata, handles)
% hObject    handle to tensor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns tensor contents as cell array
%        contents{get(hObject,'Value')} returns selected item from tensor


% --- Executes during object creation, after setting all properties.
function tensor_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tensor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in savemaster.
function savemaster_Callback(hObject, eventdata, handles)
% hObject    handle to savemaster (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% hObject    handle to strain (see GCBO)
% eventdata  reserved - to be defined in a future version of MAT,LAB
% handles    structure with handles and user data (see GUIDATA)
if getappdata(handles.strain,'dispdone')==0
%     return;
end
p_str=get(handles.listboxmag,'string');
addpath(genpath(get(handles.filedir,'string')));
axis_pt_z=size(p_str,1);
files=dir(strcat(get(handles.filedir,'string'),p_str{1},'\'));


filedir=get(handles.filedir,'string');
mystring=getappdata(handles.listboxphase,'mystring');
imPhase=cell(size(p_str,1),3);
imMag=cell(size(p_str,1),1);
unwrapped=cell(size(p_str,1),3);
k=1;

rect=getappdata(handles.boundaries,'rect');
flipped=getappdata(handles.boundaries,'flipped');

masterset=getappdata(handles.loaddir,'masterset');


nonempty={masterset(1:size(masterset,2)).epi_d};
epi_d=([masterset(find(~cellfun(@isempty,nonempty))).epi_d]);
endo_d=([masterset(find(~cellfun(@isempty,nonempty))).endo_d]);
srch=get(handles.listboxmag,'string');
procset=[];
for m=1:size(masterset,2)
    for s=1:size(srch,1)
        if (strfind(string(masterset(1,m).mag_names),string(srch(s))))
%             if ~isempty(masterset(1,m).gen_epi) && ~isempty(masterset(1,m).gen_endo)...
%                     && ~isempty(masterset(1,m).gen_disp) && ~isempty(masterset(1,m).unwrapped)
                procset=[procset;m];
%             end
        end
     end
end
epi_d=[masterset(procset).epi_d];
endo_d=[masterset(procset).endo_d];
pm=[];
for i=1:size(p_str,1)
    if isempty(masterset(procset(i)).epi_d)
        pm2=[0 0 0 0];
    else
        pm2=polygeom(masterset(procset(i)).epi_d.xi,masterset(procset(i)).epi_d.yi);
    end
    pm=[pm;pm2(4)];
    
end
[pmax pmid]=max(pm);
files=dir(strcat(get(handles.filedir,'string'),p_str{pmid},'\'));
if flipped ==1
    dcm=flipud(dicomread(files(6).name));
else
    dcm=dicomread(files(6).name);
end
axis_pts=getappdata(handles.loaddir,'axis_pts');


masterset=getappdata(handles.loaddir,'masterset');
nonempty={masterset(1:size(masterset,2)).epi_d};
nonempty=find(~cellfun(@isempty,nonempty));

[x,y]=meshgrid(1:uint16(rect(3)),1:uint16(rect(4)));


savefile = strsplit(get(handles.filedir,'string'),'\');
idC=strfind(savefile,'_0');
ind = find(not(cellfun('isempty', idC)));
if isempty(ind)
    savefile=get(handles.savefile,'string');
else
    savefile=strcat(savefile{ind},'.mat');
end

nonempty={masterset(1:size(masterset,2)).epi_d};
nonempty={masterset(1:size(masterset,2)).endo_d};


imMag=({masterset(find(~cellfun(@isempty,nonempty))).mag});
imMag=imMag';
imPhase=({masterset(find(~cellfun(@isempty,nonempty))).phases});
imPhase=imPhase';
temp=cell(size(imPhase,1),3);
for t=1:size(imPhase,1)
    temp{t,1}=imPhase{t}{1};
    temp{t,2}=imPhase{t}{2};
    temp{t,3}=imPhase{t}{3};
end
imPhase=temp;
mystring=({masterset(find(~cellfun(@isempty,nonempty))).ph_names});
mystring=mystring';
temp=cell(size(mystring,1),3);
for t=1:size(mystring,1)
    temp{t,1}=mystring{t}{1};
    temp{t,2}=mystring{t}{2};
    temp{t,3}=mystring{t}{3};
end
mystring=temp;
unwrapped=({masterset(find(~cellfun(@isempty,nonempty))).unwrapped})';
gen_epi=([masterset(find(~cellfun(@isempty,nonempty))).gen_epi])';
gen_endo=([masterset(find(~cellfun(@isempty,nonempty))).gen_endo])';
gen_disp=([masterset(find(~cellfun(@isempty,nonempty))).gen_disp])';
masterset=masterset(find(~cellfun(@isempty,nonempty)));
savefile=uiputfile('*.mat','Save as'); 
save(savefile, 'masterset','x','y','endo_d','epi_d','imMag','imPhase','filedir', 'mystring','rect','axis_pts');

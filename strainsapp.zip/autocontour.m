for i =1:size(mystring,1)
%     un_inx=imUnwrapped{i,1};
%     un_iny=imUnwrapped{i,2};
    epi_x=epi{i}.xi;
    epi_y=epi{i}.yi;
    endo_x=endo{i}.xi;
    endo_y=endo{i}.yi;
    epi_sx=epi_s2(i).xi;
    epi_sy=epi_s2(i).yi;
    endo_sx=endo_s2(i).xi;
    endo_sy=endo_s2(i).yi;
%     z=epi{i}.zi(1);
%     z_in=z*ones(size(x));
%     posz=z_in;%(z_in+abs(imUnwrapped{i,3}));
%     in=inpolygon(x_in,y_in,...
%     epi_x,epi_y);
%     in2=inpolygon(x_in,y_in,...
%     endo_x,endo_y);
%     in=in-in2;def_epi=zeros(size(epi_x,1),2);
%     def_epi=zeros(size(epi_x,1),2);
%     def_endo=zeros(size(endo_x,1),2);
%     posx=x_in(in==1);
%     posy=y_in(in==1);
%     defx=un_inx(in==1);
%     defy=un_iny(in==1);
%     for s=1:size(epi_x,1)
%         [val, id]=sort(((epi_x(s)-posx).^2+(epi_y(s)-posy).^2).^.5);
%         def_epi(s,1)=epi_x(s)+defx(id(1));
%         def_epi(s,2)=epi_y(s)+defy(id(1));
%     end
%     for s=1:size(endo_x,1)
%         [val, id]=sort(((endo_x(s)-posx).^2+(endo_y(s)-posy).^2).^.5);
%         def_endo(s,1)=endo_x(s)+defx(id(1));
%         def_endo(s,2)=endo_y(s)+defy(id(1));
%     end
    figure; hold
    plot(epi_x,epi_y,'r*-');
%     plot(def_epi(:,1),def_epi(:,2),'m*-');
    plot(epi_sx,epi_sy,'b*-');
    figure; hold
    plot(endo_x,endo_y,'r*-');
%     plot(def_endo(:,1),def_endo(:,2),'m*-');
    plot(endo_sx,endo_sy,'b*-');
end
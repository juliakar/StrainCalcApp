close all;
addpath(genpath('C:\Images\Images for Julia\'));
out_dir = 'C:\Images\Images for Julia\';
dcms=cell(8,1);
dcms{1,1} = dicomread('100515_001.MR.CCIR00500_CCIR-00534_PASQUE.0054.0006.2015.10.05.13.28.01.859375.26154613.IMA');
dcms{1,1} = imcrop(dcms{1,1}, [50,40,50,50])
figure;imagesc(dcms{1,1}), colormap gray
print (strcat(out_dir,'fig1.jpg'), '-djpeg');
dcms{2,1} = dicomread('100515_001.MR.CCIR00500_CCIR-00534_PASQUE.0055.0006.2015.10.05.13.28.01.859375.26155029.IMA');
dcms{2,1} = imcrop(dcms{2,1}, [50,40,50,50])
figure;imagesc(dcms{2,1}), colormap gray
print (strcat(out_dir,'fig2.jpg'), '-djpeg');
dcms{3,1} = dicomread('100515_001.MR.CCIR00500_CCIR-00534_PASQUE.0056.0006.2015.10.05.13.28.01.859375.26155462.IMA');
dcms{3,1} = imcrop(dcms{3,1}, [50,40,50,50])
figure;imagesc(dcms{3,1}), colormap gray
print (strcat(out_dir,'fig3.jpg'), '-djpeg');
dcms{4,1} = dicomread('100515_001.MR.CCIR00500_CCIR-00534_PASQUE.0057.0006.2015.10.05.13.28.01.859375.26155895.IMA');
dcms{4,1} = imcrop(dcms{4,1}, [50,40,50,50])
figure;imagesc(dcms{4,1}), colormap gray
print (strcat(out_dir,'fig4.jpg'), '-djpeg');

dcms{5,1} = dicomread('090215_001.MR.CCIR00500_CCIR-00534_PASQUE.0081.0006.2015.09.02.17.02.37.468750.20314077.IMA');
dcms{5,1} = imcrop(dcms{5,1}, [50,40,50,50])
figure;imagesc(dcms{5,1}), colormap gray
print (strcat(out_dir,'fig5.jpg'), '-djpeg');

dcms{6,1} = dicomread('090215_001.MR.CCIR00500_CCIR-00534_PASQUE.0082.0006.2015.09.02.17.02.37.468750.20314493.IMA');
dcms{6,1} = imcrop(dcms{6,1}, [50,40,50,50])
figure;imagesc(dcms{6,1}), colormap gray
print (strcat(out_dir,'fig6.jpg'), '-djpeg');

dcms{7,1} = dicomread('090215_001.MR.CCIR00500_CCIR-00534_PASQUE.0083.0006.2015.09.02.17.02.37.468750.20314926.IMA');
dcms{7,1} = imcrop(dcms{7,1}, [50,40,50,50])
figure;imagesc(dcms{7,1}), colormap gray
print (strcat(out_dir,'fig7.jpg'), '-djpeg');

dcms{8,1} = dicomread('090215_001.MR.CCIR00500_CCIR-00534_PASQUE.0084.0006.2015.09.02.17.02.37.468750.20315359.IMA');
dcms{8,1} = imcrop(dcms{8,1}, [50,40,50,50])
figure;imagesc(dcms{8,1}), colormap gray
print (strcat(out_dir,'fig8.jpg'), '-djpeg');

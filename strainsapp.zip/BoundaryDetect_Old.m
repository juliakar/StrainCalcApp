EARLIER =0;
LATER = 1;
if EARLIER
    LATER=0;
end
PAPPILARIES = 1;
dcm = [];
%earlier image
if EARLIER
    dcm = dicomread('031213-001.MR.CCIR00500_CCIR-00534_PASQUE.0033.0004.2013.03.12.10.14.38.46875.94901388.IMA');
end
%later image
if LATER
    dcm = dicomread('031213-001.MR.CCIR00500_CCIR-00534_PASQUE.0033.0008.2013.03.12.10.14.38.46875.94901548.IMA');
end
%dcm = dicomread('090314-001.MR.CCIR-00600_CCIR-0679_PASQUE.0067.0004.2014.09.03.12.45.59.328125.2629379.IMA');
thresh0=0.2*max(max(dcm)); % old code
max_dcm = max(max(dcm));

if EARLIER
    figure;imagesc(dcm)
    [dcm rect] = imcrop;
    close
end

if LATER
    dcm= imcrop(dcm, rect);
    %figure;imagesc(dcm);hold
end
if EARLIER
    t1=0.3*max(max(dcm));
       t2=0.8*max(max(dcm));
    figure;imagesc(dcm);hold
    h = imellipse;
    bndry_epi = wait(h);
    h = imellipse;
    bndry_endo = wait(h);
    close
end
% bndry_epi = int16(bndry_epi);
% bndry_endo = int16(bndry_endo);
% t1=0.3*max(max(dcm));
% t2=0.8*max(max(dcm));
thresh_lo = dcm <t1;
dcm(thresh_lo) = 0;
thresh_hi = dcm >t2;
dcm(thresh_hi) = 0;


[d1 d2] = size(dcm);
if EARLIER
    for i=1:d1
        for j=1:d2
            IN = inpolygon(j,i,double(bndry_epi(:,1)), double(bndry_epi(:,2)))...
                -inpolygon(j,i,double(bndry_endo(:,1)), double(bndry_endo(:,2)));
            if IN(1,1) <= 0
                dcm(i,j) = 0;%int16(1);

            end
        end
    end
end
  
if LATER
    for i=1:d1
        for j=1:d2
            IN = inpolygon(j,i,double(bndry_epi(:,1)), double(bndry_epi(:,2)));
            if IN(1,1) <= 0
                dcm(i,j) = 0;%int16(1);

            end
        end
    end
end
figure;imagesc(dcm);hold
plot(bndry_epi(:,1), bndry_epi(:,2), 'w-*');
plot(bndry_endo(:,1), bndry_endo(:,2), 'w-*');

cent_epi=[mean(bndry_epi(:,1)),mean(bndry_epi(:,2))];
cent_endo=[mean(bndry_endo(:,1)),mean(bndry_endo(:,2))];
bndry_epi_new=zeros(size(bndry_epi));
bndry_endo_new=zeros(size(bndry_endo));
get_epi=zeros(size(bndry_epi,1));

if LATER
    bndry_epi_new=zeros(size(bndry_epi));
    bndry_endo_new=zeros(size(bndry_endo));
    get_epi=zeros(size(bndry_epi,1));
    get_endo=zeros(size(bndry_endo,1));
    for i=1:size(bndry_epi,1)
        [xx yy]=fillline(double(bndry_epi(i,:)),double(cent_epi(1,:)),20);
        %plot(xx,yy,'-p*');
        xx=int16(xx);yy=int16(yy);
        bndry_epi_new(i,:)=bndry_epi(i,:);
        for j=1:20
            if dcm(yy(j),xx(j)) >= t1
                if get_epi(i) ==0
                    bndry_epi_new(i,:)=[xx(j),yy(j)];
                    get_epi(i) =1;
                end
            end
        end
    end

    for i=1:size(bndry_endo,1)
        [xx yy]=fillline(double(bndry_endo(i,:)),double(cent_endo(1,:)),20);
        %plot(xx,yy,'-k*');
        xx=int16(xx);yy=int16(yy);
        bndry_endo_new(i,:)=bndry_endo(i,:);
        for j=1:20
            if dcm(yy(j),xx(j)) == 0
                get_endo(i)=1;
            end
            if dcm(yy(j),xx(j)) >t1
                if get_endo(i) ==0
                    bndry_endo_new(i,:)=[xx(j),yy(j)];
                end
            end
        end
    end
    
    %papilaries
    if PAPPILARIES
    get_endo=zeros(size(bndry_endo,1));
        endo_cent_dist =  sqrt((bndry_endo_new(:,1)-cent_endo(1,1)).^2+(bndry_endo_new(:,2)-cent_endo(1,2)).^2);
        median_endo_cent_dist=0.87*median(endo_cent_dist);
        for i=1:size(bndry_endo,1)
            [xx yy]=fillline(double(bndry_endo(i,:)),double(cent_endo(1,:)),20);
            xx=int16(xx);yy=int16(yy);
            bndry_endo_new(i,:)=bndry_endo(i,:);
            for j=1:20
                if dcm(yy(j),xx(j)) == 0
                    get_endo(i)=1;
                end
                if dcm(yy(j),xx(j)) >t1
                    if get_endo(i) ==0
                        if sqrt((double(xx(j))-cent_endo(1,1)).^2+double((yy(j))-cent_endo(1,2)).^2) > median_endo_cent_dist
                            bndry_endo_new(i,:)=[xx(j),yy(j)];
                        end
                    end
                end
            end
        end
    end
    plot(bndry_epi_new(:,1), bndry_epi_new(:,2), 'k-*');
    plot(bndry_endo_new(:,1), bndry_endo_new(:,2), 'k-*');
end
ELLIPSE=0;
if ELLIPSE
%     figure;imagesc(dcm);hold
    % h = imline(gca,[]);
    h = imellipse;
    bndry_epi = wait(h);
    h = imellipse;
    bndry_endo = wait(h);
    % cent = int16(pos(1,:));%[25,18];
    %close
end

%dcm=dcm(50:80,50:80);
%cent = [25,18];
 
% rad =  [8.5, 5];
% rad(1) = 0.8*sqrt((pos(1,1)-pos(2,1)).^2+(pos(1,2)-pos(2,2)).^2);
% rad(2) = 0.6*rad(1);
%dcm(cent(2),cent(1)) = 3*max_dcm;
CONVOL=0;
if CONVOL
    maskX = [-1 0 1 ; -2 0 2; -1 0 1];
    maskY = [-1 -2 -1 ; 0 0 0 ; 1 2 1] ;
    resX = conv2(double(dcm), double(maskX));resY = conv2(double(dcm),double( maskY));
    mag = sqrt(resX.^2 + resY.^2);
    thresh = mag <thresh0;
    mag(thresh) = 0;


    [id1 id2 ] = find(mag<10);
    plot(id2,id1, 'k*');

    ids=[id2 id1];
    pol = zeros (360,2);
end
% figure;imagesc(mag);%hold;

% for a=1:7:360
% %     pol = zeros (360,2);
%     for i=1:5
%         r1=[int16((rad(1)+i*sqrt(.5))*cosd(a) + cent(1)),int16((rad(1)+i*sqrt(.5))*sind(a) + cent(2))];
%         ii=i+1;
%         r2=[int16((rad(1)+i*sqrt(.5))*cosd(a) + cent(1)),int16((rad(1)+i*sqrt(.5))*sind(a) + cent(2))];
%         if min(r2) > 0 %&& min(pol(a,:)) > 0
%             if r2(2) < size(mag,1) && r2(1) < size(mag,2) 
%                 if mag(r2(2), r2(1)) > 0 %mag(pol(a,2),pol(a,1))
%                     pol(a,:) = r2;
%                 else
%                  %pol(a,:) = [0,0];
%                 end
%             end
%         end
%     end
% 
% end
% 
% pol=int16(pol);
% 
% polf=pol;
% [b1 b2]= find(polf==0);
% polf(b1,:)=[];
% polf=unique(polf(:,:),'rows','stable');
% plot(polf(:,1), polf(:,2),'k.')
% 
% 
% pol = zeros (360,2);
% for a=1:7:360
% %     pol = zeros (360,2);
%     for i=1:5
%         r1=[int16((rad(2)+i*sqrt(.5))*cosd(a) + cent(1)),int16((rad(2)+i*sqrt(.5))*sind(a) + cent(2))];
%         ii=i+1;
%         r2=[int16((rad(2)+i*sqrt(.5))*cosd(a) + cent(1)),int16((rad(2)+i*sqrt(.5))*sind(a) + cent(2))];
%         if min(r2) > 0 %&& min(pol(a,:)) > 0
%             if r2(2) < size(mag,1) && r2(1) < size(mag,2) 
%                 if mag(r2(2), r2(1)) > thresh0%mag(pol(a,2),pol(a,1))
%                     pol(a,:) = r2;
%                 else
%                  %pol(a,:) = [0,0];
%                 end
%             end
%         end
%     end
% 
% end
% pol = int16(pol);
% polf2=pol;
% [b1 b2]= find(polf2==0);
% polf2(b1,:)=[];
% polf2=unique(polf2(:,:),'rows','stable');
% plot(polf2(:,1), polf2(:,2),'r.')




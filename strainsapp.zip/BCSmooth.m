masterset=getappdata(handles.loaddir,'masterset');
    gen_epi=masterset(nonempty).gen_epi;
    gen_endo=masterset(nonempty).gen_endo;
    unwrap_fit_x=[];
    unwrap_fit_y=[];
    for bi=START_FRAME:END_FRAME
        im_ux=gen_endo{bi,1}(1,:);%+unwrapped{START_FRAME,1};
        im_uy=gen_endo{bi,1}(2,:);%+unwrapped{START_FRAME,2};
        ;
        unwrap_fit_x=[unwrap_fit_x,im_ux'];%-mean(im_ux)];
        unwrap_fit_y=[unwrap_fit_y,im_uy'];%-mean(im_uy)];
    end
    
    unwrap_fit_x2=unwrap_fit_x;
    unwrap_fit_y2=unwrap_fit_y;
    fsz2=size(unwrap_fit_x,2);

    for fi=1:size(unwrap_fit_x,1)
        f=fit([1:fsz2]',unwrap_fit_x(fi,:)','poly2');
        res=feval(f,[1:fsz2]');
        unwrap_fit_x(fi,:)=res';
        % %         f=fit(15*([1:fsz2]'),unwrap_fit_y(fi,:)','fourier2');
        f=fit([1:fsz2]',unwrap_fit_y(fi,:)','poly2');
        res=feval(f,[1:fsz2]');
        unwrap_fit_y(fi,:)=res';
    end
    
    ki=1;
    for bi=START_FRAME:END_FRAME
%         im_ux=unwrapped{bi,1};
%         im_uy=unwrapped{bi,2};
        im_ux=unwrap_fit_x(:,ki);
        im_uy=unwrap_fit_y(:,ki);
        gen_endo{bi,1}=[im_ux';im_uy'];%-1*mean(im_ux(in==1));
%         gen_endo{bi,1}=im_uy;-1*mean(im_uy(in==1));
        ki=ki+1;
    end 
addpath(genpath('geom2d'));
close all;
h=open('Figs/initfit_base_auto_manual.fig');
graphics=h.Children(1).Children;
topdir='C:\ImagesUSA\KOICHI_ALEX_VOLUNTEER\all_images\';
addpath(genpath(topdir));
curdir='SP_CINE_DENSE_3DNAV_S4PT_3PPHACYC_AVEMAG_PAR10_0052';
my_files=dir(strcat(topdir,curdir,'\'));
rect=[45 45 55 55];
rect_disp=[40 50 50 50];
rect_diff=rect-rect_disp;
bi=6;
I_d=imcrop(dicomread(my_files(bi).name),rect_disp);
I_d=imfilter(I_d,[5 5]);
[N, edges]=histcounts(I_d,10);
I_d(I_d<=edges(3))=edges(3);
I_d(I_d<=edges(4))=edges(3);
%  I_d=locallapfilt(I_d, .9,.75);
% I_d(find(I_d>max(max(I_d(20:45,20:45)))))=uint16(.75*I_d(find(I_d>max(max(I_d(20:45,20:45))))));
% I_d(find(I_d>max(max(I_d(20:45,20:45)))))=(max(max(I_d(20:45,20:45))));
I_d2=I_d;
% I_d(find(I_d>max(max(I_d(20:45,20:45)))))=uint16(.7*I_d(find(I_d>max(max(I_d(20:45,20:45))))));
% 
 thresh_d = multithresh(I_d2,6);
valuesMax_d = [ thresh_d max(I_d(:)) ];

[qI_d, index] = imquantize(I_d2, thresh_d, valuesMax_d);
qI_d(21,34)=qI_d(21,36);
qI_d(21,35)=qI_d(21,36);
qI_d(22,34)=qI_d(22,36);
qI_d(22,35)=qI_d(22,36);
qI_d(25,31)=qI_d(25,33);
qI_d(25,32)=qI_d(25,33);
qI_d(18,21)=qI_d(18,20);
mqI_d=min(unique(qI_d));
uqI_d=(unique(qI_d));
% for s=1:size(unique(qI_d))
qI_d(find(qI_d==uqI_d(6)))=uqI_d(5);
qI_d(find(qI_d==uqI_d(7)))=uqI_d(6);

% end
figure;
subplot(1,2,1);
% qI_d(find(qI_d>max(max(qI_d(20:45,20:35)))))=(max(max(qI_d(20:45,20:35))));
I_d2=imadjust(I_d2, [0 .625], [0 1]);
imagesc(I_d2),colormap gray; axis tight
title('Uncompressed Image');
xlabel('pixels');
ylabel('pixels');
set(gca,'FontSize',10,'FontWeight','bold');
hold;
imcontrast
subplot(1,2,2);
% qI_d=imadjust(qI_d,[0 .825], [0 1] );
imagesc(qI_d),colormap gray; axis tight
title('Quantized Image');
xlabel('pixels');
ylabel('pixels');
set(gca,'FontSize',10,'FontWeight','bold');
imcontrast
figure;

% qI_d=imadjust(qI_d, [0 .625], [0 1]);
imagesc(qI_d),colormap gray; axis tight
hold;
title('Boundary Detection with Quantization');
xlabel('pixels');
ylabel('pixels');
set(gca,'FontSize',10,'FontWeight','bold');
plot(graphics(1).XData+rect_diff(1),graphics(1).YData+rect_diff(2),'g*');
cx=graphics(1).XData'+rect_diff(1);
cy=graphics(1).YData'+rect_diff(2);
deci=size(cx,1)/12;
xyz=[decimate(cx,floor(deci),9),decimate(cy,floor(deci),9)]';
    sz=size(xyz,2);
    cvec=zeros(1,sz+1);
    [pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
    s = unique([linspace(0,pp.breaks(end),100),sparam]);
    pts = fnval(pp,s);
    plot(pts(1,:),pts(2,:),'g.-');
% plot(graphics(3).XData+rect_diff(1),graphics(3).YData+rect_diff(2),'g.-');
plot(graphics(2).XData+rect_diff(1),graphics(2).YData+rect_diff(2),'r*');
cx=graphics(2).XData'+rect_diff(1);
cy=graphics(2).YData'+rect_diff(2);
xyz=[decimate(cx,floor(deci),9),decimate(cy,floor(deci),9)]';

    sz=size(xyz,2);
    cvec=zeros(1,sz+1);
    [pp sparam]=cscvn2(xyz(:,[1:end 1]),'periodic',cvec);
    s = unique([linspace(0,pp.breaks(end),100),sparam]);
    pts = fnval(pp,s);
    plot(pts(1,:),pts(2,:),'r.-');
% plot(graphics(4).XData+rect_diff(1),graphics(4).YData+rect_diff(2),'r.-');
plot(graphics(5).XData+rect_diff(1),graphics(5).YData+rect_diff(2),'co');

grads=cell(size(graphics(1).XData));
grads=transpose(grads);
cen=[mean(graphics(1).XData+rect_diff(1)),mean(graphics(1).YData+rect_diff(2))];
v=[graphics(5).XData+rect_diff(1);graphics(5).YData+rect_diff(2)];
for i=1:size(grads)
[cx cy c]=improfile(qI_d,[v(1,i);cen(1,1)],[v(2,i);cen(1,2)]);
c2=c(1:size(c,1)-1);
c=c(2:size(c,1))-c2;
cx=cx(2:size(cx,1))-cen(1);
cy=cy(2:size(cy,1))-cen(2);
grads{i}=[cx,cy,c];
end
figure;hold;plot(((grads{40}(:,1)).^2+(grads{40}(:,2)).^2).^.5,(grads{40}(:,3)),'r')
plot(((grads{45}(:,1)).^2+(grads{45}(:,2)).^2).^.5,(grads{45}(:,3)),'b')
plot(((grads{50}(:,1)).^2+(grads{50}(:,2)).^2).^.5,(grads{50}(:,3)),'g')

    
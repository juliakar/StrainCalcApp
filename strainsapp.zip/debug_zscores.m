bndry=b_epi;
for i=1:size(zscores,1)
            if abs(zscores(i))>1.5
                [gradc,c_ind]=findpeaks(I_grad_master2{i}(:,1));
                old_b=zeros(1,2);
                old_b(1,1)=bndry(i,1);
                old_b(1,2)=bndry(i,2);
                for ii=1:size(gradc,1)
                    bndry(i,1)=I_grad_master2{i}(c_ind(ii),2);
                    bndry(i,2)=I_grad_master2{i}(c_ind(ii),3);
                    cent=[mean(bndry(:,1)),mean(bndry(:,2))];
                    new_zs=(((bndry(:,1)-cent(:,1)).^2+(bndry(:,2)-cent(:,2)).^2-...
            mean((bndry(:,1)-cent(:,1)).^2+(bndry(:,2)-cent(:,2)).^2))/std((bndry(:,1)-cent(:,1)).^2+(bndry(:,2)-cent(:,2)).^2));
                    if abs(new_zs(i))>abs(zscores(i))
                        bndry(i,1)=old_b(1,1);
                        bndry(i,2)=old_b(1,2);
                    end
                end
            end
        end